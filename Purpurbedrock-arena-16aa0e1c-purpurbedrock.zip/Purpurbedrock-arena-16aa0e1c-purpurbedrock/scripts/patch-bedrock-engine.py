#!/usr/bin/env python3
"""
Transforms GeyserMC/Geyser (commit bbd7e67, native Minecraft 26.2) into
Purpurbedrock's self-contained internal Bedrock 26.2 protocol engine:
1. Dedicated 'bedrock/' folder for cache (including cache/player_skulls for HeadDatabase +
   player_skulls.mcpack + GeyserIntegratedPack.mcpack), custom_mappings, extensions, and packs,
   while keeping internal engine config.yml/key.pem/nethernet cleanly inside 'cache/purpurbedrock/engine'.
2. Auto-discovers pre-cached HeadDatabase PNG skull textures in 'bedrock/cache/player_skulls/*.png'
   and preserves them across restarts so custom heads work automatically in menus and worlds.
3. Disables bStats metrics and external geysermc.org NewsHandler polling.
4. Offline instant AssetUtils -> loads assets/minecraft/lang/en_us.json directly from Purpur 26.2's
   server classpath in <1ms with zero Mojang client JAR download on startup.
5. Adds NetherNet Local LAN Discovery (NetherNetDiscoverySignaling on UDP 7551) alongside
   RakNet (UDP 19132) + NetherNet HTTP Signaling/WebRTC so the server automatically appears
   in Minecraft Bedrock 26.x's local LAN Worlds ('Миры') tab.
6. Anti-kick protocol resilience: never kicks Bedrock players on PacketViolationWarningPacket
   or recoverable IllegalPacketExceptions.
"""
import pathlib
from pathlib import Path
import subprocess
import sys

HISTORICAL_GIT_ASSETS = [
    # 1.21.0 - 1.21.40 palettes & converters (commit fb868e41ed)
    ("fb868e41ed", "core/src/main/resources/bedrock/block_palette.1_21_0.nbt", "core/src/main/resources/bedrock/block_palette.1_21_0.nbt"),
    ("fb868e41ed", "core/src/main/resources/bedrock/block_palette.1_21_20.nbt", "core/src/main/resources/bedrock/block_palette.1_21_20.nbt"),
    ("fb868e41ed", "core/src/main/resources/bedrock/block_palette.1_21_30.nbt", "core/src/main/resources/bedrock/block_palette.1_21_30.nbt"),
    ("fb868e41ed", "core/src/main/resources/bedrock/block_palette.1_21_40.nbt", "core/src/main/resources/bedrock/block_palette.1_21_40.nbt"),
    ("fb868e41ed", "core/src/main/resources/bedrock/runtime_item_states.1_21_0.json", "core/src/main/resources/bedrock/runtime_item_states.1_21_0.json"),
    ("fb868e41ed", "core/src/main/resources/bedrock/runtime_item_states.1_21_20.json", "core/src/main/resources/bedrock/runtime_item_states.1_21_20.json"),
    ("fb868e41ed", "core/src/main/resources/bedrock/runtime_item_states.1_21_30.json", "core/src/main/resources/bedrock/runtime_item_states.1_21_30.json"),
    ("fb868e41ed", "core/src/main/resources/bedrock/runtime_item_states.1_21_40.json", "core/src/main/resources/bedrock/runtime_item_states.1_21_40.json"),
    ("fb868e41ed", "core/src/main/resources/bedrock/creative_items.1_21_0.json", "core/src/main/resources/bedrock/creative_items.1_21_0.json"),
    ("fb868e41ed", "core/src/main/resources/bedrock/creative_items.1_21_20.json", "core/src/main/resources/bedrock/creative_items.1_21_20.json"),
    ("fb868e41ed", "core/src/main/resources/bedrock/creative_items.1_21_30.json", "core/src/main/resources/bedrock/creative_items.1_21_30.json"),
    ("fb868e41ed", "core/src/main/resources/bedrock/creative_items.1_21_40.json", "core/src/main/resources/bedrock/creative_items.1_21_40.json"),
    ("fb868e41ed", "core/src/main/java/org/geysermc/geyser/registry/populator/Conversion712_685.java", "core/src/main/java/org/geysermc/geyser/registry/populator/Conversion712_685.java"),
    ("fb868e41ed", "core/src/main/java/org/geysermc/geyser/registry/populator/Conversion729_712.java", "core/src/main/java/org/geysermc/geyser/registry/populator/Conversion729_712.java"),
    # 1.21.50 - 1.21.80 palettes, item_components, and tags (commit 871390b803)
    ("871390b803", "core/src/main/resources/bedrock/block_palette.1_21_50.nbt", "core/src/main/resources/bedrock/block_palette.1_21_50.nbt"),
    ("871390b803", "core/src/main/resources/bedrock/block_palette.1_21_60.nbt", "core/src/main/resources/bedrock/block_palette.1_21_60.nbt"),
    ("871390b803", "core/src/main/resources/bedrock/block_palette.1_21_70.nbt", "core/src/main/resources/bedrock/block_palette.1_21_70.nbt"),
    ("871390b803", "core/src/main/resources/bedrock/block_palette.1_21_80.nbt", "core/src/main/resources/bedrock/block_palette.1_21_80.nbt"),
    ("871390b803", "core/src/main/resources/bedrock/runtime_item_states.1_21_50.json", "core/src/main/resources/bedrock/runtime_item_states.1_21_50.json"),
    ("871390b803", "core/src/main/resources/bedrock/runtime_item_states.1_21_60.json", "core/src/main/resources/bedrock/runtime_item_states.1_21_60.json"),
    ("871390b803", "core/src/main/resources/bedrock/runtime_item_states.1_21_70.json", "core/src/main/resources/bedrock/runtime_item_states.1_21_70.json"),
    ("871390b803", "core/src/main/resources/bedrock/runtime_item_states.1_21_80.json", "core/src/main/resources/bedrock/runtime_item_states.1_21_80.json"),
    ("871390b803", "core/src/main/resources/bedrock/creative_items.1_21_50.json", "core/src/main/resources/bedrock/creative_items.1_21_50.json"),
    ("871390b803", "core/src/main/resources/bedrock/creative_items.1_21_60.json", "core/src/main/resources/bedrock/creative_items.1_21_60.json"),
    ("871390b803", "core/src/main/resources/bedrock/creative_items.1_21_70.json", "core/src/main/resources/bedrock/creative_items.1_21_70.json"),
    ("871390b803", "core/src/main/resources/bedrock/creative_items.1_21_80.json", "core/src/main/resources/bedrock/creative_items.1_21_80.json"),
    ("871390b803", "core/src/main/resources/bedrock/item_components.nbt", "core/src/main/resources/bedrock/item_components.1_21_80.nbt"),
    ("871390b803", "core/src/main/resources/bedrock/item_tags.1_21_50.json", "core/src/main/resources/bedrock/item_tags.1_21_50.json"),
    ("871390b803", "core/src/main/resources/bedrock/item_tags.1_21_60.json", "core/src/main/resources/bedrock/item_tags.1_21_60.json"),
    ("871390b803", "core/src/main/resources/bedrock/item_tags.1_21_70.json", "core/src/main/resources/bedrock/item_tags.1_21_70.json"),
    # 1.21.90 - 1.21.124 palettes, item_components, and tags (commits 53596d05bc & b4e95b9219)
    ("53596d05bc", "core/src/main/resources/bedrock/block_palette.1_21_90.nbt", "core/src/main/resources/bedrock/block_palette.1_21_90.nbt"),
    ("53596d05bc", "core/src/main/resources/bedrock/block_palette.1_21_100.nbt", "core/src/main/resources/bedrock/block_palette.1_21_100.nbt"),
    ("53596d05bc", "core/src/main/resources/bedrock/block_palette.1_21_110.nbt", "core/src/main/resources/bedrock/block_palette.1_21_110.nbt"),
    ("53596d05bc", "core/src/main/resources/bedrock/runtime_item_states.1_21_90.json", "core/src/main/resources/bedrock/runtime_item_states.1_21_90.json"),
    ("53596d05bc", "core/src/main/resources/bedrock/runtime_item_states.1_21_93.json", "core/src/main/resources/bedrock/runtime_item_states.1_21_93.json"),
    ("53596d05bc", "core/src/main/resources/bedrock/runtime_item_states.1_21_100.json", "core/src/main/resources/bedrock/runtime_item_states.1_21_100.json"),
    ("53596d05bc", "core/src/main/resources/bedrock/runtime_item_states.1_21_110.json", "core/src/main/resources/bedrock/runtime_item_states.1_21_110.json"),
    ("53596d05bc", "core/src/main/resources/bedrock/runtime_item_states.1_21_120.json", "core/src/main/resources/bedrock/runtime_item_states.1_21_120.json"),
    ("53596d05bc", "core/src/main/resources/bedrock/creative_items.1_21_90.json", "core/src/main/resources/bedrock/creative_items.1_21_90.json"),
    ("53596d05bc", "core/src/main/resources/bedrock/creative_items.1_21_93.json", "core/src/main/resources/bedrock/creative_items.1_21_93.json"),
    ("53596d05bc", "core/src/main/resources/bedrock/creative_items.1_21_100.json", "core/src/main/resources/bedrock/creative_items.1_21_100.json"),
    ("53596d05bc", "core/src/main/resources/bedrock/creative_items.1_21_110.json", "core/src/main/resources/bedrock/creative_items.1_21_110.json"),
    ("53596d05bc", "core/src/main/resources/bedrock/creative_items.1_21_120.json", "core/src/main/resources/bedrock/creative_items.1_21_120.json"),
    ("53596d05bc", "core/src/main/resources/bedrock/item_components.1_21_90.nbt", "core/src/main/resources/bedrock/item_components.1_21_90.nbt"),
    ("53596d05bc", "core/src/main/resources/bedrock/item_components.1_21_93.nbt", "core/src/main/resources/bedrock/item_components.1_21_93.nbt"),
    ("53596d05bc", "core/src/main/resources/bedrock/item_components.1_21_100.nbt", "core/src/main/resources/bedrock/item_components.1_21_100.nbt"),
    ("53596d05bc", "core/src/main/resources/bedrock/item_components.1_21_110.nbt", "core/src/main/resources/bedrock/item_components.1_21_110.nbt"),
    ("53596d05bc", "core/src/main/resources/bedrock/item_components.1_21_120.nbt", "core/src/main/resources/bedrock/item_components.1_21_120.nbt"),
    ("53596d05bc", "core/src/main/resources/bedrock/item_tags.1_21_90.json", "core/src/main/resources/bedrock/item_tags.1_21_90.json"),
    ("53596d05bc", "core/src/main/resources/bedrock/item_tags.1_21_100.json", "core/src/main/resources/bedrock/item_tags.1_21_100.json"),
    ("53596d05bc", "core/src/main/resources/bedrock/item_tags.1_21_110.json", "core/src/main/resources/bedrock/item_tags.1_21_110.json"),
    ("b4e95b9219", "core/src/main/resources/bedrock/item_tags.1_21_120.json", "core/src/main/resources/bedrock/item_tags.1_21_120.json"),
    # 1.21.130 - 26.23 palettes, item_components, and tags (commit 6075649081)
    ("6075649081", "core/src/main/resources/bedrock/block_palette.1_21_130.nbt", "core/src/main/resources/bedrock/block_palette.1_21_130.nbt"),
    ("6075649081", "core/src/main/resources/bedrock/block_palette.1_26_10.nbt", "core/src/main/resources/bedrock/block_palette.1_26_10.nbt"),
    ("6075649081", "core/src/main/resources/bedrock/block_palette.1_26_20.nbt", "core/src/main/resources/bedrock/block_palette.1_26_20.nbt"),
    ("6075649081", "core/src/main/resources/bedrock/runtime_item_states.1_21_130.json", "core/src/main/resources/bedrock/runtime_item_states.1_21_130.json"),
    ("6075649081", "core/src/main/resources/bedrock/runtime_item_states.1_26_0.json", "core/src/main/resources/bedrock/runtime_item_states.1_26_0.json"),
    ("6075649081", "core/src/main/resources/bedrock/runtime_item_states.1_26_10.json", "core/src/main/resources/bedrock/runtime_item_states.1_26_10.json"),
    ("6075649081", "core/src/main/resources/bedrock/runtime_item_states.1_26_20.json", "core/src/main/resources/bedrock/runtime_item_states.1_26_20.json"),
    ("6075649081", "core/src/main/resources/bedrock/creative_items.1_21_130.json", "core/src/main/resources/bedrock/creative_items.1_21_130.json"),
    ("6075649081", "core/src/main/resources/bedrock/creative_items.1_26_0.json", "core/src/main/resources/bedrock/creative_items.1_26_0.json"),
    ("6075649081", "core/src/main/resources/bedrock/creative_items.1_26_10.json", "core/src/main/resources/bedrock/creative_items.1_26_10.json"),
    ("6075649081", "core/src/main/resources/bedrock/item_components.1_21_130.nbt", "core/src/main/resources/bedrock/item_components.1_21_130.nbt"),
    ("6075649081", "core/src/main/resources/bedrock/item_components.1_26_0.nbt", "core/src/main/resources/bedrock/item_components.1_26_0.nbt"),
    ("6075649081", "core/src/main/resources/bedrock/item_components.1_26_10.nbt", "core/src/main/resources/bedrock/item_components.1_26_10.nbt"),
    ("6075649081", "core/src/main/resources/bedrock/item_components.1_26_20.nbt", "core/src/main/resources/bedrock/item_components.1_26_20.nbt"),
    ("6075649081", "core/src/main/resources/bedrock/item_tags.1_21_130.json", "core/src/main/resources/bedrock/item_tags.1_21_130.json"),
    ("6075649081", "core/src/main/resources/bedrock/item_tags.1_26_0.json", "core/src/main/resources/bedrock/item_tags.1_26_0.json"),
    ("6075649081", "core/src/main/resources/bedrock/item_tags.1_26_10.json", "core/src/main/resources/bedrock/item_tags.1_26_10.json"),
    # 26.60 protocol palettes (official Geyser support commit fd35d5918)
    ("fd35d5918", "core/src/main/resources/bedrock/block_palette.26_60.nbt", "core/src/main/resources/bedrock/block_palette.26_60.nbt"),
    ("fd35d5918", "core/src/main/resources/bedrock/runtime_item_states.26_60.json", "core/src/main/resources/bedrock/runtime_item_states.26_60.json"),
    ("fd35d5918", "core/src/main/resources/bedrock/creative_items.26_60.json", "core/src/main/resources/bedrock/creative_items.26_60.json"),
    ("fd35d5918", "core/src/main/resources/bedrock/item_components.26_60.nbt", "core/src/main/resources/bedrock/item_components.26_60.nbt"),
    ("fd35d5918", "core/src/main/resources/bedrock/data_driven_blocks.26_60.nbt", "core/src/main/resources/bedrock/data_driven_blocks.26_60.nbt"),
]


MULTI_VERSION_HELPER_JAVA = """package org.geysermc.geyser.registry.populator;

import org.cloudburstmc.nbt.NbtMap;
import org.cloudburstmc.nbt.NbtMapBuilder;
import org.geysermc.geyser.item.Items;
import org.geysermc.geyser.item.type.Item;
import org.geysermc.geyser.level.block.type.BlockState;
import org.geysermc.geyser.level.block.type.SkullBlock;
import org.geysermc.geyser.registry.Registries;
import org.geysermc.geyser.registry.populator.conversion.ChaosCubedConverter;
import org.geysermc.geyser.registry.populator.conversion.ICanHasStates;
import org.geysermc.geyser.registry.type.GeyserBedrockBlock;
import org.geysermc.geyser.registry.type.GeyserMappingItem;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

// Purpurbedrock Multi-Version Palette and Mapping Helper (Bedrock 1.21.0 v685 to 26.60 v2225).
public final class MultiVersionPaletteHelper {

    private static final Set<String> PALE_OAK_BLOCKS = Set.of(
        "pale_oak_wood", "pale_oak_planks", "pale_oak_sapling", "pale_oak_log",
        "stripped_pale_oak_log", "stripped_pale_oak_wood", "pale_oak_leaves",
        "pale_oak_hanging_sign", "pale_oak_pressure_plate", "pale_oak_trapdoor",
        "pale_oak_button", "pale_oak_stairs", "pale_oak_slab", "pale_oak_double_slab",
        "pale_oak_fence_gate", "pale_oak_fence", "pale_oak_door",
        "pale_oak_standing_sign", "pale_oak_wall_sign"
    );

    private MultiVersionPaletteHelper() {
    }

    public static NbtMap remapBlockForVersion(int protocolVersion, BlockState javaBlockState, NbtMap tag) {
        if (protocolVersion >= 2193) {
            return tag;
        }
        // < 26.50 (v2193): strip stair corner & fence/pane/bars/tripwire server connections
        tag = ICanHasStates.convertBlock(tag);

        // < 26.30 (v1001): ChaosCubed sulfur/cinnabar fallbacks
        if (protocolVersion < 1001) {
            tag = ChaosCubedConverter.convertBlock(tag);
        }

        // < 26.20 (v975): golden_dandelion -> dandelion
        if (protocolVersion < 975 && tag.getString("name").equals("minecraft:golden_dandelion")) {
            tag = withoutStates("minecraft:dandelion");
        }

        // < 1.21.110 (v844): shelves, copper bars/chains/lanterns/torches/statues, oxidized lightning rods
        if (protocolVersion < 844) {
            String name = tag.getString("name");
            if (name.equals("minecraft:iron_chain") || name.endsWith("copper_chain")) {
                tag = withId(tag, "minecraft:chain");
            } else if (name.endsWith("lightning_rod")) {
                NbtMapBuilder states = tag.getCompound("states").toBuilder();
                states.remove("powered_bit");
                tag = tag.toBuilder().putString("name", "minecraft:lightning_rod").putCompound("states", states.build()).build();
            } else if (name.endsWith("_shelf")) {
                tag = withoutStates("minecraft:bookshelf");
            } else if (name.endsWith("copper_golem_statue")) {
                tag = withoutStates("minecraft:cut_copper");
            } else if (name.equals("minecraft:copper_torch")) {
                tag = withId(tag, "minecraft:torch");
            } else if (name.endsWith("copper_bars")) {
                tag = withId(tag, "minecraft:iron_bars");
            } else if (name.endsWith("copper_lantern")) {
                tag = withId(tag, "minecraft:lantern");
            }
        }

        // < 1.21.100 (v827): copper chests -> chest
        if (protocolVersion < 827 && tag.getString("name").endsWith("copper_chest")) {
            tag = withId(tag, "minecraft:chest");
        }

        // < 1.21.80 (v800): dried_ghast -> bone_block
        if (protocolVersion < 800 && tag.getString("name").equals("minecraft:dried_ghast")) {
            tag = withoutStates("minecraft:bone_block");
        }

        // < 1.21.70 (v786): spring drop vegetation
        if (protocolVersion < 786) {
            String name = tag.getString("name");
            if (name.equals("minecraft:bush")) {
                tag = withId(tag, "minecraft:fern");
            } else if (name.equals("minecraft:firefly_bush")) {
                tag = withId(tag, "minecraft:deadbush");
            } else if (name.equals("minecraft:tall_dry_grass") || name.equals("minecraft:short_dry_grass")) {
                tag = withId(tag, "minecraft:short_grass");
            } else if (name.equals("minecraft:cactus_flower")) {
                tag = withoutStates("minecraft:poppy");
            } else if (name.equals("minecraft:leaf_litter") || name.equals("minecraft:wildflowers")) {
                tag = withoutStates("minecraft:pink_petals");
            }
        }

        // < 1.21.60 (v776): creaking_heart boolean active & door/fence_gate cardinal_direction -> int direction
        if (protocolVersion < 776) {
            String name = tag.getString("name");
            if (name.equals("minecraft:creaking_heart")) {
                NbtMapBuilder states = tag.getCompound("states").toBuilder();
                Object val = states.remove("creaking_heart_state");
                states.putBoolean("active", "awake".equals(val));
                tag = tag.toBuilder().putCompound("states", states.build()).build();
            } else if (name.endsWith("_door") || name.endsWith("fence_gate")) {
                NbtMap curStates = tag.getCompound("states");
                if (curStates.containsKey("minecraft:cardinal_direction")) {
                    NbtMapBuilder states = curStates.toBuilder();
                    String dir = String.valueOf(states.remove("minecraft:cardinal_direction"));
                    int dirInt = switch (dir) {
                        case "south" -> 0;
                        case "west" -> 1;
                        case "north" -> 2;
                        case "east" -> 3;
                        default -> 0;
                    };
                    states.putInt("direction", dirInt);
                    tag = tag.toBuilder().putCompound("states", states.build()).build();
                }
            }
        }

        // < 1.21.50 (v766): Pale Garden & Resin blocks
        if (protocolVersion < 766) {
            String bare = tag.getString("name").replace("minecraft:", "");
            if (PALE_OAK_BLOCKS.contains(bare)) {
                tag = withId(tag, "minecraft:" + bare.replace("pale_oak", "birch"));
            } else {
                tag = switch (bare) {
                    case "resin_brick_double_slab" -> withId(tag, "minecraft:red_sandstone_double_slab");
                    case "pale_moss_block" -> withId(tag, "minecraft:moss_block");
                    case "pale_moss_carpet" -> withoutStates("minecraft:moss_carpet");
                    case "pale_hanging_moss" -> withoutStates("minecraft:hanging_roots");
                    case "open_eyeblossom" -> withoutStates("minecraft:oxeye_daisy");
                    case "closed_eyeblossom" -> withoutStates("minecraft:white_tulip");
                    case "resin_clump" -> withoutStates("minecraft:deadbush");
                    case "resin_block" -> withoutStates("minecraft:red_sandstone");
                    case "resin_bricks" -> withoutStates("minecraft:cut_red_sandstone");
                    case "resin_brick_stairs" -> withId(tag, "minecraft:red_sandstone_stairs");
                    case "resin_brick_slab" -> withId(tag, "minecraft:red_sandstone_slab");
                    case "resin_brick_wall" -> withId(tag, "minecraft:red_sandstone_wall");
                    case "chiseled_resin_bricks" -> withId(tag, "minecraft:chiseled_red_sandstone");
                    case "creaking_heart" -> withoutStates("minecraft:chiseled_polished_blackstone");
                    default -> tag;
                };
            }
        }

        // == 1.21.40 (v748) & < 1.21.40 (< v748): skulls, mushroom_stem, wood stripped_bit
        if (protocolVersion == 748) {
            if (tag.getString("name").endsWith("_wood") && tag.getCompound("states").containsKey("stripped_bit")) {
                NbtMapBuilder states = tag.getCompound("states").toBuilder();
                states.remove("stripped_bit");
                tag = tag.toBuilder().putCompound("states", states.build()).build();
            }
        } else if (protocolVersion < 748) {
            if (javaBlockState.block() instanceof SkullBlock) {
                int facing = 1;
                NbtMap curStates = tag.getCompound("states");
                if (curStates.containsKey("facing_direction")) {
                    facing = curStates.getInt("facing_direction");
                }
                tag = NbtMap.builder()
                    .putString("name", "minecraft:skull")
                    .putCompound("states", NbtMap.builder().putInt("facing_direction", facing).build())
                    .build();
            } else if (tag.getString("name").equals("minecraft:mushroom_stem")) {
                tag = NbtMap.builder()
                    .putString("name", "minecraft:brown_mushroom_block")
                    .putCompound("states", NbtMap.builder().putInt("huge_mushroom_bits", 10).build())
                    .build();
            } else if (tag.getString("name").endsWith("_wood")) {
                boolean stripped = tag.getString("name").startsWith("minecraft:stripped_");
                String baseWood = tag.getString("name").replace("stripped_", "");
                NbtMapBuilder states = tag.getCompound("states").toBuilder();
                states.putBoolean("stripped_bit", stripped);
                tag = tag.toBuilder().putString("name", baseWood).putCompound("states", states.build()).build();
            }
        }

        // < 1.21.30 (v729) & < 1.21.20 (v712)
        if (protocolVersion < 712) {
            tag = Conversion712_685.remapBlock(tag);
        } else if (protocolVersion < 729) {
            tag = Conversion729_712.remapBlock(tag);
        }

        return tag;
    }

    public static GeyserBedrockBlock resolveBlockDefinition(
            NbtMap remappedTag,
            Map<NbtMap, GeyserBedrockBlock> exactMap,
            Map<String, List<GeyserBedrockBlock>> byNameMap) {
        GeyserBedrockBlock direct = exactMap.get(remappedTag);
        if (direct != null) {
            return direct;
        }
        String name = remappedTag.getString("name");
        NbtMap wantedStates = remappedTag.getCompound("states");

        GeyserBedrockBlock sameNameBest = bestStateMatch(byNameMap.get(name), wantedStates);
        if (sameNameBest != null) {
            return sameNameBest;
        }

        // Structural collision-preserving fallback candidates
        String[] candidates;
        if (name.endsWith("_stairs")) {
            candidates = new String[]{"minecraft:oak_stairs", "minecraft:stone_stairs"};
        } else if (name.endsWith("_double_slab")) {
            candidates = new String[]{"minecraft:oak_double_slab", "minecraft:double_wooden_slab", "minecraft:planks", "minecraft:stone"};
        } else if (name.endsWith("_slab")) {
            candidates = new String[]{"minecraft:oak_slab", "minecraft:wooden_slab", "minecraft:stone_block_slab"};
        } else if (name.endsWith("_wall")) {
            candidates = new String[]{"minecraft:cobblestone_wall"};
        } else if (name.endsWith("_fence_gate")) {
            candidates = new String[]{"minecraft:fence_gate"};
        } else if (name.endsWith("_fence")) {
            candidates = new String[]{"minecraft:oak_fence", "minecraft:fence"};
        } else if (name.endsWith("_door")) {
            candidates = new String[]{"minecraft:wooden_door"};
        } else if (name.endsWith("_trapdoor")) {
            candidates = new String[]{"minecraft:trapdoor"};
        } else if (name.endsWith("_button")) {
            candidates = new String[]{"minecraft:wooden_button"};
        } else if (name.endsWith("_pressure_plate")) {
            candidates = new String[]{"minecraft:wooden_pressure_plate"};
        } else if (name.contains("leaves")) {
            candidates = new String[]{"minecraft:oak_leaves", "minecraft:leaves"};
        } else if (name.contains("glass_pane")) {
            candidates = new String[]{"minecraft:glass_pane"};
        } else if (name.contains("carpet")) {
            candidates = new String[]{"minecraft:white_carpet", "minecraft:carpet"};
        } else if (name.contains("bush") || name.contains("grass") || name.contains("flower") || name.contains("litter") || name.contains("petals") || name.contains("moss") || name.contains("clump")) {
            candidates = new String[]{"minecraft:short_grass", "minecraft:tallgrass", "minecraft:deadbush", "minecraft:air"};
        } else {
            candidates = new String[]{"minecraft:stone", "minecraft:unknown", "minecraft:air"};
        }

        for (String candidate : candidates) {
            GeyserBedrockBlock match = bestStateMatch(byNameMap.get(candidate), wantedStates);
            if (match != null) {
                return match;
            }
        }

        for (List<GeyserBedrockBlock> anyList : byNameMap.values()) {
            if (!anyList.isEmpty()) {
                return anyList.getFirst();
            }
        }
        return null;
    }

    private static GeyserBedrockBlock bestStateMatch(List<GeyserBedrockBlock> candidates, NbtMap wantedStates) {
        if (candidates == null || candidates.isEmpty()) {
            return null;
        }
        if (wantedStates == null || wantedStates.isEmpty() || candidates.size() == 1) {
            return candidates.getFirst();
        }
        GeyserBedrockBlock best = candidates.getFirst();
        int bestScore = -1;
        for (GeyserBedrockBlock candidate : candidates) {
            NbtMap candStates = candidate.getState().getCompound("states");
            int score = 0;
            for (Map.Entry<String, Object> e : wantedStates.entrySet()) {
                if (Objects.equals(candStates.get(e.getKey()), e.getValue())) {
                    score += 2;
                }
            }
            if (score > bestScore) {
                bestScore = score;
                best = candidate;
            }
        }
        return best;
    }

    public static GeyserMappingItem remapItemForVersion(int protocolVersion, Item item, GeyserMappingItem mapping) {
        if (protocolVersion < 844) {
            if (item == Items.IRON_CHAIN || item.javaIdentifier().endsWith("copper_chain")) {
                mapping = mapping.withBedrockIdentifier("minecraft:chain");
            }
        }
        if (protocolVersion < 748) {
            mapping = switch (mapping.getBedrockIdentifier()) {
                case "minecraft:skeleton_skull" -> mapping.withBedrockIdentifier("minecraft:skull").withBedrockData(0);
                case "minecraft:wither_skeleton_skull" -> mapping.withBedrockIdentifier("minecraft:skull").withBedrockData(1);
                case "minecraft:zombie_head" -> mapping.withBedrockIdentifier("minecraft:skull").withBedrockData(2);
                case "minecraft:player_head" -> mapping.withBedrockIdentifier("minecraft:skull").withBedrockData(3);
                case "minecraft:creeper_head" -> mapping.withBedrockIdentifier("minecraft:skull").withBedrockData(4);
                case "minecraft:dragon_head" -> mapping.withBedrockIdentifier("minecraft:skull").withBedrockData(5);
                case "minecraft:piglin_head" -> mapping.withBedrockIdentifier("minecraft:skull").withBedrockData(6);
                case "minecraft:mushroom_stem" -> mapping.withBedrockIdentifier("minecraft:brown_mushroom_block").withBedrockData(10);
                default -> mapping;
            };
        }
        if (protocolVersion < 712) {
            mapping = Conversion712_685.remapItem(item, mapping);
        } else if (protocolVersion < 729) {
            mapping = Conversion729_712.remapItem(item, mapping);
        }
        return mapping;
    }

    public static Map<Item, Item> buildJavaOnlyItemFallbacks(int protocolVersion) {
        Map<Item, Item> out = new HashMap<>();
        if (protocolVersion < 1001) {
            out.putAll(ChaosCubedConverter.convertItem());
        }
        if (protocolVersion < 975) {
            out.put(Items.GOLDEN_DANDELION, Items.DANDELION);
        }
        if (protocolVersion < 898) {
            putById(out, "minecraft:wooden_spear", "minecraft:wooden_sword");
            putById(out, "minecraft:stone_spear", "minecraft:stone_sword");
            putById(out, "minecraft:copper_spear", "minecraft:stone_sword");
            putById(out, "minecraft:iron_spear", "minecraft:iron_sword");
            putById(out, "minecraft:golden_spear", "minecraft:golden_sword");
            putById(out, "minecraft:diamond_spear", "minecraft:diamond_sword");
            putById(out, "minecraft:netherite_spear", "minecraft:netherite_sword");
            putById(out, "minecraft:copper_nautilus_armor", "minecraft:iron_horse_armor");
            putById(out, "minecraft:iron_nautilus_armor", "minecraft:iron_horse_armor");
            putById(out, "minecraft:golden_nautilus_armor", "minecraft:golden_horse_armor");
            putById(out, "minecraft:diamond_nautilus_armor", "minecraft:diamond_horse_armor");
            putById(out, "minecraft:netherite_nautilus_armor", "minecraft:diamond_horse_armor");
            putById(out, "minecraft:netherite_horse_armor", "minecraft:diamond_horse_armor");
            putById(out, "minecraft:nautilus_spawn_egg", "minecraft:dolphin_spawn_egg");
            putById(out, "minecraft:zombie_nautilus_spawn_egg", "minecraft:dolphin_spawn_egg");
            putById(out, "minecraft:camel_husk_spawn_egg", "minecraft:camel_spawn_egg");
            putById(out, "minecraft:parched_spawn_egg", "minecraft:husk_spawn_egg");
        }
        if (protocolVersion < 844) {
            for (Item it : Registries.JAVA_ITEMS.get()) {
                String id = it.javaIdentifier();
                if (id.endsWith("_shelf")) {
                    putById(out, id, "minecraft:bookshelf");
                } else if (id.endsWith("copper_bars")) {
                    putById(out, id, "minecraft:iron_bars");
                } else if (id.endsWith("copper_lantern")) {
                    putById(out, id, "minecraft:lantern");
                } else if (id.endsWith("copper_golem_statue")) {
                    putById(out, id, "minecraft:cut_copper");
                } else if (id.endsWith("copper_chain")) {
                    putById(out, id, "minecraft:iron_chain");
                } else if (id.endsWith("_lightning_rod")) {
                    putById(out, id, "minecraft:lightning_rod");
                }
            }
            putById(out, "minecraft:copper_torch", "minecraft:torch");
            putById(out, "minecraft:copper_sword", "minecraft:stone_sword");
            putById(out, "minecraft:copper_pickaxe", "minecraft:stone_pickaxe");
            putById(out, "minecraft:copper_axe", "minecraft:stone_axe");
            putById(out, "minecraft:copper_shovel", "minecraft:stone_shovel");
            putById(out, "minecraft:copper_hoe", "minecraft:stone_hoe");
            putById(out, "minecraft:copper_helmet", "minecraft:chainmail_helmet");
            putById(out, "minecraft:copper_chestplate", "minecraft:chainmail_chestplate");
            putById(out, "minecraft:copper_leggings", "minecraft:chainmail_leggings");
            putById(out, "minecraft:copper_boots", "minecraft:chainmail_boots");
            putById(out, "minecraft:copper_horse_armor", "minecraft:iron_horse_armor");
            putById(out, "minecraft:copper_nugget", "minecraft:iron_nugget");
            putById(out, "minecraft:copper_golem_spawn_egg", "minecraft:iron_golem_spawn_egg");
        }
        if (protocolVersion < 827) {
            for (Item it : Registries.JAVA_ITEMS.get()) {
                String id = it.javaIdentifier();
                if (id.endsWith("copper_chest")) {
                    putById(out, id, "minecraft:chest");
                }
            }
        }
        if (protocolVersion < 818) {
            putById(out, "minecraft:music_disc_lava_chicken", "minecraft:music_disc_cat");
        }
        if (protocolVersion < 800) {
            for (Item it : Registries.JAVA_ITEMS.get()) {
                String id = it.javaIdentifier();
                if (id.endsWith("_harness")) {
                    putById(out, id, "minecraft:saddle");
                }
            }
            putById(out, "minecraft:dried_ghast", "minecraft:bone_block");
            putById(out, "minecraft:happy_ghast_spawn_egg", "minecraft:ghast_spawn_egg");
            putById(out, "minecraft:music_disc_tears", "minecraft:music_disc_blocks");
        }
        if (protocolVersion < 786) {
            putById(out, "minecraft:bush", "minecraft:fern");
            putById(out, "minecraft:firefly_bush", "minecraft:dead_bush");
            putById(out, "minecraft:short_dry_grass", "minecraft:short_grass");
            putById(out, "minecraft:tall_dry_grass", "minecraft:short_grass");
            putById(out, "minecraft:cactus_flower", "minecraft:poppy");
            putById(out, "minecraft:leaf_litter", "minecraft:pink_petals");
            putById(out, "minecraft:wildflowers", "minecraft:pink_petals");
            putById(out, "minecraft:blue_egg", "minecraft:egg");
            putById(out, "minecraft:brown_egg", "minecraft:egg");
        }
        if (protocolVersion < 766) {
            for (Item it : Registries.JAVA_ITEMS.get()) {
                String id = it.javaIdentifier();
                if (id.contains("pale_oak") && !out.containsKey(it)) {
                    putById(out, id, id.replace("pale_oak", "birch"));
                }
            }
            putById(out, "minecraft:pale_moss_block", "minecraft:moss_block");
            putById(out, "minecraft:pale_moss_carpet", "minecraft:moss_carpet");
            putById(out, "minecraft:pale_hanging_moss", "minecraft:hanging_roots");
            putById(out, "minecraft:open_eyeblossom", "minecraft:oxeye_daisy");
            putById(out, "minecraft:closed_eyeblossom", "minecraft:white_tulip");
            putById(out, "minecraft:resin_clump", "minecraft:orange_dye");
            putById(out, "minecraft:resin_brick", "minecraft:brick");
            putById(out, "minecraft:resin_block", "minecraft:red_sandstone");
            putById(out, "minecraft:resin_bricks", "minecraft:cut_red_sandstone");
            putById(out, "minecraft:resin_brick_stairs", "minecraft:red_sandstone_stairs");
            putById(out, "minecraft:resin_brick_slab", "minecraft:red_sandstone_slab");
            putById(out, "minecraft:resin_brick_wall", "minecraft:red_sandstone_wall");
            putById(out, "minecraft:chiseled_resin_bricks", "minecraft:chiseled_red_sandstone");
            putById(out, "minecraft:creaking_heart", "minecraft:chiseled_polished_blackstone");
            putById(out, "minecraft:creaking_spawn_egg", "minecraft:enderman_spawn_egg");
        }
        if (protocolVersion < 748) {
            for (Item it : Registries.JAVA_ITEMS.get()) {
                String id = it.javaIdentifier();
                if ((id.equals("minecraft:bundle") || id.endsWith("_bundle")) && !out.containsKey(it)) {
                    putById(out, id, "minecraft:chest");
                }
            }
            putById(out, "minecraft:field_masoned_banner_pattern", "minecraft:flower_banner_pattern");
            putById(out, "minecraft:bordure_indented_banner_pattern", "minecraft:flower_banner_pattern");
        }
        // Resolve transitive fallback chains (e.g. pale_oak_shelf -> oak_shelf -> bookshelf)
        boolean changed = true;
        while (changed) {
            changed = false;
            for (Map.Entry<Item, Item> e : new HashMap<>(out).entrySet()) {
                Item next = out.get(e.getValue());
                if (next != null && next != e.getValue()) {
                    out.put(e.getKey(), next);
                    changed = true;
                }
            }
        }
        return out;
    }

    private static void putById(Map<Item, Item> map, String srcId, String dstId) {
        Item src = Registries.JAVA_ITEM_IDENTIFIERS.get(srcId);
        Item dst = Registries.JAVA_ITEM_IDENTIFIERS.get(dstId);
        if (src != null && dst != null) {
            map.put(src, dst);
        }
    }

    private static NbtMap withId(NbtMap tag, String id) {
        NbtMapBuilder b = tag.toBuilder();
        b.replace("name", id);
        return b.build();
    }

    private static NbtMap withoutStates(String id) {
        return NbtMap.builder()
            .putString("name", id)
            .putCompound("states", NbtMap.EMPTY)
            .build();
    }
}
"""


def extract_historical_git_assets(root: Path) -> None:
    if "--skip-git-assets" in sys.argv:
        print("Skipping historical git asset extraction (--skip-git-assets).")
        return
    git_dir = root / ".git"
    if not git_dir.exists():
        raise RuntimeError(f"Expected git repository at {root} to extract historical multi-version palettes!")
    for sha, src_rel, dst_rel in HISTORICAL_GIT_ASSETS:
        raw = subprocess.check_output(["git", "-C", str(root), "show", f"{sha}:{src_rel}"])
        dst = root / dst_rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(raw)
    print(f"Extracted {len(HISTORICAL_GIT_ASSETS)} historical Bedrock multi-version assets (1.21.0 -> 26.60) from git.")




def replace_exact(path: pathlib.Path, old: str, new: str, label: str) -> None:
    text = path.read_text(encoding="utf-8")
    if old not in text:
        raise RuntimeError(f"[{label}] Expected snippet not found in {path}")
    path.write_text(text.replace(old, new, 1), encoding="utf-8")
    print(f"[OK] Patched {label} in {path.name}")


def main() -> None:
    if len(sys.argv) < 2:
        raise SystemExit("Usage: patch-bedrock-engine.py <geyser-root> [--skip-git-assets]")

    root = pathlib.Path(sys.argv[1]).resolve()

    # 0. Trim settings.gradle.kts to only build :ap, :api, :common, :core, :spigot (skip Loom/NeoForge)
    replace_exact(
        root / "settings.gradle.kts",
        """include(":ap")
include(":api")
include(":bungeecord")
include(":fabric")
include(":gametest")
include(":neoforge")
include(":mod")
include(":spigot")
include(":standalone")
include(":velocity")
include(":viaproxy")
include(":common")
include(":core")

// Specify project dirs
project(":bungeecord").projectDir = file("bootstrap/bungeecord")
project(":fabric").projectDir = file("bootstrap/mod/fabric")
project(":gametest").projectDir = file("bootstrap/mod/gametest")
project(":neoforge").projectDir = file("bootstrap/mod/neoforge")
project(":mod").projectDir = file("bootstrap/mod")
project(":spigot").projectDir = file("bootstrap/spigot")
project(":standalone").projectDir = file("bootstrap/standalone")
project(":velocity").projectDir = file("bootstrap/velocity")
project(":viaproxy").projectDir = file("bootstrap/viaproxy")""",
        """include(":ap")
include(":api")
include(":common")
include(":core")
include(":spigot")

project(":spigot").projectDir = file("bootstrap/spigot")""",
        "settings.gradle.kts minimal spigot build",
    )

    # Cloudburst protocol build containing the official Bedrock 26.60 (v2225) codec and packets.
    versions_catalog = root / "gradle/libs.versions.toml"
    replace_exact(
        versions_catalog,
        'protocol-connection = "3.0.0.Beta14-20261009.172637-6"',
        'protocol-connection = "3.0.0.Beta14-20261019.150006-9"',
        "CloudburstProtocol.v2225Connection",
    )
    replace_exact(
        versions_catalog,
        'protocol-common = "3.0.0.Beta14-20261009.172637-6"',
        'protocol-common = "3.0.0.Beta14-20261019.150006-9"',
        "CloudburstProtocol.v2225Common",
    )
    replace_exact(
        versions_catalog,
        'protocol-codec = "3.0.0.Beta14-20261009.172637-6"',
        'protocol-codec = "3.0.0.Beta14-20261019.150006-9"',
        "CloudburstProtocol.v2225Codec",
    )

    # 1. GeyserSpigotPlugin.java: point getConfigFolder() to bedrock/ (so cache, player_skulls, packs,
    #    extensions, custom_mappings all live cleanly in bedrock/), keep Floodgate fallback key in engineDir,
    #    and disable bStats telemetry.
    spigot_plugin = root / "bootstrap/spigot/src/main/java/org/geysermc/geyser/platform/spigot/GeyserSpigotPlugin.java"
    replace_exact(
        spigot_plugin,
        """    @Override
    public Path getConfigFolder() {
        return getDataFolder().toPath();
    }""",
        """    @Override
    public Path getConfigFolder() {
        Path bedrockDataDir = Path.of(System.getProperty("purpurbedrock.dataDir", "bedrock")).toAbsolutePath();
        try {
            java.nio.file.Files.createDirectories(bedrockDataDir);
        } catch (java.io.IOException ignored) {
        }
        return bedrockDataDir;
    }""",
        "GeyserSpigotPlugin.getConfigFolder",
    )
    replace_exact(
        spigot_plugin,
        """        Plugin floodgate = Bukkit.getPluginManager().getPlugin("floodgate");
        Path geyserDataFolder = getDataFolder().toPath();
        Path floodgateDataFolder = floodgate != null ? floodgate.getDataFolder().toPath() : null;""",
        """        Plugin floodgate = Bukkit.getPluginManager().getPlugin("floodgate");
        Path geyserDataFolder = Path.of(System.getProperty("purpurbedrock.engineDir", "cache/purpurbedrock/engine")).toAbsolutePath();
        Path floodgateDataFolder = floodgate != null ? floodgate.getDataFolder().toPath() : null;""",
        "GeyserSpigotPlugin.getFloodgateKeyPath",
    )
    replace_exact(
        spigot_plugin,
        """    @Override
    public MetricsPlatform createMetricsPlatform() {
        return new SpigotMetrics(this);
    }""",
        """    @Override
    public MetricsPlatform createMetricsPlatform() {
        return null; // Purpurbedrock: disable external bStats telemetry
    }""",
        "GeyserSpigotPlugin.createMetricsPlatform",
    )

    # 1b. ConfigLoader.java: read internal config.yml from purpurbedrock.engineDir so bedrock/ only holds user content
    config_loader = root / "core/src/main/java/org/geysermc/geyser/configuration/ConfigLoader.java"
    replace_exact(
        config_loader,
        """    public ConfigLoader(GeyserBootstrap bootstrap) {
        this.bootstrap = bootstrap;
        this.platformType = bootstrap.platformType();
        configFile = new File(bootstrap.getConfigFolder().toFile(), "config.yml");
    }""",
        """    public ConfigLoader(GeyserBootstrap bootstrap) {
        this.bootstrap = bootstrap;
        this.platformType = bootstrap.platformType();
        Path engineDir = Path.of(System.getProperty("purpurbedrock.engineDir", "cache/purpurbedrock/engine")).toAbsolutePath();
        try {
            java.nio.file.Files.createDirectories(engineDir);
        } catch (java.io.IOException ignored) {
        }
        configFile = engineDir.resolve("config.yml").toFile();
    }""",
        "ConfigLoader.constructor",
    )

    # 2. NewsHandler.java: disable external geysermc.org polling
    news_handler = root / "core/src/main/java/org/geysermc/geyser/util/NewsHandler.java"
    replace_exact(
        news_handler,
        """    public NewsHandler(String branch, int build) {
        this.branch = branch;
        this.build = build;

        executorService.scheduleWithFixedDelay(this::checkNews, 0, 30, TimeUnit.MINUTES);
    }""",
        """    public NewsHandler(String branch, int build) {
        this.branch = branch;
        this.build = build;
        // Purpurbedrock: disabled external news polling to geysermc.org
    }""",
        "NewsHandler.constructor",
    )

    # 3. AssetUtils.java & MinecraftLocale.java: instant offline en_us + ru_ru/uk_ua/be_by/kk_kz + deprecated
    #    translations from Bukkit/bundled classpath without downloading 50MB client.jar, plus quiet async
    #    Mojang asset index lookup for all other client languages.
    asset_utils = root / "core/src/main/java/org/geysermc/geyser/util/AssetUtils.java"
    replace_exact(
        asset_utils,
        """    public static CompletableFuture<Void> generateAssetCache() {
        return CompletableFuture.supplyAsync(() -> {""",
        """    public static CompletableFuture<Void> generateAssetCache() {
        if (Boolean.parseBoolean(System.getProperty("purpurbedrock.offlineAssets", "true"))) {
            return CompletableFuture.completedFuture(null);
        }
        return CompletableFuture.supplyAsync(() -> {""",
        "AssetUtils.generateAssetCacheOfflineBypass",
    )
    replace_exact(
        asset_utils,
        """                // Get the url for the latest version of the games manifest
                String latestInfoURL = "";
                for (Version version : versionManifest.getVersions()) {
                    if (version.getId().equals(GameProtocol.getJavaMinecraftVersion())) {
                        latestInfoURL = version.getUrl();
                        break;
                    }
                }""",
        """                // Get the url for the latest version of the games manifest (with release fallback)
                String latestInfoURL = "";
                for (Version version : versionManifest.getVersions()) {
                    if (version.getId().equals(GameProtocol.getJavaMinecraftVersion())) {
                        latestInfoURL = version.getUrl();
                        break;
                    }
                }
                if (latestInfoURL.isEmpty() && versionManifest.getLatestVersion() != null) {
                    String fallbackRelease = versionManifest.getLatestVersion().getRelease();
                    for (Version version : versionManifest.getVersions()) {
                        if (version.getId().equals(fallbackRelease)) {
                            latestInfoURL = version.getUrl();
                            break;
                        }
                    }
                }""",
        "AssetUtils.generateAssetCacheFallback",
    )
    replace_exact(
        asset_utils,
        """            } catch (Exception e) {
                GeyserImpl.getInstance().getLogger().error(GeyserLocale.getLocaleStringLog("geyser.locale.fail.asset_cache", (!e.getMessage().isEmpty() ? e.getMessage() : e.getStackTrace())));
            }""",
        """            } catch (Exception e) {
                // Fail silently to debug if Mojang CDN is offline/blocked; bundled locales still work offline
                GeyserImpl.getInstance().getLogger().debug("Mojang asset index unavailable (using bundled locales): " + e.getMessage());
            }""",
        "AssetUtils.quietOfflineAssetIndex",
    )
    replace_exact(
        asset_utils,
        """    public static void downloadAndRunClientJarTasks() {
        if (CLIENT_JAR_INFO == null) {
            // Likely failed to download
            GeyserImpl.getInstance().getLogger().debug("Skipping en_US hash check as client jar is null.");
            return;
        }""",
        """    private static InputStream openServerOrBundledAsset(String assetPath) {
        String fileName = assetPath.substring(assetPath.lastIndexOf('/') + 1);
        InputStream stream = AssetUtils.class.getClassLoader().getResourceAsStream("purpurbedrock/locales/" + fileName);
        if (stream != null) {
            return stream;
        }
        stream = AssetUtils.class.getClassLoader().getResourceAsStream(assetPath);
        if (stream != null) {
            return stream;
        }
        try {
            Class<?> bukkitClass = Class.forName("org.bukkit.Bukkit");
            if (bukkitClass.getClassLoader() != null) {
                stream = bukkitClass.getClassLoader().getResourceAsStream(assetPath);
                if (stream != null) {
                    return stream;
                }
            }
            stream = bukkitClass.getResourceAsStream("/" + assetPath);
            if (stream != null) {
                return stream;
            }
        } catch (Throwable ignored) {
        }
        ClassLoader ctx = Thread.currentThread().getContextClassLoader();
        return ctx != null ? ctx.getResourceAsStream(assetPath) : null;
    }

    public static void downloadAndRunClientJarTasks() {
        if (Boolean.parseBoolean(System.getProperty("purpurbedrock.offlineAssets", "true")) || CLIENT_JAR_INFO == null) {
            ClientJarTask task;
            while ((task = CLIENT_JAR_TASKS.poll()) != null) {
                try {
                    InputStream classpathStream = openServerOrBundledAsset(task.asset);
                    if (classpathStream != null) {
                        try (InputStream in = classpathStream) {
                            task.ifNewDownload.accept(in);
                        }
                    }
                    task.whenDone.run();
                } catch (Exception ignored) {
                }
            }
            return;
        }""",
        "AssetUtils.downloadAndRunClientJarTasks",
    )

    minecraft_locale = root / "core/src/main/java/org/geysermc/geyser/text/MinecraftLocale.java"
    replace_exact(
        minecraft_locale,
        """    public static void ensureEN_US() {
        // en_us requires special treatment since it's included in Minecraft's JAR file
        Path localeFile = getPath("en_us");
        AssetUtils.addTask(!Files.exists(localeFile), new AssetUtils.ClientJarTask("assets/minecraft/lang/en_us.json",
                (stream) -> AssetUtils.saveFile(localeFile, stream),
                () -> loadLocale("en_us")));
    }""",
        """    private static volatile boolean purpurBundledLoaded = false;

    public static void ensureEN_US() {
        installBundledLocales();
        // en_us requires special treatment since it's included in Minecraft's JAR file
        Path localeFile = getPath("en_us");
        AssetUtils.addTask(!Files.exists(localeFile), new AssetUtils.ClientJarTask("assets/minecraft/lang/en_us.json",
                (stream) -> AssetUtils.saveFile(localeFile, stream),
                () -> loadLocale("en_us")));
    }

    private static synchronized void installBundledLocales() {
        if (purpurBundledLoaded && LOCALE_MAPPINGS.containsKey("ru_ru") && LOCALE_MAPPINGS.containsKey("en_us")) {
            return;
        }
        ClassLoader cl = MinecraftLocale.class.getClassLoader();
        // 1. Load deprecated.json directly from bundled JAR stream into REMOVED_KEYS & REPLACED_KEYS
        try {
            InputStream depIn = cl != null ? cl.getResourceAsStream("purpurbedrock/locales/deprecated.json") : null;
            if (depIn == null) {
                try {
                    Class<?> bukkitClass = Class.forName("org.bukkit.Bukkit");
                    if (bukkitClass.getClassLoader() != null) {
                        depIn = bukkitClass.getClassLoader().getResourceAsStream("assets/minecraft/lang/deprecated.json");
                    }
                } catch (Throwable ignored) {
                }
            }
            if (depIn != null) {
                try (InputStream stream = depIn) {
                    JsonObject localeObj = JsonUtils.fromJson(stream);
                    JsonElement removed = localeObj.get("removed");
                    if (removed != null && removed.isJsonArray()) {
                        for (JsonElement removedElement : removed.getAsJsonArray()) {
                            REMOVED_KEYS.add(removedElement.getAsString());
                        }
                    }
                    JsonElement renamed = localeObj.get("renamed");
                    if (renamed != null && renamed.isJsonObject()) {
                        for (Map.Entry<String, JsonElement> renamedElement : renamed.getAsJsonObject().entrySet()) {
                            REPLACED_KEYS.put(renamedElement.getKey(), renamedElement.getValue().getAsString());
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }

        // 2. Load en_us, ru_ru, uk_ua, be_by, kk_kz directly from JAR classpath into LOCALE_MAPPINGS in RAM
        //    AND repair any missing/truncated (< 150 KB) files on disk from earlier failed Mojang downloads!
        String[] langs = new String[]{"en_us", "ru_ru", "uk_ua", "be_by", "kk_kz"};
        for (String code : langs) {
            try {
                InputStream in = cl != null ? cl.getResourceAsStream("purpurbedrock/locales/" + code + ".json") : null;
                if (in == null && "en_us".equals(code)) {
                    try {
                        Class<?> bukkitClass = Class.forName("org.bukkit.Bukkit");
                        if (bukkitClass.getClassLoader() != null) {
                            in = bukkitClass.getClassLoader().getResourceAsStream("assets/minecraft/lang/en_us.json");
                        }
                    } catch (Throwable ignored) {
                    }
                }
                if (in != null) {
                    byte[] rawBytes;
                    try (InputStream stream = in) {
                        rawBytes = stream.readAllBytes();
                    }
                    if (LOCALE_FOLDER != null) {
                        Path target = getPath(code);
                        if (!Files.exists(target) || Files.size(target) < 150_000L) {
                            Files.write(target, rawBytes);
                        }
                    }
                    try (InputStream memStream = new java.io.ByteArrayInputStream(rawBytes)) {
                        JsonObject localeObj = JsonUtils.fromJson(memStream);
                        Map<String, String> langMap = new HashMap<>(8192);
                        for (Map.Entry<String, JsonElement> entry : localeObj.entrySet()) {
                            if (REMOVED_KEYS.contains(entry.getKey())) {
                                continue;
                            }
                            String val = entry.getValue().getAsString();
                            langMap.put(entry.getKey(), val);
                            String repl = REPLACED_KEYS.get(entry.getKey());
                            if (repl != null) {
                                langMap.put(repl, val);
                            }
                        }
                        if (LOCALE_FOLDER != null) {
                            Path overridePath = getPath("overrides/" + code);
                            if (Files.exists(overridePath) && Files.isReadable(overridePath)) {
                                langMap.putAll(parseLangFile(overridePath, code));
                            }
                        }
                        if (!langMap.isEmpty()) {
                            LOCALE_MAPPINGS.put(code, langMap);
                        }
                    }
                }
            } catch (Exception ignored) {
            }
        }
        purpurBundledLoaded = true;
    }""",
        "MinecraftLocale.installBundledLocales",
    )
    replace_exact(
        minecraft_locale,
        """    public static @Nullable String getLocaleStringIfPresent(String messageText, String locale) {
        Map<String, String> localeStrings = LOCALE_MAPPINGS.get(locale.toLowerCase(Locale.ROOT));
        if (localeStrings != null) {
            String translated = localeStrings.get(messageText);
            if (translated != null) {
                return translated;
            }
        }
        localeStrings = LOCALE_MAPPINGS.get("en_us");
        if (localeStrings != null) {
            return localeStrings.get(messageText);
        }
        return null;
    }""",
        """    public static @Nullable String getLocaleStringIfPresent(String messageText, String locale) {
        if (!purpurBundledLoaded) {
            installBundledLocales();
        }
        String normLocale = locale == null ? "ru_ru" : locale.toLowerCase(Locale.ROOT);
        if (!LOCALE_MAPPINGS.containsKey(normLocale) && LOCALE_FOLDER != null && Files.exists(getPath(normLocale))) {
            loadLocale(normLocale);
        }
        String mappedKey = REPLACED_KEYS.getOrDefault(messageText, messageText);
        Map<String, String> localeStrings = LOCALE_MAPPINGS.get(normLocale);
        if (localeStrings != null) {
            String translated = localeStrings.get(messageText);
            if (translated == null && !mappedKey.equals(messageText)) {
                translated = localeStrings.get(mappedKey);
            }
            if (translated != null) {
                return translated;
            }
        }
        if (!"ru_ru".equals(normLocale) && normLocale.startsWith("ru_")) {
            Map<String, String> ruStrings = LOCALE_MAPPINGS.get("ru_ru");
            if (ruStrings != null) {
                String translated = ruStrings.getOrDefault(messageText, ruStrings.get(mappedKey));
                if (translated != null) {
                    return translated;
                }
            }
        }
        localeStrings = LOCALE_MAPPINGS.get("en_us");
        if (localeStrings != null) {
            String translated = localeStrings.get(messageText);
            if (translated == null && !mappedKey.equals(messageText)) {
                translated = localeStrings.get(mappedKey);
            }
            if (translated != null) {
                return translated;
            }
        }
        return lookupLegacySpawnOrSystemKey(messageText, normLocale);
    }

    private static @Nullable String lookupLegacySpawnOrSystemKey(String key, String normLocale) {
        boolean isRu = normLocale.startsWith("ru") || normLocale.startsWith("be") || normLocale.startsWith("kk");
        boolean isUk = normLocale.startsWith("uk");
        return switch (key) {
            case "potion.withDuration" -> "%s (%s)";
            case "potion.withAmplifier" -> "%s %s";
            case "effect.duration.infinite" -> "∞";
            case "chat.type.advancement.task" -> isRu ? "%s получил достижение %s" : (isUk ? "%s здобув досягнення %s" : "%s has made the advancement %s");
            case "chat.type.advancement.challenge" -> isRu ? "%s выполнил испытание %s" : (isUk ? "%s виконав випробування %s" : "%s has completed the challenge %s");
            case "chat.type.advancement.goal" -> isRu ? "%s достиг цели %s" : (isUk ? "%s досяг мети %s" : "%s has reached the goal %s");
            case "block.minecraft.spawn.not_valid" -> isRu
                ? "У вас нет кровати или заряженного якоря возрождения, либо доступ к ним затруднён"
                : (isUk ? "У вас немає ліжка або зарядженого якоря відродження, або доступ до них перешкоджено"
                    : "You have no home bed or charged respawn anchor, or it was obstructed");
            default -> null;
        };
    }""",
        "MinecraftLocale.getLocaleStringIfPresent",
    )

    # 4. Backport the corrected BDS LAN status layouts from Cloudburst Network CR6.
    # The CR5 dependency bundled by the 26.2 engine only answers with obsolete layout v4,
    # while Bedrock 26.40-26.45 require v6 and 26.50-26.60 require v7. Keeping these
    # replacement classes in the project also avoids upgrading unrelated transport APIs.
    lan_backport_dir = Path(__file__).resolve().parent / "bedrock-lan"
    lan_package_dir = root / "core/src/main/java/org/cloudburstmc/netty/channel/nethernet/signaling"
    lan_package_dir.mkdir(parents=True, exist_ok=True)
    for lan_source in ("NetherNetDiscovery.java", "ServerData.java"):
        source = lan_backport_dir / lan_source
        if not source.is_file():
            raise RuntimeError(f"Missing Bedrock LAN backport source: {source}")
        (lan_package_dir / lan_source).write_bytes(source.read_bytes())
        print(f"Wrote Bedrock 26.60 LAN backport -> {lan_source}")

    # The 26.60 protocol connection build consumes the shared disconnect enum introduced
    # after the retained 26.2 transport build. Backport it to prevent disconnect-time
    # NoClassDefFoundError without replacing the stable RakNet/WebRTC implementation.
    disconnect_reason_source = lan_backport_dir / "TransportDisconnectReason.java"
    disconnect_reason_target = root / "core/src/main/java/org/cloudburstmc/netty/channel/TransportDisconnectReason.java"
    if not disconnect_reason_source.is_file():
        raise RuntimeError(f"Missing transport compatibility source: {disconnect_reason_source}")
    disconnect_reason_target.parent.mkdir(parents=True, exist_ok=True)
    disconnect_reason_target.write_bytes(disconnect_reason_source.read_bytes())
    print("Wrote Bedrock 26.60 transport compatibility -> TransportDisconnectReason.java")

    # Keep the internal Bukkit plugin identity for extension compatibility, but use the
    # Purpurbedrock prefix for all console messages and warnings.
    replace_exact(
        root / "bootstrap/spigot/src/main/resources/plugin.yml",
        """name: ${name}-Spigot
author: ${author}""",
        """name: ${name}-Spigot
prefix: Purpurbedrock
author: ${author}""",
        "GeyserSpigotPlugin.consolePrefix",
    )

    # 4a. NetherNetServer.java: keep internal nethernet temp dir in engineDir + add NetherNetDiscoverySignaling on UDP 7551
    nethernet_server = root / "core/src/main/java/org/geysermc/geyser/network/bedrock/nethernet/NetherNetServer.java"
    replace_exact(
        nethernet_server,
        """import org.cloudburstmc.netty.channel.nethernet.signaling.NetherNetHTTPServerSignaling;
import org.cloudburstmc.netty.channel.nethernet.signaling.NetherNetServerSignaling;""",
        """import org.cloudburstmc.netty.channel.nethernet.NetherNetConstants;
import org.cloudburstmc.netty.channel.nethernet.signaling.NetherNetDiscoverySignaling;
import org.cloudburstmc.netty.channel.nethernet.signaling.NetherNetHTTPServerSignaling;
import org.cloudburstmc.netty.channel.nethernet.signaling.NetherNetServerSignaling;""",
        "NetherNetServer.imports",
    )
    replace_exact(
        nethernet_server,
        """    private EventLoopGroup inbuiltEventLoopGroup;
    private Channel inbuiltChannel;
    private NetherNetChannelInitialiser inbuiltInitialiser;""",
        """    private EventLoopGroup inbuiltEventLoopGroup;
    private Channel inbuiltChannel;
    private NetherNetChannelInitialiser inbuiltInitialiser;
    private NetherNetDiscoverySignaling lanDiscoverySignaling;
    private EventLoopGroup lanDiscoveryEventLoopGroup;
    private Channel lanDiscoveryChannel;
    private NetherNetChannelInitialiser lanDiscoveryInitialiser;""",
        "NetherNetServer.fields",
    )
    replace_exact(
        nethernet_server,
        """        this.dataFolder = geyser.getBootstrap().getConfigFolder().resolve("nethernet");""",
        """        this.dataFolder = java.nio.file.Path.of(System.getProperty("purpurbedrock.engineDir", "cache/purpurbedrock/engine")).toAbsolutePath().resolve("nethernet");""",
        "NetherNetServer.dataFolder",
    )
    replace_exact(
        nethernet_server,
        """        if (inbuilt) startInbuilt();
        if (provider) startProvider();
    }""",
        """        if (inbuilt) startInbuilt();
        if (Boolean.parseBoolean(System.getProperty("purpurbedrock.lanDiscovery", "true"))) {
            startLanDiscovery();
        }
        if (provider) startProvider();
    }

    private PongData buildLanPongData() {
        BedrockPong pong = pingResponder.onQuery(GUID, new InetSocketAddress("127.0.0.1", 0), null);
        return new PongData.Builder()
                .setServerName(pong.motd() != null ? pong.motd() : "Purpurbedrock 26.2")
                .setLevelName(pong.subMotd() != null ? pong.subMotd() : "Purpurbedrock LAN")
                .setProtocol(pong.protocolVersion())
                .setVersion(pong.version())
                // Bedrock 26.60 hides a LAN world advertised with zero players. A dedicated
                // server has no players before the first join, so advertise one discovery
                // participant while retaining the real online count everywhere else.
                .setPlayerCount(Math.max(1, pong.playerCount()))
                .setMaxPlayerCount(Math.max(1, pong.maximumPlayerCount()))
                .build();
    }

    private void startLanDiscovery() {
        BedrockListener listener = geyser.config().bedrock();
        int discoveryPort = Integer.getInteger("purpurbedrock.lanDiscoveryPort", NetherNetConstants.DISCOVERY_PORT);
        int lanIcePort = Integer.getInteger("purpurbedrock.lanIcePort", webrtcPort + 1);
        try {
            NetherNetLogging.setNativeLogLevel("WARN");
            InetSocketAddress bindAddr = new InetSocketAddress(listener.address(), discoveryPort);
            this.lanDiscoverySignaling = new NetherNetDiscoverySignaling(GUID ^ 0x4C414EL, bindAddr);
            this.lanDiscoverySignaling.setAdvertisementData(buildLanPongData());

            this.lanDiscoveryEventLoopGroup = new MultiThreadIoEventLoopGroup(NioIoHandler.newFactory());
            this.lanDiscoveryInitialiser = new NetherNetChannelInitialiser(geyser);

            ServerBootstrap lanBootstrap = new ServerBootstrap()
                    .group(this.lanDiscoveryEventLoopGroup)
                    .channelFactory(NetherNetChannelFactory.server(this.lanDiscoverySignaling))
                    .childHandler(this.lanDiscoveryInitialiser)
                    .option(NetherChannelOption.NETHER_SERVER_ICE_ADDRESS, new InetSocketAddress(listener.address(), lanIcePort));

            this.lanDiscoveryChannel = lanBootstrap.bind(bindAddr).sync().channel();
            this.lanDiscoveryEventLoopGroup.next().scheduleAtFixedRate(() -> {
                if (!stopping && this.lanDiscoverySignaling != null) {
                    try {
                        this.lanDiscoverySignaling.setAdvertisementData(buildLanPongData());
                    } catch (Throwable ignored) {
                    }
                }
            }, 3, 3, TimeUnit.SECONDS);

            logger().info("[Purpurbedrock] NetherNet LAN Discovery active on UDP " + listener.address() + ":" + discoveryPort
                    + " (LAN ICE UDP " + lanIcePort + ") — server visible in Bedrock 'Миры' LAN tab.");
        } catch (Throwable e) {
            closeLanDiscoveryResources();
            logger().info("[Purpurbedrock] NetherNet LAN UDP " + discoveryPort + " unavailable (" + e.getClass().getSimpleName()
                    + "); RakNet/Signaling remains active.");
        }
    }

    private void closeLanDiscoveryResources() {
        if (lanDiscoveryChannel != null) {
            try { lanDiscoveryChannel.close(); } catch (Throwable ignored) {}
            lanDiscoveryChannel = null;
        }
        if (lanDiscoverySignaling != null) {
            try { lanDiscoverySignaling.close(); } catch (Throwable ignored) {}
            lanDiscoverySignaling = null;
        }
        if (lanDiscoveryEventLoopGroup != null) {
            lanDiscoveryEventLoopGroup.shutdownGracefully(0, 1, TimeUnit.SECONDS);
            lanDiscoveryEventLoopGroup = null;
        }
        if (lanDiscoveryInitialiser != null) {
            lanDiscoveryInitialiser.getEventLoopGroup().shutdownGracefully(0, 1, TimeUnit.SECONDS);
            lanDiscoveryInitialiser = null;
        }
    }""",
        "NetherNetServer.startLanDiscovery",
    )
    replace_exact(
        nethernet_server,
        """    private void closeInbuiltResources() {
        if (inbuiltChannel != null) inbuiltChannel.close();
        if (signaling != null) signaling.close();
        if (inbuiltEventLoopGroup != null) inbuiltEventLoopGroup.shutdownGracefully();
        if (inbuiltInitialiser != null) inbuiltInitialiser.getEventLoopGroup().shutdownGracefully();
    }""",
        """    private void closeInbuiltResources() {
        if (inbuiltChannel != null) inbuiltChannel.close();
        if (signaling != null) signaling.close();
        if (inbuiltEventLoopGroup != null) inbuiltEventLoopGroup.shutdownGracefully(0, 1, TimeUnit.SECONDS);
        if (inbuiltInitialiser != null) inbuiltInitialiser.getEventLoopGroup().shutdownGracefully(0, 1, TimeUnit.SECONDS);
        closeLanDiscoveryResources();
    }""",
        "NetherNetServer.closeInbuiltResources",
    )

    # 5. BedrockPacketViolationWarningTranslator & InvalidPacketHandler: never kick players for benign warnings
    violation_translator = root / "core/src/main/java/org/geysermc/geyser/translator/protocol/bedrock/BedrockPacketViolationWarningTranslator.java"
    replace_exact(
        violation_translator,
        """        logger.warning("Received packet violation warning (type: %s, severity: %s, packetCauseId: %s) from client (%s): %s! Enable debug mode for the full message.".formatted(packet.getType(),
            packet.getSeverity(), packet.getPacketCauseId(), session.bedrockUsername(), sanitize(message)));
        session.disconnect("An error occurred! Please contact an administrator.");""",
        """        logger.debug("Ignored packet violation warning (type: %s, severity: %s, packetCauseId: %s) from client (%s): %s".formatted(packet.getType(),
            packet.getSeverity(), packet.getPacketCauseId(), session.bedrockUsername(), sanitize(message)));
        // Purpurbedrock: do not kick Bedrock players on non-fatal client packet warnings""",
        "BedrockPacketViolationWarningTranslator",
    )

    invalid_packet = root / "core/src/main/java/org/geysermc/geyser/network/bedrock/InvalidPacketHandler.java"
    replace_exact(
        invalid_packet,
        """        // Kick users that try to send illegal packets
        logger.error("Illegal packet from " + session.bedrockUsername(), cause);
        session.disconnect("Invalid packet received!");
        session.forciblyCloseUpstream();""",
        """        // Purpurbedrock: ignore recoverable malformed/unsupported packets instead of disconnecting
        logger.debug("Ignored unsupported/malformed Bedrock packet from " + session.bedrockUsername() + ": " + rootCause.getMessage());""",
        "InvalidPacketHandler",
    )

    # 6. Dedicated root folder ('bedrock/') for cache, custom_mappings, extensions, and packs
    geyser_impl = root / "core/src/main/java/org/geysermc/geyser/GeyserImpl.java"
    replace_exact(
        geyser_impl,
        """    @Override
    @NonNull
    public Path configDirectory() {
        return bootstrap.getConfigFolder();
    }

    @Override
    @NonNull
    public Path packDirectory() {
        return bootstrap.getConfigFolder().resolve("packs");
    }""",
        """    @Override
    @NonNull
    public Path configDirectory() {
        return Path.of(System.getProperty("purpurbedrock.dataDir", "bedrock")).toAbsolutePath();
    }

    @Override
    @NonNull
    public Path packDirectory() {
        return Path.of(System.getProperty("purpurbedrock.dataDir", "bedrock")).toAbsolutePath().resolve("packs");
    }""",
        "GeyserImpl.configAndPackDirectory",
    )

    ext_loader = root / "core/src/main/java/org/geysermc/geyser/extension/GeyserExtensionLoader.java"
    replace_exact(
        ext_loader,
        """    private final Path extensionsDirectory = GeyserImpl.getInstance().getBootstrap().getConfigFolder().resolve("extensions");""",
        """    private final Path extensionsDirectory = Path.of(System.getProperty("purpurbedrock.dataDir", "bedrock")).toAbsolutePath().resolve("extensions");""",
        "GeyserExtensionLoader.extensionsDirectory",
    )

    mappings_reader = root / "core/src/main/java/org/geysermc/geyser/registry/mappings/MappingsConfigReader.java"
    replace_exact(
        mappings_reader,
        """        Path customMappingsDirectory = GeyserImpl.getInstance().getBootstrap().getConfigFolder().resolve("custom_mappings");""",
        """        Path customMappingsDirectory = Path.of(System.getProperty("purpurbedrock.dataDir", "bedrock")).toAbsolutePath().resolve("custom_mappings");""",
        "MappingsConfigReader.customMappingsDirectory",
    )

    # 7. HeadDatabase / player_skulls cache support:
    #    - Auto-register any pre-cached <skinHash>.png textures in bedrock/cache/player_skulls/
    #      so HeadDatabase skulls render in 3D on Bedrock without requiring manual JSON lists.
    #    - Eagerly ensure bedrock/cache/player_skulls exists and never wipe cached .png textures.
    skull_populator = root / "core/src/main/java/org/geysermc/geyser/registry/populator/CustomSkullRegistryPopulator.java"
    replace_exact(
        skull_populator,
        """        profiles.forEach((profile) -> {
            String skinHash = getSkinHash(profile);
            if (skinHash != null) {
                skinHashes.add(skinHash);
            }
        });""",
        """        profiles.forEach((profile) -> {
            String skinHash = getSkinHash(profile);
            if (skinHash != null) {
                skinHashes.add(skinHash);
            }
        });

        // Purpurbedrock: auto-discover pre-cached HeadDatabase skull PNGs in bedrock/cache/player_skulls/,
        // capped strictly to maxStaticSkulls (default 8 = 168 states) so mobile phones (e.g. Galaxy A07)
        // never crash or freeze from 30,000+ CustomSkull VoxelShapes/Molang permutations in StartGamePacket!
        int maxStaticSkulls = Math.max(0, Integer.getInteger("purpurbedrock.maxCachedCustomSkulls", 8));
        Path cachedSkullsDir = GeyserImpl.getInstance().getBootstrap().getConfigFolder().resolve("cache").resolve("player_skulls");
        try {
            Files.createDirectories(cachedSkullsDir);
            int remainingBudget = Math.max(0, maxStaticSkulls - skinHashes.size());
            if (remainingBudget > 0) {
                java.util.HashSet<String> seenHashes = new java.util.HashSet<>(skinHashes);
                java.util.ArrayList<Path> candidateFiles = new java.util.ArrayList<>();
                try (java.util.stream.Stream<Path> cachedFiles = Files.list(cachedSkullsDir)) {
                    cachedFiles.forEach(file -> {
                        String fileName = file.getFileName().toString();
                        if (Files.isRegularFile(file) && fileName.endsWith(".png") && fileName.length() > 4) {
                            String candidateHash = fileName.substring(0, fileName.length() - 4);
                            if (SKULL_HASH_PATTERN.matcher(candidateHash).matches() && !seenHashes.contains(candidateHash)) {
                                candidateFiles.add(file);
                            }
                        }
                    });
                }
                if (candidateFiles.size() > remainingBudget) {
                    candidateFiles.sort((a, b) -> {
                        try {
                            return Files.getLastModifiedTime(b).compareTo(Files.getLastModifiedTime(a));
                        } catch (IOException ex) {
                            return 0;
                        }
                    });
                }
                int addedAuto = 0;
                for (Path file : candidateFiles) {
                    if (addedAuto >= remainingBudget) {
                        break;
                    }
                    String fileName = file.getFileName().toString();
                    String candidateHash = fileName.substring(0, fileName.length() - 4);
                    if (seenHashes.add(candidateHash)) {
                        skinHashes.add(candidateHash);
                        addedAuto++;
                    }
                }
            }
        } catch (IOException ignored) {
        }
        if (skinHashes.size() > maxStaticSkulls) {
            int droppedCount = skinHashes.size() - maxStaticSkulls;
            skinHashes.subList(maxStaticSkulls, skinHashes.size()).clear();
            GeyserImpl.getInstance().getLogger().info(
                "Capped static custom skull blocks to " + maxStaticSkulls + " (deferred " + droppedCount
                + " skulls to dynamic SkullCache to prevent mobile Bedrock client crashes)."
            );
        }""",
        "CustomSkullRegistryPopulator.autoDiscoverPlayerSkulls",
    )

    skull_pack_mgr = root / "core/src/main/java/org/geysermc/geyser/pack/SkullResourcePackManager.java"
    replace_exact(
        skull_pack_mgr,
        """        try {
            Files.createDirectories(cachePath);
        } catch (IOException e) {""",
        """        try {
            Files.createDirectories(cachePath);
            Files.createDirectories(SKULL_SKIN_CACHE_PATH);
        } catch (IOException e) {""",
        "SkullResourcePackManager.ensurePlayerSkullsDir",
    )
    replace_exact(
        skull_pack_mgr,
        """    public static void cleanSkullSkinCache() {
        // No need to clean up if skin cache does not exist
        if (!Files.exists(SKULL_SKIN_CACHE_PATH)) {
            return;
        }""",
        """    public static void cleanSkullSkinCache() {
        // Purpurbedrock: preserve pre-cached HeadDatabase player_skulls/*.png textures across restarts
        if (Boolean.parseBoolean(System.getProperty("purpurbedrock.preserveSkullCache", "true"))) {
            return;
        }
        // No need to clean up if skin cache does not exist
        if (!Files.exists(SKULL_SKIN_CACHE_PATH)) {
            return;
        }""",
        "SkullResourcePackManager.preserveHeadDatabaseCache",
    )


    # 8. DialogHolder: remove the 'gui.waitingForResponse.title' waiting popup window
    dialog_holder = root / "core/src/main/java/org/geysermc/geyser/session/dialog/DialogHolder.java"
    replace_exact(
        dialog_holder,
        """            case WAIT_FOR_RESPONSE -> {
                // If no new dialog was opened, open a form telling the user we're waiting on a response from the server
                // This dialog is replaced with a similar form with a "back" button after 5 seconds, matching Java behaviour
                responseWaitTime = System.currentTimeMillis();
                sendBackButton = false;
                waitForResponse();
            }""",
        """            case WAIT_FOR_RESPONSE -> {
                // Purpurbedrock: close the dialog cleanly without showing the intrusive waiting popup;
                // if the server subsequently sends a follow-up dialog or chest GUI, it opens directly.
                manager.close();
            }""",
        "DialogHolder.suppressWaitForResponseAfterAction",
    )
    replace_exact(
        dialog_holder,
        """    private void waitForResponse() {
        String content;
        if (sendBackButton) {
            content = GeyserLocale.getPlayerLocaleString("geyser.dialogs.waiting_for_a_while", session.locale());
        } else {
            content = GeyserLocale.getPlayerLocaleString("geyser.dialogs.waiting_for_response", session.locale());
        }

        session.sendDialogForm(SimpleForm.builder()
            .translator(MinecraftLocale::getLocaleString, session.locale())
            .title("gui.waitingForResponse.title")
            .content(content)
            .optionalButton("gui.back", sendBackButton)
            .closedOrInvalidResultHandler(() -> {
                if (stillValid()) { // If still waiting on a new dialog
                    waitForResponse();
                }
            })
            .validResultHandler(response -> manager.close()) // Back button was pressed, meaning no new dialog was sent
            .build());
    }""",
        """    private void waitForResponse() {
        manager.close();
    }""",
        "DialogHolder.removeWaitForResponseForm",
    )

    # 9. Full Bedrock Multi-Version (1.21.0 v685 -> 26.60 v2225)
    extract_historical_git_assets(root)

    mv_helper_path = root / "core/src/main/java/org/geysermc/geyser/registry/populator/MultiVersionPaletteHelper.java"
    mv_helper_path.write_text(MULTI_VERSION_HELPER_JAVA, encoding="utf-8")
    print(f"Wrote MultiVersionPaletteHelper.java -> {mv_helper_path.name}")

    # 9a. GameProtocol: register all 24 Bedrock codecs (1.21.0 through 26.60)
    game_protocol = root / "core/src/main/java/org/geysermc/geyser/network/bedrock/GameProtocol.java"
    replace_exact(
        game_protocol,
        """import org.cloudburstmc.protocol.bedrock.codec.BedrockCodec;
import org.cloudburstmc.protocol.bedrock.codec.v1001.Bedrock_v1001;
import org.cloudburstmc.protocol.bedrock.codec.v2168.Bedrock_v2168;
import org.cloudburstmc.protocol.bedrock.codec.v2168.Bedrock_v2168_hotfix4;
import org.cloudburstmc.protocol.bedrock.codec.v2169.Bedrock_v2169;
import org.cloudburstmc.protocol.bedrock.codec.v2193.Bedrock_v2193;""",
        """import org.cloudburstmc.protocol.bedrock.codec.BedrockCodec;
import org.cloudburstmc.protocol.bedrock.codec.v685.Bedrock_v685;
import org.cloudburstmc.protocol.bedrock.codec.v686.Bedrock_v686;
import org.cloudburstmc.protocol.bedrock.codec.v712.Bedrock_v712;
import org.cloudburstmc.protocol.bedrock.codec.v729.Bedrock_v729;
import org.cloudburstmc.protocol.bedrock.codec.v748.Bedrock_v748;
import org.cloudburstmc.protocol.bedrock.codec.v766.Bedrock_v766;
import org.cloudburstmc.protocol.bedrock.codec.v776.Bedrock_v776;
import org.cloudburstmc.protocol.bedrock.codec.v786.Bedrock_v786;
import org.cloudburstmc.protocol.bedrock.codec.v800.Bedrock_v800;
import org.cloudburstmc.protocol.bedrock.codec.v818.Bedrock_v818;
import org.cloudburstmc.protocol.bedrock.codec.v819.Bedrock_v819;
import org.cloudburstmc.protocol.bedrock.codec.v827.Bedrock_v827;
import org.cloudburstmc.protocol.bedrock.codec.v844.Bedrock_v844;
import org.cloudburstmc.protocol.bedrock.codec.v859.Bedrock_v859;
import org.cloudburstmc.protocol.bedrock.codec.v860.Bedrock_v860;
import org.cloudburstmc.protocol.bedrock.codec.v898.Bedrock_v898;
import org.cloudburstmc.protocol.bedrock.codec.v924.Bedrock_v924;
import org.cloudburstmc.protocol.bedrock.codec.v944.Bedrock_v944;
import org.cloudburstmc.protocol.bedrock.codec.v975.Bedrock_v975;
import org.cloudburstmc.protocol.bedrock.codec.v1001.Bedrock_v1001;
import org.cloudburstmc.protocol.bedrock.codec.v2168.Bedrock_v2168;
import org.cloudburstmc.protocol.bedrock.codec.v2168.Bedrock_v2168_hotfix4;
import org.cloudburstmc.protocol.bedrock.codec.v2169.Bedrock_v2169;
import org.cloudburstmc.protocol.bedrock.codec.v2193.Bedrock_v2193;
import org.cloudburstmc.protocol.bedrock.codec.v2225.Bedrock_v2225;""",
        "GameProtocol.imports",
    )
    replace_exact(
        game_protocol,
        """        // Strict ordering
        register(Bedrock_v1001.CODEC, "26.30", "26.31", "26.32", "26.33", "26.34");
        register(Bedrock_v2168_hotfix4.CODEC, "26.40", "26.41", "26.42", "26.43", "26.44");
        register(Bedrock_v2169.CODEC, "26.45");
        register(Bedrock_v2193.CODEC, "26.50", "26.51", "26.52");""",
        """        // Strict ascending protocol ordering: Bedrock 1.21.0 (v685) -> 26.60 (v2225)
        register(Bedrock_v685.CODEC, "1.21.0", "1.21.1");
        register(Bedrock_v686.CODEC, "1.21.2", "1.21.3");
        register(Bedrock_v712.CODEC, "1.21.20", "1.21.21", "1.21.22", "1.21.23");
        register(Bedrock_v729.CODEC, "1.21.30", "1.21.31");
        register(Bedrock_v748.CODEC, "1.21.40", "1.21.41", "1.21.43", "1.21.44");
        register(Bedrock_v766.CODEC, "1.21.50", "1.21.51");
        register(Bedrock_v776.CODEC, "1.21.60", "1.21.61", "1.21.62");
        register(Bedrock_v786.CODEC, "1.21.70", "1.21.71", "1.21.72", "1.21.73");
        register(Bedrock_v800.CODEC, "1.21.80", "1.21.81", "1.21.82", "1.21.83", "1.21.84");
        register(Bedrock_v818.CODEC, "1.21.90", "1.21.91", "1.21.92");
        register(Bedrock_v819.CODEC, "1.21.93", "1.21.94");
        register(Bedrock_v827.CODEC, "1.21.100", "1.21.101");
        register(Bedrock_v844.CODEC, "1.21.110", "1.21.111", "1.21.112", "1.21.113", "1.21.114");
        register(Bedrock_v859.CODEC, "1.21.120", "1.21.121", "1.21.122", "1.21.123");
        register(Bedrock_v860.CODEC, "1.21.124");
        register(Bedrock_v898.CODEC, "1.21.130", "1.21.131", "1.21.132");
        register(Bedrock_v924.CODEC, "26.0", "26.1", "26.2", "26.3");
        register(Bedrock_v944.CODEC, "26.10", "26.11", "26.12");
        register(Bedrock_v975.CODEC, "26.20", "26.21", "26.22", "26.23");
        register(Bedrock_v1001.CODEC, "26.30", "26.31", "26.32", "26.33", "26.34");
        register(Bedrock_v2168_hotfix4.CODEC, "26.40", "26.41", "26.42", "26.43", "26.44");
        register(Bedrock_v2169.CODEC, "26.45");
        register(Bedrock_v2193.CODEC, "26.50", "26.51", "26.52");
        register(Bedrock_v2225.CODEC, "26.60");""",
        "GameProtocol.registerAllVersions",
    )

    # 9b. CodecProcessor: exact packet serializer ladder across v685..v2225
    codec_processor = root / "core/src/main/java/org/geysermc/geyser/network/bedrock/CodecProcessor.java"
    replace_exact(
        codec_processor,
        """import org.cloudburstmc.protocol.bedrock.codec.v291.serializer.MobEquipmentSerializer_v291;
import org.cloudburstmc.protocol.bedrock.codec.v291.serializer.MoveEntityAbsoluteSerializer_v291;
import org.cloudburstmc.protocol.bedrock.codec.v291.serializer.PlayerHotbarSerializer_v291;
import org.cloudburstmc.protocol.bedrock.codec.v291.serializer.SetEntityLinkSerializer_v291;
import org.cloudburstmc.protocol.bedrock.codec.v390.serializer.PlayerSkinSerializer_v390;
import org.cloudburstmc.protocol.bedrock.codec.v419.serializer.MovePlayerSerializer_v419;
import org.cloudburstmc.protocol.bedrock.codec.v557.serializer.SetEntityDataSerializer_v557;
import org.cloudburstmc.protocol.bedrock.codec.v662.serializer.SetEntityMotionSerializer_v662;
import org.cloudburstmc.protocol.bedrock.codec.v712.serializer.MobArmorEquipmentSerializer_v712;
import org.cloudburstmc.protocol.bedrock.codec.v748.serializer.InventoryContentSerializer_v748;
import org.cloudburstmc.protocol.bedrock.codec.v748.serializer.InventorySlotSerializer_v748;""",
        """import org.cloudburstmc.protocol.bedrock.codec.v291.serializer.MobArmorEquipmentSerializer_v291;
import org.cloudburstmc.protocol.bedrock.codec.v291.serializer.MobEquipmentSerializer_v291;
import org.cloudburstmc.protocol.bedrock.codec.v291.serializer.MoveEntityAbsoluteSerializer_v291;
import org.cloudburstmc.protocol.bedrock.codec.v291.serializer.PlayerHotbarSerializer_v291;
import org.cloudburstmc.protocol.bedrock.codec.v291.serializer.SetEntityLinkSerializer_v291;
import org.cloudburstmc.protocol.bedrock.codec.v390.serializer.PlayerSkinSerializer_v390;
import org.cloudburstmc.protocol.bedrock.codec.v407.serializer.InventoryContentSerializer_v407;
import org.cloudburstmc.protocol.bedrock.codec.v407.serializer.InventorySlotSerializer_v407;
import org.cloudburstmc.protocol.bedrock.codec.v419.serializer.MovePlayerSerializer_v419;
import org.cloudburstmc.protocol.bedrock.codec.v486.serializer.BossEventSerializer_v486;
import org.cloudburstmc.protocol.bedrock.codec.v557.serializer.SetEntityDataSerializer_v557;
import org.cloudburstmc.protocol.bedrock.codec.v662.serializer.SetEntityMotionSerializer_v662;
import org.cloudburstmc.protocol.bedrock.codec.v712.serializer.InventoryContentSerializer_v712;
import org.cloudburstmc.protocol.bedrock.codec.v712.serializer.InventorySlotSerializer_v712;
import org.cloudburstmc.protocol.bedrock.codec.v712.serializer.MobArmorEquipmentSerializer_v712;
import org.cloudburstmc.protocol.bedrock.codec.v729.serializer.InventoryContentSerializer_v729;
import org.cloudburstmc.protocol.bedrock.codec.v729.serializer.InventorySlotSerializer_v729;
import org.cloudburstmc.protocol.bedrock.codec.v748.serializer.InventoryContentSerializer_v748;
import org.cloudburstmc.protocol.bedrock.codec.v748.serializer.InventorySlotSerializer_v748;
import org.cloudburstmc.protocol.bedrock.codec.v776.serializer.BossEventSerializer_v776;
import org.cloudburstmc.protocol.bedrock.packet.PlayerInputPacket;
import org.cloudburstmc.protocol.bedrock.packet.RiderJumpPacket;""",
        "CodecProcessor.imports",
    )
    replace_exact(
        codec_processor,
        """    private static final BedrockPacketSerializer<InventoryContentPacket> INVENTORY_CONTENT_SERIALIZER_V748 = new InventoryContentSerializer_v748() {
        @Override
        public void deserialize(ByteBuf buffer, BedrockCodecHelper helper, InventoryContentPacket packet) {
            throw new IllegalPacketException("Client cannot send InventoryContentPacket in server-auth inventory environment!");
        }
    };""",
        """    private static final BedrockPacketSerializer<InventoryContentPacket> INVENTORY_CONTENT_SERIALIZER_V407 = new InventoryContentSerializer_v407() {
        @Override
        public void deserialize(ByteBuf buffer, BedrockCodecHelper helper, InventoryContentPacket packet) {
            throw new IllegalPacketException("Client cannot send InventoryContentPacket in server-auth inventory environment!");
        }
    };

    private static final BedrockPacketSerializer<InventoryContentPacket> INVENTORY_CONTENT_SERIALIZER_V712 = new InventoryContentSerializer_v712() {
        @Override
        public void deserialize(ByteBuf buffer, BedrockCodecHelper helper, InventoryContentPacket packet) {
            throw new IllegalPacketException("Client cannot send InventoryContentPacket in server-auth inventory environment!");
        }
    };

    private static final BedrockPacketSerializer<InventoryContentPacket> INVENTORY_CONTENT_SERIALIZER_V729 = new InventoryContentSerializer_v729() {
        @Override
        public void deserialize(ByteBuf buffer, BedrockCodecHelper helper, InventoryContentPacket packet) {
            throw new IllegalPacketException("Client cannot send InventoryContentPacket in server-auth inventory environment!");
        }
    };

    private static final BedrockPacketSerializer<InventoryContentPacket> INVENTORY_CONTENT_SERIALIZER_V748 = new InventoryContentSerializer_v748() {
        @Override
        public void deserialize(ByteBuf buffer, BedrockCodecHelper helper, InventoryContentPacket packet) {
            throw new IllegalPacketException("Client cannot send InventoryContentPacket in server-auth inventory environment!");
        }
    };

    private static final BedrockPacketSerializer<InventorySlotPacket> INVENTORY_SLOT_SERIALIZER_V407 = new InventorySlotSerializer_v407() {
        @Override
        public void deserialize(ByteBuf buffer, BedrockCodecHelper helper, InventorySlotPacket packet) {
            throw new IllegalPacketException("Client cannot send InventorySlotPacket in server-auth inventory environment!");
        }
    };

    private static final BedrockPacketSerializer<InventorySlotPacket> INVENTORY_SLOT_SERIALIZER_V712 = new InventorySlotSerializer_v712() {
        @Override
        public void deserialize(ByteBuf buffer, BedrockCodecHelper helper, InventorySlotPacket packet) {
            throw new IllegalPacketException("Client cannot send InventorySlotPacket in server-auth inventory environment!");
        }
    };

    private static final BedrockPacketSerializer<InventorySlotPacket> INVENTORY_SLOT_SERIALIZER_V729 = new InventorySlotSerializer_v729() {
        @Override
        public void deserialize(ByteBuf buffer, BedrockCodecHelper helper, InventorySlotPacket packet) {
            throw new IllegalPacketException("Client cannot send InventorySlotPacket in server-auth inventory environment!");
        }
    };

    private static final BedrockPacketSerializer<BossEventPacket> BOSS_EVENT_SERIALIZER_V486 = new BossEventSerializer_v486() {
        @Override
        public void deserialize(ByteBuf buffer, BedrockCodecHelper helper, BossEventPacket packet) {
        }
    };

    private static final BedrockPacketSerializer<BossEventPacket> BOSS_EVENT_SERIALIZER_V776 = new BossEventSerializer_v776() {
        @Override
        public void deserialize(ByteBuf buffer, BedrockCodecHelper helper, BossEventPacket packet) {
        }
    };

    private static final BedrockPacketSerializer<MobArmorEquipmentPacket> MOB_ARMOR_EQUIPMENT_SERIALIZER_V291 = new MobArmorEquipmentSerializer_v291() {
        @Override
        public void deserialize(ByteBuf buffer, BedrockCodecHelper helper, MobArmorEquipmentPacket packet) {
        }
    };""",
        "CodecProcessor.serializers",
    )
    replace_exact(
        codec_processor,
        """        if (codec.getProtocolVersion() < 975) { // 26.20
            codecBuilder.updateSerializer(InventorySlotPacket.class, INVENTORY_SLOT_SERIALIZER_V748);
            codecBuilder.updateSerializer(MoveEntityAbsolutePacket.class, MOVE_ENTITY_SERIALIZER_V291);
            // Valid serverbound packets where reading of some fields can be skipped
            codecBuilder.updateSerializer(MobEquipmentPacket.class, MOB_EQUIPMENT_SERIALIZER_V291);
        } else {
            codecBuilder.updateSerializer(InventorySlotPacket.class, INVENTORY_SLOT_SERIALIZER_V975);
            codecBuilder.updateSerializer(MoveEntityAbsolutePacket.class, MOVE_ENTITY_SERIALIZER_V975);
            codecBuilder.updateSerializer(MobEquipmentPacket.class, MOB_EQUIPMENT_SERIALIZER_V975);
        }

        if (codec.getProtocolVersion() < 1001) { // 26.30
            codecBuilder.updateSerializer(MobArmorEquipmentPacket.class, MOB_ARMOR_EQUIPMENT_SERIALIZER_V712);
            codecBuilder.updateSerializer(InventoryContentPacket.class, INVENTORY_CONTENT_SERIALIZER_V748);
        } else {
            codecBuilder.updateSerializer(MobArmorEquipmentPacket.class, MOB_ARMOR_EQUIPMENT_SERIALIZER_V1001);
            codecBuilder.updateSerializer(InventoryContentPacket.class, INVENTORY_CONTENT_SERIALIZER_V1001);
        }

        if (codec.getProtocolVersion() < 2168) { // 26.40
            // Illegal when serverbound due to Geyser specific setup
            codecBuilder.updateSerializer(MovePlayerPacket.class, MOVE_PLAYER_SERIALIZER_V419);
            codecBuilder.updateSerializer(PlayerSkinPacket.class, PLAYER_SKIN_SERIALIZER_V390);
        } else {
            codecBuilder.updateSerializer(MovePlayerPacket.class, MOVE_PLAYER_SERIALIZER_V2168);
            codecBuilder.updateSerializer(PlayerSkinPacket.class, PLAYER_SKIN_SERIALIZER_V2168);
        }

        if (codec.getProtocolVersion() < 2193) { // 26.50
            codecBuilder.updateSerializer(BossEventPacket.class, BOSS_EVENT_SERIALIZER_V1001);
        } else {
            codecBuilder.updateSerializer(BossEventPacket.class, BOSS_EVENT_SERIALIZER_V2193);
        }""",
        """        int proto = codec.getProtocolVersion();

        if (proto < 800) { // Removed in 1.21.80
            codecBuilder.updateSerializer(RiderJumpPacket.class, IGNORED_SERIALIZER);
            codecBuilder.updateSerializer(PlayerInputPacket.class, IGNORED_SERIALIZER);
        }

        if (proto >= 975) { // 26.20+
            codecBuilder.updateSerializer(InventorySlotPacket.class, INVENTORY_SLOT_SERIALIZER_V975);
            codecBuilder.updateSerializer(MoveEntityAbsolutePacket.class, MOVE_ENTITY_SERIALIZER_V975);
            codecBuilder.updateSerializer(MobEquipmentPacket.class, MOB_EQUIPMENT_SERIALIZER_V975);
        } else {
            codecBuilder.updateSerializer(MoveEntityAbsolutePacket.class, MOVE_ENTITY_SERIALIZER_V291);
            codecBuilder.updateSerializer(MobEquipmentPacket.class, MOB_EQUIPMENT_SERIALIZER_V291);
            if (proto >= 748) {
                codecBuilder.updateSerializer(InventorySlotPacket.class, INVENTORY_SLOT_SERIALIZER_V748);
            } else if (proto >= 729) {
                codecBuilder.updateSerializer(InventorySlotPacket.class, INVENTORY_SLOT_SERIALIZER_V729);
            } else if (proto >= 712) {
                codecBuilder.updateSerializer(InventorySlotPacket.class, INVENTORY_SLOT_SERIALIZER_V712);
            } else {
                codecBuilder.updateSerializer(InventorySlotPacket.class, INVENTORY_SLOT_SERIALIZER_V407);
            }
        }

        if (proto >= 1001) { // 26.30+
            codecBuilder.updateSerializer(MobArmorEquipmentPacket.class, MOB_ARMOR_EQUIPMENT_SERIALIZER_V1001);
            codecBuilder.updateSerializer(InventoryContentPacket.class, INVENTORY_CONTENT_SERIALIZER_V1001);
        } else {
            codecBuilder.updateSerializer(
                MobArmorEquipmentPacket.class,
                proto >= 712 ? MOB_ARMOR_EQUIPMENT_SERIALIZER_V712 : MOB_ARMOR_EQUIPMENT_SERIALIZER_V291
            );
            if (proto >= 748) {
                codecBuilder.updateSerializer(InventoryContentPacket.class, INVENTORY_CONTENT_SERIALIZER_V748);
            } else if (proto >= 729) {
                codecBuilder.updateSerializer(InventoryContentPacket.class, INVENTORY_CONTENT_SERIALIZER_V729);
            } else if (proto >= 712) {
                codecBuilder.updateSerializer(InventoryContentPacket.class, INVENTORY_CONTENT_SERIALIZER_V712);
            } else {
                codecBuilder.updateSerializer(InventoryContentPacket.class, INVENTORY_CONTENT_SERIALIZER_V407);
            }
        }

        if (proto < 2168) { // < 26.40
            codecBuilder.updateSerializer(MovePlayerPacket.class, MOVE_PLAYER_SERIALIZER_V419);
            codecBuilder.updateSerializer(PlayerSkinPacket.class, PLAYER_SKIN_SERIALIZER_V390);
        } else {
            codecBuilder.updateSerializer(MovePlayerPacket.class, MOVE_PLAYER_SERIALIZER_V2168);
            codecBuilder.updateSerializer(PlayerSkinPacket.class, PLAYER_SKIN_SERIALIZER_V2168);
        }

        if (proto >= 2193) { // 26.50+
            codecBuilder.updateSerializer(BossEventPacket.class, BOSS_EVENT_SERIALIZER_V2193);
        } else if (proto >= 1001) { // 26.30 - 26.45
            codecBuilder.updateSerializer(BossEventPacket.class, BOSS_EVENT_SERIALIZER_V1001);
        } else if (proto >= 776) { // 1.21.60 - 26.23
            codecBuilder.updateSerializer(BossEventPacket.class, BOSS_EVENT_SERIALIZER_V776);
        } else { // 1.21.0 - 1.21.51
            codecBuilder.updateSerializer(BossEventPacket.class, BOSS_EVENT_SERIALIZER_V486);
        }""",
        "CodecProcessor.processCodecMultiVersion",
    )
    replace_exact(
        codec_processor,
        """import org.cloudburstmc.protocol.bedrock.packet.PartyChangedPacket;
import org.cloudburstmc.protocol.bedrock.packet.PhotoInfoRequestPacket;""",
        """import org.cloudburstmc.protocol.bedrock.packet.PartyChangedPacket;
import org.cloudburstmc.protocol.bedrock.packet.ClientboundMatchmakingStatePacket;
import org.cloudburstmc.protocol.bedrock.packet.ServerboundMatchmakingCancelPacket;
import org.cloudburstmc.protocol.bedrock.packet.PhotoInfoRequestPacket;""",
        "CodecProcessor.v2225MatchmakingImports",
    )
    replace_exact(
        codec_processor,
        """            if (codec.getProtocolVersion() >= 944) {
                codecBuilder.updateSerializer(PartyChangedPacket.class, IGNORED_SERIALIZER);
            }
        }""",
        """            if (codec.getProtocolVersion() >= 944) {
                codecBuilder.updateSerializer(PartyChangedPacket.class, IGNORED_SERIALIZER);
            }
            if (codec.getProtocolVersion() >= 2225) {
                codecBuilder.updateSerializer(ClientboundMatchmakingStatePacket.class, IGNORED_SERIALIZER);
                codecBuilder.updateSerializer(ServerboundMatchmakingCancelPacket.class, IGNORED_SERIALIZER);
            }
        }""",
        "CodecProcessor.v2225MatchmakingPackets",
    )

    # 9c. BlockRegistryPopulator: load all 17 block palettes (1.21.0 -> 26.50) with guaranteed state resolution
    block_populator = root / "core/src/main/java/org/geysermc/geyser/registry/populator/BlockRegistryPopulator.java"
    replace_exact(
        block_populator,
        """import org.cloudburstmc.protocol.bedrock.codec.v2193.Bedrock_v2193;
import org.cloudburstmc.protocol.bedrock.data.BlockPropertyData;""",
        """import org.cloudburstmc.protocol.bedrock.codec.v2193.Bedrock_v2193;
import org.cloudburstmc.protocol.bedrock.codec.v2225.Bedrock_v2225;
import org.cloudburstmc.protocol.bedrock.data.BlockPropertyData;""",
        "BlockRegistryPopulator.v2225Import",
    )
    replace_exact(
        block_populator,
        """        var blockMappers = ImmutableMap.<ObjectIntPair<String>, Remapper>builder()
                .put(ObjectIntPair.of("26_30", Bedrock_v1001.CODEC.getProtocolVersion()), ICanHasStates::convertBlock)
                .put(ObjectIntPair.of("26_40", Bedrock_v2168.CODEC.getProtocolVersion()), ICanHasStates::convertBlock)
                .put(ObjectIntPair.of("26_50", Bedrock_v2193.CODEC.getProtocolVersion()), tag -> tag)
            .build();""",
        """        var blockMappers = ImmutableMap.<ObjectIntPair<String>, Remapper>builder()
                .put(ObjectIntPair.of("1_21_0", 685), tag -> tag)
                .put(ObjectIntPair.of("1_21_20", 712), tag -> tag)
                .put(ObjectIntPair.of("1_21_30", 729), tag -> tag)
                .put(ObjectIntPair.of("1_21_40", 748), tag -> tag)
                .put(ObjectIntPair.of("1_21_50", 766), tag -> tag)
                .put(ObjectIntPair.of("1_21_60", 776), tag -> tag)
                .put(ObjectIntPair.of("1_21_70", 786), tag -> tag)
                .put(ObjectIntPair.of("1_21_80", 800), tag -> tag)
                .put(ObjectIntPair.of("1_21_90", 818), tag -> tag)
                .put(ObjectIntPair.of("1_21_100", 827), tag -> tag)
                .put(ObjectIntPair.of("1_21_110", 844), tag -> tag)
                .put(ObjectIntPair.of("1_21_130", 898), tag -> tag)
                .put(ObjectIntPair.of("1_26_10", 944), tag -> tag)
                .put(ObjectIntPair.of("1_26_20", 975), tag -> tag)
                .put(ObjectIntPair.of("26_30", Bedrock_v1001.CODEC.getProtocolVersion()), tag -> tag)
                .put(ObjectIntPair.of("26_40", Bedrock_v2168.CODEC.getProtocolVersion()), tag -> tag)
                .put(ObjectIntPair.of("26_50", Bedrock_v2193.CODEC.getProtocolVersion()), tag -> tag)
                .put(ObjectIntPair.of("26_60", Bedrock_v2225.CODEC.getProtocolVersion()), tag -> tag)
            .build();""",
        "BlockRegistryPopulator.blockMappers",
    )
    replace_exact(
        block_populator,
        """                NbtMap originalBedrockTag = buildBedrockState(blockState, entry);
                NbtMap bedrockTag = stateMapper.remap(originalBedrockTag);

                GeyserBedrockBlock vanillaBedrockDefinition = blockStateOrderedMap.get(bedrockTag);""",
        """                NbtMap originalBedrockTag = buildBedrockState(blockState, entry);
                NbtMap bedrockTag = MultiVersionPaletteHelper.remapBlockForVersion(protocolVersion, blockState, stateMapper.remap(originalBedrockTag));

                GeyserBedrockBlock vanillaBedrockDefinition = MultiVersionPaletteHelper.resolveBlockDefinition(bedrockTag, blockStateOrderedMap, blocksByName);""",
        "BlockRegistryPopulator.resolveMultiVersionBlock",
    )
    replace_exact(
        block_populator,
        """            Object2ObjectMap<NbtMap, GeyserBedrockBlock> blockStateOrderedMap = new Object2ObjectOpenHashMap<>(blockStates.size());
            GeyserBedrockBlock[] bedrockRuntimeMap = new GeyserBedrockBlock[blockStates.size()];
            for (int i = 0; i < blockStates.size(); i++) {
                NbtMap tag = blockStates.get(i);
                GeyserBedrockBlock block = new GeyserBedrockBlock(i, tag);
                if (blockStateOrderedMap.put(tag, block) != null) {
                    throw new AssertionError("Duplicate block states in Bedrock palette: " + tag);
                }
                bedrockRuntimeMap[i] = block;
            }""",
        """            Object2ObjectMap<NbtMap, GeyserBedrockBlock> blockStateOrderedMap = new Object2ObjectOpenHashMap<>(blockStates.size());
            Map<String, List<GeyserBedrockBlock>> blocksByName = new Object2ObjectOpenHashMap<>();
            GeyserBedrockBlock[] bedrockRuntimeMap = new GeyserBedrockBlock[blockStates.size()];
            for (int i = 0; i < blockStates.size(); i++) {
                NbtMap tag = blockStates.get(i);
                GeyserBedrockBlock block = new GeyserBedrockBlock(i, tag);
                if (blockStateOrderedMap.put(tag, block) != null) {
                    throw new AssertionError("Duplicate block states in Bedrock palette: " + tag);
                }
                bedrockRuntimeMap[i] = block;
                blocksByName.computeIfAbsent(tag.getString("name"), k -> new ArrayList<>()).add(block);
            }""",
        "BlockRegistryPopulator.indexBlocksByName",
    )

    # 9d. CreativeItemRegistryPopulator: support < 1.21.60 creative_items JSONs without 'groups'
    creative_populator = root / "core/src/main/java/org/geysermc/geyser/registry/populator/CreativeItemRegistryPopulator.java"
    replace_exact(
        creative_populator,
        """        JsonArray creativeItemEntries;
        try (InputStream stream = bootstrap.getResourceOrThrow(String.format("bedrock/creative_items.%s.json", palette.creativeVersion()))) {
            creativeItemEntries = JsonUtils.fromJson(stream).getAsJsonArray("groups");
        } catch (Exception e) {
            throw new AssertionError("Unable to load creative item groups", e);
        }""",
        """        JsonArray creativeItemEntries;
        try (InputStream stream = bootstrap.getResourceOrThrow(String.format("bedrock/creative_items.%s.json", palette.creativeVersion()))) {
            JsonObject rootJson = JsonUtils.fromJson(stream);
            if (!rootJson.has("groups") || !rootJson.get("groups").isJsonArray()) {
                return;
            }
            creativeItemEntries = rootJson.getAsJsonArray("groups");
        } catch (Exception e) {
            throw new AssertionError("Unable to load creative item groups", e);
        }""",
        "CreativeItemRegistryPopulator.optionalGroups",
    )
    replace_exact(
        creative_populator,
        """                itemData = creativeItemData.stream()
                    .map(CreativeItemData::getItem)
                    .filter(item -> item.getDefinition().getIdentifier().equals(identifier))
                    .findFirst()
                    .orElseThrow();""",
        """                itemData = creativeItemData.stream()
                    .map(CreativeItemData::getItem)
                    .filter(item -> item.getDefinition().getIdentifier().equals(identifier))
                    .findFirst()
                    .orElse(ItemData.AIR);""",
        "CreativeItemRegistryPopulator.safeGroupIcon",
    )

    # 9e. ItemRegistryPopulator: load all 21 item palettes (1.21.0 v685 -> 26.60 v2225)
    item_populator = root / "core/src/main/java/org/geysermc/geyser/registry/populator/ItemRegistryPopulator.java"
    replace_exact(
        item_populator,
        """import org.cloudburstmc.protocol.bedrock.codec.v2193.Bedrock_v2193;
import org.cloudburstmc.protocol.bedrock.codec.v924.Bedrock_v924;""",
        """import org.cloudburstmc.protocol.bedrock.codec.v2193.Bedrock_v2193;
import org.cloudburstmc.protocol.bedrock.codec.v2225.Bedrock_v2225;
import org.cloudburstmc.protocol.bedrock.codec.v924.Bedrock_v924;""",
        "ItemRegistryPopulator.v2225Import",
    )
    replace_exact(
        item_populator,
        """        List<PaletteVersion> paletteVersions = new ArrayList<>(3);
        paletteVersions.add(new PaletteVersion("26_30", Bedrock_v1001.CODEC.getProtocolVersion()));
        paletteVersions.add(new PaletteVersion("26_40", Bedrock_v2168.CODEC.getProtocolVersion()));
        paletteVersions.add(new PaletteVersion("26_50", Bedrock_v2193.CODEC.getProtocolVersion()));""",
        """        List<PaletteVersion> paletteVersions = new ArrayList<>(21);
        paletteVersions.add(new PaletteVersion("1_21_0", 685, MultiVersionPaletteHelper.buildJavaOnlyItemFallbacks(685), (it, mp) -> MultiVersionPaletteHelper.remapItemForVersion(685, it, mp)));
        paletteVersions.add(new PaletteVersion("1_21_20", 712, MultiVersionPaletteHelper.buildJavaOnlyItemFallbacks(712), (it, mp) -> MultiVersionPaletteHelper.remapItemForVersion(712, it, mp)));
        paletteVersions.add(new PaletteVersion("1_21_30", 729, MultiVersionPaletteHelper.buildJavaOnlyItemFallbacks(729), (it, mp) -> MultiVersionPaletteHelper.remapItemForVersion(729, it, mp)));
        paletteVersions.add(new PaletteVersion("1_21_40", 748, MultiVersionPaletteHelper.buildJavaOnlyItemFallbacks(748), (it, mp) -> MultiVersionPaletteHelper.remapItemForVersion(748, it, mp)));
        paletteVersions.add(new PaletteVersion("1_21_50", 766, MultiVersionPaletteHelper.buildJavaOnlyItemFallbacks(766), (it, mp) -> MultiVersionPaletteHelper.remapItemForVersion(766, it, mp)));
        paletteVersions.add(new PaletteVersion("1_21_60", 776, MultiVersionPaletteHelper.buildJavaOnlyItemFallbacks(776), (it, mp) -> MultiVersionPaletteHelper.remapItemForVersion(776, it, mp)));
        paletteVersions.add(new PaletteVersion("1_21_70", 786, MultiVersionPaletteHelper.buildJavaOnlyItemFallbacks(786), (it, mp) -> MultiVersionPaletteHelper.remapItemForVersion(786, it, mp)));
        paletteVersions.add(new PaletteVersion("1_21_80", 800, MultiVersionPaletteHelper.buildJavaOnlyItemFallbacks(800), (it, mp) -> MultiVersionPaletteHelper.remapItemForVersion(800, it, mp)));
        paletteVersions.add(new PaletteVersion("1_21_90", 818, MultiVersionPaletteHelper.buildJavaOnlyItemFallbacks(818), (it, mp) -> MultiVersionPaletteHelper.remapItemForVersion(818, it, mp)));
        paletteVersions.add(new PaletteVersion("1_21_93", 819, MultiVersionPaletteHelper.buildJavaOnlyItemFallbacks(819), (it, mp) -> MultiVersionPaletteHelper.remapItemForVersion(819, it, mp)));
        paletteVersions.add(new PaletteVersion("1_21_100", 827, MultiVersionPaletteHelper.buildJavaOnlyItemFallbacks(827), (it, mp) -> MultiVersionPaletteHelper.remapItemForVersion(827, it, mp)));
        paletteVersions.add(new PaletteVersion("1_21_110", 844, MultiVersionPaletteHelper.buildJavaOnlyItemFallbacks(844), (it, mp) -> MultiVersionPaletteHelper.remapItemForVersion(844, it, mp)));
        paletteVersions.add(new PaletteVersion("1_21_120", 859, MultiVersionPaletteHelper.buildJavaOnlyItemFallbacks(859), (it, mp) -> MultiVersionPaletteHelper.remapItemForVersion(859, it, mp)));
        paletteVersions.add(new PaletteVersion("1_21_130", 898, MultiVersionPaletteHelper.buildJavaOnlyItemFallbacks(898), (it, mp) -> MultiVersionPaletteHelper.remapItemForVersion(898, it, mp)));
        paletteVersions.add(new PaletteVersion("1_26_0", Bedrock_v924.CODEC.getProtocolVersion(), MultiVersionPaletteHelper.buildJavaOnlyItemFallbacks(924), (it, mp) -> MultiVersionPaletteHelper.remapItemForVersion(924, it, mp)));
        paletteVersions.add(new PaletteVersion("1_26_10", Bedrock_v944.CODEC.getProtocolVersion(), MultiVersionPaletteHelper.buildJavaOnlyItemFallbacks(944), (it, mp) -> MultiVersionPaletteHelper.remapItemForVersion(944, it, mp)));
        paletteVersions.add(new PaletteVersion("1_26_20", Bedrock_v975.CODEC.getProtocolVersion(), "1_26_10", MultiVersionPaletteHelper.buildJavaOnlyItemFallbacks(975), (it, mp) -> MultiVersionPaletteHelper.remapItemForVersion(975, it, mp)));
        paletteVersions.add(new PaletteVersion("26_30", Bedrock_v1001.CODEC.getProtocolVersion()));
        paletteVersions.add(new PaletteVersion("26_40", Bedrock_v2168.CODEC.getProtocolVersion()));
        paletteVersions.add(new PaletteVersion("26_50", Bedrock_v2193.CODEC.getProtocolVersion()));
        paletteVersions.add(new PaletteVersion("26_60", Bedrock_v2225.CODEC.getProtocolVersion()));""",
        "ItemRegistryPopulator.paletteVersions",
    )
    replace_exact(
        item_populator,
        """        public PaletteVersion(String version, int protocolVersion, Map<Item, Item> javaOnlyItems, String creativeVersion) {
            this(version, protocolVersion, creativeVersion, javaOnlyItems, (item, mapping) -> mapping);
        }""",
        """        public PaletteVersion(String version, int protocolVersion, Map<Item, Item> javaOnlyItems, String creativeVersion) {
            this(version, protocolVersion, creativeVersion, javaOnlyItems, (item, mapping) -> mapping);
        }

        public PaletteVersion(String version, int protocolVersion, Map<Item, Item> javaOnlyItems, Remapper remapper) {
            this(version, protocolVersion, null, javaOnlyItems, remapper);
        }""",
        "ItemRegistryPopulator.PaletteVersionCtor",
    )
    replace_exact(
        item_populator,
        """            NbtMap vanillaComponents;
            try (InputStream stream = bootstrap.getResourceOrThrow("bedrock/item_components.%s.nbt".formatted(palette.version()))) {
                vanillaComponents = (NbtMap) NbtUtils.createGZIPReader(stream, true, true).readTag();
            } catch (Exception e) {
                throw new AssertionError("Unable to load Bedrock item components", e);
            }""",
        """            NbtMap vanillaComponents;
            String componentsVer = palette.protocolVersion() < 818 ? "1_21_80" : palette.version();
            try (InputStream stream = bootstrap.getResourceOrThrow("bedrock/item_components.%s.nbt".formatted(componentsVer))) {
                vanillaComponents = (NbtMap) NbtUtils.createGZIPReader(stream, true, true).readTag();
            } catch (Exception e) {
                throw new AssertionError("Unable to load Bedrock item components", e);
            }""",
        "ItemRegistryPopulator.vanillaComponentsVersion",
    )
    replace_exact(
        item_populator,
        """                // Some items, e.g. food, are not component based but still have components
                NbtMap components = vanillaComponents.getCompound(entry.getName());
                if (components == null && entry.isComponentBased()) {
                    // FIXME needs a proper item components file update
                    if (!entry.getName().contains("lava_chicken")) {
                        throw new RuntimeException("Could not find vanilla components for vanilla component based item! " + entry.getName());
                    } else {
                        components = NbtMap.EMPTY;
                    }
                }""",
        """                // Some items, e.g. food, are not component based but still have components
                NbtMap components = vanillaComponents.getCompound(entry.getName());
                if (components == null && entry.isComponentBased()) {
                    components = NbtMap.EMPTY;
                }""",
        "ItemRegistryPopulator.safeMissingComponents",
    )
    replace_exact(
        item_populator,
        """                GeyserMappingItem mappingItem;
                Item replacementItem = palette.javaOnlyItems().get(javaItem);
                if (replacementItem != null) {
                    mappingItem = items.get(replacementItem.javaIdentifier()); // java only item, a java id fallback has been provided
                } else {
                    // check if any mapping changes need to be made on this version
                    mappingItem = palette.remapper().remap(javaItem, entry.getValue());
                }

                String bedrockIdentifier = mappingItem.getBedrockIdentifier();
                ItemDefinition definition = definitions.get(bedrockIdentifier);
                if (definition == null) {
                    throw new RuntimeException("Missing Bedrock ItemDefinition in version " + palette.version() + " for mapping: " + mappingItem);
                }""",
        """                GeyserMappingItem mappingItem;
                Item replacementItem = palette.javaOnlyItems().get(javaItem);
                if (replacementItem != null) {
                    mappingItem = palette.remapper().remap(replacementItem, items.get(replacementItem.javaIdentifier()));
                } else {
                    mappingItem = palette.remapper().remap(javaItem, entry.getValue());
                }

                String bedrockIdentifier = mappingItem.getBedrockIdentifier();
                ItemDefinition definition = definitions.get(bedrockIdentifier);
                if (definition == null) {
                    javaOnlyItems.add(javaItem);
                    if (entry.getValue().getFirstBlockRuntimeId() != null) {
                        replacementItem = Items.STONE;
                        mappingItem = palette.remapper().remap(Items.STONE, items.get("minecraft:stone"));
                    } else {
                        mappingItem = palette.remapper().remap(Items.PAPER, items.get("minecraft:paper"));
                    }
                    bedrockIdentifier = mappingItem.getBedrockIdentifier();
                    definition = definitions.get(bedrockIdentifier);
                }""",
        "ItemRegistryPopulator.safeDefinitionFallback",
    )
    replace_exact(
        item_populator,
        """                Integer firstBlockRuntimeId = entry.getValue().getFirstBlockRuntimeId();""",
        """                Integer firstBlockRuntimeId = replacementItem != null
                    ? items.get(replacementItem.javaIdentifier()).getFirstBlockRuntimeId()
                    : entry.getValue().getFirstBlockRuntimeId();
                Integer effectiveLastBlockRuntimeId = replacementItem != null
                    ? items.get(replacementItem.javaIdentifier()).getLastBlockRuntimeId()
                    : entry.getValue().getLastBlockRuntimeId();""",
        "ItemRegistryPopulator.replacementBlockRuntimeIds",
    )
    replace_exact(
        item_populator,
        """                            int lastBlockRuntimeId = entry.getValue().getLastBlockRuntimeId() == null ? firstBlockRuntimeId : entry.getValue().getLastBlockRuntimeId();""",
        """                            int lastBlockRuntimeId = effectiveLastBlockRuntimeId == null ? firstBlockRuntimeId : effectiveLastBlockRuntimeId;""",
        "ItemRegistryPopulator.effectiveLastBlockRuntimeId",
    )
    replace_exact(
        item_populator,
        """                                if (bedrockBlock == null) {
                                    throw new RuntimeException("Could not find a block match for " + entry.getKey());
                                }""",
        """                                if (bedrockBlock == null) {
                                    bedrockBlock = blockMappings.getVanillaBedrockBlock(firstBlockRuntimeId);
                                }""",
        "ItemRegistryPopulator.safeBlockMatchFallback",
    )
    replace_exact(
        item_populator,
        """                                    if (itemData.getItem().getDamage() != 0) {
                                        break;
                                    }

                                    NbtMap states = ((GeyserBedrockBlock) itemData.getItem().getBlockDefinition()).getState().getCompound("states");""",
        """                                    if (itemData.getItem().getDamage() != 0 || itemData.getItem().getBlockDefinition() == null) {
                                        break;
                                    }

                                    NbtMap states = ((GeyserBedrockBlock) itemData.getItem().getBlockDefinition()).getState().getCompound("states");""",
        "ItemRegistryPopulator.nullSafeCreativeBlockDef",
    )
    replace_exact(
        item_populator,
        """                    try {
                        definition = registerSkullItem(identifier, items.get("minecraft:player_head"), customProtocolId, palette.protocolVersion, firstMappingsPass);""",
        """                    try {
                        GeyserMappingItem skullBaseMapping = palette.remapper().remap(Items.PLAYER_HEAD, items.get("minecraft:player_head"));
                        definition = registerSkullItem(identifier, skullBaseMapping, customProtocolId, palette.protocolVersion, firstMappingsPass);""",
        "ItemRegistryPopulator.multiVersionSkullBaseMapping",
    )

    # 9f. TagRegistryPopulator: register tags across 685..2225
    tag_populator = root / "core/src/main/java/org/geysermc/geyser/registry/populator/TagRegistryPopulator.java"
    replace_exact(
        tag_populator,
        """import org.cloudburstmc.protocol.bedrock.codec.v2193.Bedrock_v2193;
import org.geysermc.geyser.GeyserBootstrap;""",
        """import org.cloudburstmc.protocol.bedrock.codec.v2193.Bedrock_v2193;
import org.cloudburstmc.protocol.bedrock.codec.v2225.Bedrock_v2225;
import org.geysermc.geyser.GeyserBootstrap;""",
        "TagRegistryPopulator.v2225Import",
    )
    replace_exact(
        tag_populator,
        """        List<ObjectIntPair<String>> paletteVersions = List.of(
            ObjectIntPair.of("26_30", Bedrock_v1001.CODEC.getProtocolVersion()),
            ObjectIntPair.of("26_30", Bedrock_v2168.CODEC.getProtocolVersion()),
            ObjectIntPair.of("26_30", Bedrock_v2193.CODEC.getProtocolVersion())
        );""",
        """        List<ObjectIntPair<String>> paletteVersions = List.of(
            ObjectIntPair.of("1_21_50", 685),
            ObjectIntPair.of("1_21_60", 776),
            ObjectIntPair.of("1_21_70", 786),
            ObjectIntPair.of("1_21_90", 818),
            ObjectIntPair.of("1_21_100", 827),
            ObjectIntPair.of("1_21_110", 844),
            ObjectIntPair.of("1_21_120", 859),
            ObjectIntPair.of("1_21_130", 898),
            ObjectIntPair.of("1_26_0", 924),
            ObjectIntPair.of("1_26_10", 944),
            ObjectIntPair.of("26_30", Bedrock_v1001.CODEC.getProtocolVersion()),
            ObjectIntPair.of("26_30", Bedrock_v2168.CODEC.getProtocolVersion()),
            ObjectIntPair.of("26_30", Bedrock_v2193.CODEC.getProtocolVersion()),
            ObjectIntPair.of("26_30", Bedrock_v2225.CODEC.getProtocolVersion())
        );""",
        "TagRegistryPopulator.paletteVersions",
    )

    # 9g. UpstreamSession: O(1) outgoing packet codec gate + EntityDataMap/EntityFlag/Attribute/EntityId sanitizer
    upstream_session = root / "core/src/main/java/org/geysermc/geyser/session/UpstreamSession.java"
    replace_exact(
        upstream_session,
        """import org.cloudburstmc.protocol.bedrock.BedrockServerSession;
import org.cloudburstmc.protocol.bedrock.codec.BedrockCodecHelper;
import org.cloudburstmc.protocol.bedrock.packet.BedrockPacket;
import org.geysermc.geyser.network.bedrock.GeyserBedrockPeer;

import java.net.InetSocketAddress;
import java.util.ArrayDeque;
import java.util.Queue;""",
        """import org.cloudburstmc.protocol.bedrock.BedrockServerSession;
import org.cloudburstmc.protocol.bedrock.codec.BaseBedrockCodecHelper;
import org.cloudburstmc.protocol.bedrock.codec.BedrockCodecHelper;
import org.cloudburstmc.protocol.bedrock.codec.EntityDataTypeMap;
import org.cloudburstmc.protocol.bedrock.data.entity.EntityDataMap;
import org.cloudburstmc.protocol.bedrock.data.entity.EntityDataTypes;
import org.cloudburstmc.protocol.bedrock.data.entity.EntityFlag;
import org.cloudburstmc.protocol.bedrock.packet.AddEntityPacket;
import org.cloudburstmc.protocol.bedrock.packet.AddItemEntityPacket;
import org.cloudburstmc.protocol.bedrock.packet.AddPlayerPacket;
import org.cloudburstmc.protocol.bedrock.packet.BedrockPacket;
import org.cloudburstmc.protocol.bedrock.packet.SetEntityDataPacket;
import org.cloudburstmc.protocol.bedrock.packet.UpdateAttributesPacket;
import org.cloudburstmc.protocol.bedrock.transformer.FlagTransformer;
import org.cloudburstmc.protocol.common.util.TypeMap;
import org.geysermc.geyser.network.bedrock.GeyserBedrockPeer;

import java.lang.reflect.Field;
import java.net.InetSocketAddress;
import java.util.ArrayDeque;
import java.util.EnumMap;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;""",
        "UpstreamSession.imports",
    )
    replace_exact(
        upstream_session,
        """    public void sendPacket(@NonNull BedrockPacket packet) {
        if (!isClosed()) {
            session.sendPacket(packet);
        }
    }

    public void sendPacketImmediately(@NonNull BedrockPacket packet) {
        if (!isClosed()) {
            session.sendPacketImmediately(packet);
        }
    }""",
        """    private static final Set<String> ATTRIBUTES_26_30 = Set.of(
        "minecraft:friction_modifier",
        "minecraft:bounciness",
        "minecraft:air_drag_modifier"
    );

    private record ProtocolEntityFilter(EntityDataTypeMap dataTypes, TypeMap<EntityFlag> flagTypes) {}
    private static final ConcurrentHashMap<Integer, ProtocolEntityFilter> ENTITY_FILTERS = new ConcurrentHashMap<>();
    private static final Field ENTITY_DATA_FIELD;
    private static final Field FLAG_TYPEMAP_FIELD;

    static {
        Field edf = null;
        Field ftf = null;
        try {
            edf = BaseBedrockCodecHelper.class.getDeclaredField("entityData");
            edf.setAccessible(true);
            ftf = FlagTransformer.class.getDeclaredField("typeMap");
            ftf.setAccessible(true);
        } catch (Throwable ignored) {
        }
        ENTITY_DATA_FIELD = edf;
        FLAG_TYPEMAP_FIELD = ftf;
    }

    @SuppressWarnings("unchecked")
    private ProtocolEntityFilter getEntityFilter(int proto) {
        return ENTITY_FILTERS.computeIfAbsent(proto, p -> {
            try {
                BedrockCodecHelper helper = getCodecHelper();
                if (ENTITY_DATA_FIELD != null && helper instanceof BaseBedrockCodecHelper baseHelper) {
                    EntityDataTypeMap edm = (EntityDataTypeMap) ENTITY_DATA_FIELD.get(baseHelper);
                    TypeMap<EntityFlag> ftm = null;
                    EntityDataTypeMap.Definition<?> flagsDef = edm.fromType(EntityDataTypes.FLAGS);
                    if (flagsDef != null && FLAG_TYPEMAP_FIELD != null && flagsDef.getTransformer() instanceof FlagTransformer ft) {
                        ftm = (TypeMap<EntityFlag>) FLAG_TYPEMAP_FIELD.get(ft);
                    }
                    return new ProtocolEntityFilter(edm, ftm);
                }
            } catch (Throwable ignored) {
            }
            return new ProtocolEntityFilter(null, null);
        });
    }

    private void sanitizeEntityData(int proto, EntityDataMap metadata) {
        if (proto >= 2193 || metadata == null || metadata.isEmpty()) {
            return;
        }
        ProtocolEntityFilter filter = getEntityFilter(proto);
        if (filter.dataTypes() != null) {
            metadata.keySet().removeIf(type -> filter.dataTypes().fromType(type) == null);
        }
        EnumMap<EntityFlag, Boolean> flags = metadata.getFlags();
        if (flags != null && !flags.isEmpty() && filter.flagTypes() != null) {
            flags.keySet().removeIf(flag -> filter.flagTypes().getIdUnsafe(flag) == -1);
        }
    }

    private boolean prepareOutgoingPacket(BedrockPacket packet) {
        if (this.session.getCodec().getPacketDefinition(packet.getClass()) == null) {
            return false;
        }
        int proto = getProtocolVersion();
        if (proto >= 2193) {
            return true;
        }
        if (packet instanceof SetEntityDataPacket sed) {
            sanitizeEntityData(proto, sed.getMetadata());
        } else if (packet instanceof AddEntityPacket aep) {
            sanitizeEntityData(proto, aep.getMetadata());
            if (proto < 898) {
                String id = aep.getIdentifier();
                if (proto < 766 && "minecraft:creaking".equals(id)) {
                    aep.setIdentifier("minecraft:enderman");
                } else if (proto < 800 && "minecraft:happy_ghast".equals(id)) {
                    aep.setIdentifier("minecraft:ghast");
                } else if (proto < 844 && "minecraft:copper_golem".equals(id)) {
                    aep.setIdentifier("minecraft:iron_golem");
                } else if ("minecraft:nautilus".equals(id) || "minecraft:zombie_nautilus".equals(id)) {
                    aep.setIdentifier("minecraft:dolphin");
                } else if ("minecraft:camel_husk".equals(id)) {
                    aep.setIdentifier("minecraft:camel");
                } else if ("minecraft:parched".equals(id)) {
                    aep.setIdentifier("minecraft:stray");
                }
            }
        } else if (packet instanceof AddPlayerPacket app) {
            sanitizeEntityData(proto, app.getMetadata());
        } else if (packet instanceof AddItemEntityPacket aiep) {
            sanitizeEntityData(proto, aiep.getMetadata());
        } else if (proto < 1001 && packet instanceof UpdateAttributesPacket uap) {
            java.util.List<org.cloudburstmc.protocol.bedrock.data.AttributeData> attrs = uap.getAttributes();
            if (attrs == null || attrs.isEmpty()) {
                return false;
            }
            boolean hasUnsupported = false;
            for (int i = 0, n = attrs.size(); i < n; i++) {
                if (ATTRIBUTES_26_30.contains(attrs.get(i).getName())) {
                    hasUnsupported = true;
                    break;
                }
            }
            if (hasUnsupported) {
                java.util.ArrayList<org.cloudburstmc.protocol.bedrock.data.AttributeData> filtered = new java.util.ArrayList<>(attrs.size());
                for (int i = 0, n = attrs.size(); i < n; i++) {
                    org.cloudburstmc.protocol.bedrock.data.AttributeData ad = attrs.get(i);
                    if (!ATTRIBUTES_26_30.contains(ad.getName())) {
                        filtered.add(ad);
                    }
                }
                if (filtered.isEmpty()) {
                    return false;
                }
                uap.setAttributes(filtered);
            }
        }
        return true;
    }

    public void sendPacket(@NonNull BedrockPacket packet) {
        if (!isClosed() && prepareOutgoingPacket(packet)) {
            session.sendPacket(packet);
        }
    }

    public void sendPacketImmediately(@NonNull BedrockPacket packet) {
        if (!isClosed() && prepareOutgoingPacket(packet)) {
            session.sendPacketImmediately(packet);
        }
    }""",
        "UpstreamSession.multiVersionSanitizer",
    )
    replace_exact(
        upstream_session,
        """    public void queuePostStartGamePacket(BedrockPacket packet) {
        postStartGamePackets.add(packet);
    }""",
        """    public synchronized void queuePostStartGamePacket(BedrockPacket packet) {
        Queue<BedrockPacket> packets = postStartGamePackets;
        if (packets != null) {
            packets.add(packet);
        } else {
            // Extensions may enqueue after a repeated Java login/reconfiguration packet.
            // StartGame has already completed, so sending now preserves the intended ordering.
            sendPacket(packet);
        }
    }""",
        "UpstreamSession.postStartGameQueueLatePacket",
    )
    replace_exact(
        upstream_session,
        """    public void sendPostStartGamePackets() {
        if (isClosed()) {
            return;
        }

        BedrockPacket packet;
        while ((packet = postStartGamePackets.poll()) != null) {
            session.sendPacket(packet);
        }
        postStartGamePackets = null;
    }""",
        """    public synchronized void sendPostStartGamePackets() {
        if (isClosed()) {
            return;
        }

        // JavaLoginTranslator can be wrapped by extensions (for example GeyserGlowing), and
        // reconfiguration can deliver another login packet. Flushing must therefore be idempotent.
        Queue<BedrockPacket> packets = postStartGamePackets;
        if (packets == null) {
            return;
        }
        postStartGamePackets = null;

        BedrockPacket packet;
        while ((packet = packets.poll()) != null) {
            if (prepareOutgoingPacket(packet)) {
                session.sendPacket(packet);
            }
        }
    }""",
        "UpstreamSession.postStartGameIdempotentSanitizer",
    )

    # 9h. GeyserSession: multi-version StartGamePacket, ItemComponentPacket, BiomeDefinitionListPacket, Jigsaw/VoxelShapes, Experiments
    geyser_session = root / "core/src/main/java/org/geysermc/geyser/session/GeyserSession.java"
    replace_exact(
        geyser_session,
        """        ItemComponentPacket componentPacket = new ItemComponentPacket();
        componentPacket.getItems().addAll(itemMappings.getItemDefinitions().values());
        upstream.sendPacket(componentPacket);""",
        """        ItemComponentPacket componentPacket = new ItemComponentPacket();
        if (this.protocolVersion() < 776) {
            for (var def : itemMappings.getItemDefinitions().values()) {
                if (def.isComponentBased() && def.getComponentData() != null && (
                        !def.getIdentifier().startsWith("minecraft:")
                        || def.getIdentifier().equals("minecraft:cake")
                        || def.getIdentifier().equals("minecraft:armor_stand")
                        || def.getIdentifier().equals("minecraft:firework_rocket"))) {
                    componentPacket.getItems().add(def);
                }
            }
        } else {
            componentPacket.getItems().addAll(itemMappings.getItemDefinitions().values());
        }
        upstream.sendPacket(componentPacket);""",
        "GeyserSession.itemComponentPacketMultiVersion",
    )
    replace_exact(
        geyser_session,
        """        CreativeContentPacket creativePacket = new CreativeContentPacket();
        creativePacket.getContents().addAll(this.itemMappings.getCreativeItems());
        creativePacket.getGroups().addAll(this.itemMappings.getCreativeItemGroups());
        upstream.sendPacket(creativePacket);""",
        """        CreativeContentPacket creativePacket = new CreativeContentPacket();
        String deviceOs = (this.getClientData() != null && this.getClientData().getDeviceOs() != null)
            ? this.getClientData().getDeviceOs().name()
            : "UNKNOWN";
        boolean constrainedClient = !deviceOs.equals("UWP")
            && !deviceOs.equals("WIN32")
            && !deviceOs.equals("WINDOWS");
        java.util.List<org.cloudburstmc.protocol.bedrock.data.inventory.CreativeItemData> creativeItems =
            this.itemMappings.getCreativeItems();
        if (constrainedClient) {
            // The full creative catalogue is one of the largest persistent allocations made
            // immediately after StartGame. Survival clients do not need every entry to join.
            int safeLimit = Math.max(128, Integer.getInteger("purpurbedrock.mobileCreativeItemLimit", 512));
            creativePacket.getContents().addAll(creativeItems.subList(0, Math.min(safeLimit, creativeItems.size())));
        } else {
            creativePacket.getContents().addAll(creativeItems);
        }
        creativePacket.getGroups().addAll(this.itemMappings.getCreativeItemGroups());
        upstream.sendPacket(creativePacket);""",
        "GeyserSession.mobileSafeCreativeContent",
    )
    replace_exact(
        geyser_session,
        """        BiomeDefinitionListPacket biomeDefinitionListPacket = new BiomeDefinitionListPacket();
        biomeDefinitionListPacket.setBiomes(Registries.BIOMES.get());
        upstream.sendPacket(biomeDefinitionListPacket);""",
        """        BiomeDefinitionListPacket biomeDefinitionListPacket = new BiomeDefinitionListPacket();
        if (this.protocolVersion() >= 800) {
            biomeDefinitionListPacket.setBiomes(Registries.BIOMES.get());
        } else {
            biomeDefinitionListPacket.setDefinitions(Registries.BIOMES_NBT.get());
        }
        upstream.sendPacket(biomeDefinitionListPacket);""",
        "GeyserSession.biomeDefinitionListMultiVersion",
    )
    replace_exact(
        geyser_session,
        """        JigsawStructureDataPacket jigsawStructureDataPacket = new JigsawStructureDataPacket();
        jigsawStructureDataPacket.setJigsawStructureDataTag(NbtMap.fromMap(Map.of(
            "processors", NbtList.EMPTY,
            "template_pools", NbtList.EMPTY,
            "jigsaws", NbtList.EMPTY,
            "structure_sets", NbtList.EMPTY
        )));
        upstream.sendPacket(jigsawStructureDataPacket);

        VoxelShapesPacket voxelShapesPacket = new VoxelShapesPacket();
        voxelShapesPacket.setNameMap(new HashMap<>());
        voxelShapesPacket.setShapes(new ArrayList<>());
        upstream.sendPacket(voxelShapesPacket);""",
        """        if (this.protocolVersion() >= 712) {
            JigsawStructureDataPacket jigsawStructureDataPacket = new JigsawStructureDataPacket();
            jigsawStructureDataPacket.setJigsawStructureDataTag(NbtMap.fromMap(Map.of(
                "processors", NbtList.EMPTY,
                "template_pools", NbtList.EMPTY,
                "jigsaws", NbtList.EMPTY,
                "structure_sets", NbtList.EMPTY
            )));
            upstream.sendPacket(jigsawStructureDataPacket);
        }

        if (this.protocolVersion() >= 975) {
            VoxelShapesPacket voxelShapesPacket = new VoxelShapesPacket();
            voxelShapesPacket.setNameMap(new HashMap<>());
            voxelShapesPacket.setShapes(new ArrayList<>());
            upstream.sendPacket(voxelShapesPacket);
        }""",
        "GeyserSession.jigsawAndVoxelShapesGates",
    )
    replace_exact(
        geyser_session,
        """        // Needed for custom block mappings and custom skulls system
        startGamePacket.getBlockProperties().addAll(this.blockMappings.getBlockProperties());""",
        """        // Needed for custom block mappings and custom skulls system
        startGamePacket.getBlockProperties().addAll(this.blockMappings.getBlockProperties());
        if (this.protocolVersion() < 776) {
            startGamePacket.getItemDefinitions().addAll(this.itemMappings.getItemDefinitions().values());
        }""",
        "GeyserSession.pre776StartGameItemDefinitions",
    )
    replace_exact(
        geyser_session,
        """        startGamePacket.setRewindHistorySize(0);""",
        """        // Required for < 1.21.90 (< v818) StartGameSerializer_v428.writeSyncedPlayerMovementSettings (prevents NPE on null ordinal)
        startGamePacket.setAuthoritativeMovementMode(org.cloudburstmc.protocol.bedrock.data.AuthoritativeMovementMode.SERVER);
        startGamePacket.setRewindHistorySize(0);""",
        "GeyserSession.pre818AuthoritativeMovementMode",
    )
    replace_exact(
        geyser_session,
        """        // Needed for certain molang queries used in blocks and items
        startGamePacket.getExperiments().add(new ExperimentData("experimental_molang_features", true));
    }""",
        """        // Needed for certain molang queries used in blocks and items
        startGamePacket.getExperiments().add(new ExperimentData("experimental_molang_features", true));
        if (this.protocolVersion() == 800) {
            startGamePacket.getExperiments().add(new ExperimentData("y_2025_drop_2", true));
            startGamePacket.getExperiments().add(new ExperimentData("locator_bar", true));
        } else if (this.protocolVersion() == 827) {
            startGamePacket.getExperiments().add(new ExperimentData("y_2025_drop_3", true));
        }
    }""",
        "GeyserSession.configureExperimentsMultiVersion",
    )
    replace_exact(
        geyser_session,
        """    private void syncEntityProperties() {
        for (NbtMap nbtMap : Registries.BEDROCK_ENTITY_PROPERTIES.get()) {
            SyncEntityPropertyPacket syncEntityPropertyPacket = new SyncEntityPropertyPacket();
            syncEntityPropertyPacket.setData(nbtMap);
            upstream.sendPacket(syncEntityPropertyPacket);
        }
    }""",
        """    private void syncEntityProperties() {
        int proto = this.protocolVersion();
        for (NbtMap nbtMap : Registries.BEDROCK_ENTITY_PROPERTIES.get()) {
            String type = nbtMap.getString("type", "");
            if ((proto < 766 && "minecraft:creaking".equals(type))
                || (proto < 800 && "minecraft:happy_ghast".equals(type))
                || (proto < 844 && "minecraft:copper_golem".equals(type))
                || (proto < 898 && ("minecraft:nautilus".equals(type)
                    || "minecraft:zombie_nautilus".equals(type)
                    || "minecraft:camel_husk".equals(type)
                    || "minecraft:parched".equals(type)))) {
                continue;
            }
            SyncEntityPropertyPacket syncEntityPropertyPacket = new SyncEntityPropertyPacket();
            syncEntityPropertyPacket.setData(nbtMap);
            upstream.sendPacket(syncEntityPropertyPacket);
        }
    }""",
        "GeyserSession.syncEntityPropertiesMultiVersion",
    )

    # 9i. UpstreamPacketHandler, BedrockInventoryTransactionTranslator, BedrockPlayerAuthInputTranslator,
    #     JavaRecipeBookAddTranslator, BoatEntity, SkullBlockEntityTranslator
    upstream_handler = root / "core/src/main/java/org/geysermc/geyser/network/bedrock/UpstreamPacketHandler.java"
    replace_exact(
        upstream_handler,
        """                stackPacket.setGameVersion("*");
                stackPacket.getResourcePacks().addAll(this.resourcePackLoadEvent.orderedPacks());

                session.sendUpstreamPacket(stackPacket);""",
        """                stackPacket.setGameVersion("*");
                stackPacket.getResourcePacks().addAll(this.resourcePackLoadEvent.orderedPacks());
                if (session.protocolVersion() == 800) {
                    stackPacket.getExperiments().add(new org.cloudburstmc.protocol.bedrock.data.ExperimentData("y_2025_drop_2", true));
                    stackPacket.getExperiments().add(new org.cloudburstmc.protocol.bedrock.data.ExperimentData("locator_bar", true));
                } else if (session.protocolVersion() == 827) {
                    stackPacket.getExperiments().add(new org.cloudburstmc.protocol.bedrock.data.ExperimentData("y_2025_drop_3", true));
                }

                session.sendUpstreamPacket(stackPacket);""",
        "UpstreamPacketHandler.stackExperiments",
    )

    inv_tx_translator = root / "core/src/main/java/org/geysermc/geyser/translator/protocol/bedrock/BedrockInventoryTransactionTranslator.java"
    replace_exact(
        inv_tx_translator,
        """                if (packet.getActions().size() == 2) {
                    InventoryActionData worldAction = packet.getActions().get(1);
                    InventoryActionData containerAction = packet.getActions().get(0);""",
        """                if (packet.getActions().size() == 2) {
                    boolean is2630OrAbove = session.protocolVersion() >= 1001;
                    InventoryActionData worldAction = packet.getActions().get(is2630OrAbove ? 1 : 0);
                    InventoryActionData containerAction = packet.getActions().get(is2630OrAbove ? 0 : 1);""",
        "BedrockInventoryTransactionTranslator.dropItemOrder",
    )

    auth_input_translator = root / "core/src/main/java/org/geysermc/geyser/translator/protocol/bedrock/entity/player/input/BedrockPlayerAuthInputTranslator.java"
    replace_exact(
        auth_input_translator,
        """        session.setInClientPredictedVehicle(packet.getInputData().contains(PlayerAuthInputData.IN_CLIENT_PREDICTED_IN_VEHICLE) && entity.getVehicle() != null);""",
        """        session.setInClientPredictedVehicle(session.protocolVersion() >= 944
            && packet.getInputData().contains(PlayerAuthInputData.IN_CLIENT_PREDICTED_IN_VEHICLE)
            && entity.getVehicle() != null);""",
        "BedrockPlayerAuthInputTranslator.vehiclePredictionGate",
    )

    recipe_translator = root / "core/src/main/java/org/geysermc/geyser/translator/protocol/java/JavaRecipeBookAddTranslator.java"
    replace_exact(
        recipe_translator,
        """            if (display instanceof FurnaceRecipeDisplay furnaceRecipe) {""",
        """            if (display instanceof FurnaceRecipeDisplay furnaceRecipe) {
                if (session.protocolVersion() < 975) {
                    continue;
                }""",
        "JavaRecipeBookAddTranslator.furnaceRecipeGate",
    )

    boat_entity = root / "core/src/main/java/org/geysermc/geyser/entity/type/BoatEntity.java"
    replace_exact(
        boat_entity,
        """        this.variant = variant;

        metadata.put(EntityDataTypes.VARIANT, variant.ordinal());""",
        """        if (variant == BoatVariant.PALE_OAK && session.protocolVersion() < 766) {
            variant = BoatVariant.BIRCH;
        }
        this.variant = variant;

        metadata.put(EntityDataTypes.VARIANT, variant.ordinal());""",
        "BoatEntity.paleOakVariantFallback",
    )

    skull_be = root / "core/src/main/java/org/geysermc/geyser/translator/level/block/entity/SkullBlockEntityTranslator.java"
    replace_exact(
        skull_be,
        """        if (blockState.getValue(Properties.POWERED)) {
            bedrockNbt.putBoolean("MouthMoving", true);
        }""",
        """        if (session.protocolVersion() < 748 && blockState.block() instanceof org.geysermc.geyser.level.block.type.SkullBlock skull) {
            bedrockNbt.putByte("SkullType", (byte) skull.skullType().bedrockId());
        }
        if (blockState.getValue(Properties.POWERED)) {
            bedrockNbt.putBoolean("MouthMoving", true);
        }""",
        "SkullBlockEntityTranslator.pre748SkullType",
    )

    # =========================================================================
    # 10. Bedrock Connection Survival, Chunk Reliability & Real RTT Ping
    # =========================================================================
    # RakNet's upstream default is only 10 seconds. Mobile radio handovers, VPNs and a client
    # busy applying a resource pack can exceed that without representing a dead connection.
    raknet_server = root / "core/src/main/java/org/geysermc/geyser/network/RaknetServer.java"
    replace_exact(
        raknet_server,
        """            .option(RakChannelOption.RAK_THROTTLE, rakRateLimitingDisabled ? null : new DefaultRakServerThrottle(maxConnectionsPerAddress, 4_000, 3))
            .childHandler(serverInitializer);""",
        """            // Permit rapid retries after app crashes and Wi-Fi/LTE handovers. The packet/global
            // limiters still protect the socket; three admissions per four seconds was too low
            // for a client retry sequence and silently produced a timeout screen.
            .option(RakChannelOption.RAK_THROTTLE, rakRateLimitingDisabled ? null : new DefaultRakServerThrottle(maxConnectionsPerAddress, 1_000, 20))
            .childOption(RakChannelOption.RAK_SESSION_TIMEOUT,
                Math.max(30_000L, Long.getLong("purpurbedrock.rakSessionTimeoutMs", 120_000L)))
            .childHandler(serverInitializer);""",
        "RaknetServer.mobileSessionTimeout",
    )

    # A 256 KiB pack chunk fragments into hundreds of UDP datagrams. Smaller chunks make
    # retransmission practical on lossy Wi-Fi/LTE and keep the login progressing.
    resource_pack = root / "core/src/main/java/org/geysermc/geyser/pack/GeyserResourcePack.java"
    replace_exact(
        resource_pack,
        """    public static final int CHUNK_SIZE = 1024 * 256;""",
        """    public static final int CHUNK_SIZE = 1024 * 64; // Purpurbedrock: loss-safe mobile pack transfer""",
        "GeyserResourcePack.lossSafeChunkSize",
    )

    # Never make the Java server's keepalive depend on the Bedrock render/UI thread. During
    # world loading that callback can pause long enough for the Java side to kick a healthy user.
    java_keepalive = root / "core/src/main/java/org/geysermc/geyser/translator/protocol/java/JavaKeepAliveTranslator.java"
    replace_exact(
        java_keepalive,
        """        final long javaId = packet.getPingId();
        // ClientboundKeepAlivePacket's are async, hence we won't add additional delay ensuring it's sent in the event loop would add
        session.sendNetworkLatencyStackPacket(javaId, false, () -> session.sendDownstreamPacket(new ServerboundKeepAlivePacket(javaId)));""",
        """        final long javaId = packet.getPingId();
        // Confirm immediately. Real client RTT is measured independently by the periodic
        // NetworkStackLatency probe, so this cannot turn a loading-screen stall into a timeout.
        session.sendDownstreamPacket(new ServerboundKeepAlivePacket(javaId));""",
        "JavaKeepAliveTranslator.loadingSafeImmediateAck",
    )

    # A crashed app can leave its pending/active XUID registered briefly. The next connection
    # must replace that stale session instead of being rejected forever as "already logged in".
    session_manager = root / "core/src/main/java/org/geysermc/geyser/session/SessionManager.java"
    replace_exact(
        session_manager,
        """    public void addSession(UUID uuid, GeyserSession session) {
        pendingSessions.remove(session);
        sessions.put(uuid, session);
    }

    public void removeSession(GeyserSession session) {
        UUID uuid = session.getPlayerEntity().uuid();
        if (uuid == null || sessions.remove(uuid) == null) {
            // Connection was likely pending
            pendingSessions.remove(session);
        }
    }""",
        """    public void addSession(UUID uuid, GeyserSession session) {
        pendingSessions.remove(session);
        GeyserSession previous = sessions.put(uuid, session);
        if (previous != null && previous != session) {
            previous.disconnect("Replaced by a newer connection");
        }
    }

    public void removeSession(GeyserSession session) {
        // Always remove pending state, including sessions that obtained a UUID just before
        // failing. Remove active state conditionally so an old disconnect race cannot erase
        // the replacement session stored under the same Java UUID.
        pendingSessions.remove(session);
        UUID uuid = session.getPlayerEntity().uuid();
        if (uuid != null) {
            sessions.remove(uuid, session);
        }
        sessions.entrySet().removeIf(entry -> entry.getValue() == session);
    }

    public void replaceSessionsByXuid(String xuid, GeyserSession replacement) {
        if (xuid == null || xuid.isBlank()) {
            return;
        }
        for (GeyserSession previous : getAllSessions()) {
            if (previous != replacement && xuid.equals(previous.xuid())) {
                pendingSessions.remove(previous);
                UUID uuid = previous.getPlayerEntity().uuid();
                if (uuid != null) {
                    sessions.remove(uuid, previous);
                }
                previous.disconnect("Replaced by a newer connection");
            }
        }
    }""",
        "SessionManager.atomicReconnectReplacement",
    )

    replace_exact(
        upstream_handler,
        """        if (geyser.getSessionManager().isXuidAlreadyPending(session.xuid()) || geyser.getSessionManager().sessionByXuid(session.xuid()) != null) {
            session.disconnect(GeyserLocale.getLocaleStringLog("geyser.auth.already_loggedin", session.bedrockUsername()));
            return PacketSignal.HANDLED;
        }

        // Set the block translation based off of version""",
        """        // Mobile clients often reconnect before a timed-out socket's close event reaches
        // the server. Atomically evict that stale XUID so the second login can proceed.
        geyser.getSessionManager().replaceSessionsByXuid(session.xuid(), session);

        // Set the block translation based off of version""",
        "UpstreamPacketHandler.replaceStaleSessionOnReconnect",
    )

    # Existing installations may still contain the former 120-second value. Clamp the runtime
    # authentication window without requiring users to regenerate their configuration.
    geyser_impl = root / "core/src/main/java/org/geysermc/geyser/GeyserImpl.java"
    replace_exact(
        geyser_impl,
        """        pendingMicrosoftAuthentication = new PendingMicrosoftAuthentication(config.pendingAuthenticationTimeout());""",
        """        pendingMicrosoftAuthentication = new PendingMicrosoftAuthentication(
            config.pendingAuthenticationTimeout() == 0 ? 0 : Math.max(300, config.pendingAuthenticationTimeout()));""",
        "GeyserImpl.minimumAuthenticationTimeout",
    )

    chunk_utils = root / "core/src/main/java/org/geysermc/geyser/util/ChunkUtils.java"
    replace_exact(
        chunk_utils,
        """    public static void updateChunkPosition(GeyserSession session, Vector3i position) {
        Vector2i chunkPos = session.getLastChunkPosition();
        Vector2i newChunkPos = Vector2i.from(position.getX() >> 4, position.getZ() >> 4);

        if (chunkPos == null || !chunkPos.equals(newChunkPos)) {
            NetworkChunkPublisherUpdatePacket chunkPublisherUpdatePacket = new NetworkChunkPublisherUpdatePacket();
            chunkPublisherUpdatePacket.setPosition(position);
            // Mitigates chunks not loading on 1.17.1 Paper and 1.19.3 Fabric. As of Bedrock 1.19.60.
            // https://github.com/GeyserMC/Geyser/issues/3490
            chunkPublisherUpdatePacket.setRadius(squareToCircle(session.getServerRenderDistance()) << 4);
            session.sendUpstreamPacket(chunkPublisherUpdatePacket);

            session.setLastChunkPosition(newChunkPos);
        }
    }""",
        """    private static final java.util.Map<GeyserSession, Integer> LAST_PUBLISHER_RADIUS =
        java.util.Collections.synchronizedMap(new java.util.WeakHashMap<>());

    public static int computePublisherBlockRadius(GeyserSession session) {
        int effectiveChunks = session.purpurAdaptiveRenderDistance();
        // Do not add a publisher margin: at a 5-chunk client distance, +2 expands the
        // circular area from roughly 154 to 254 chunks. Low-memory phones can be killed by
        // Android exactly as the loading-tip text disappears, before they ever spawn.
        return squareToCircle(effectiveChunks) << 4;
    }

    public static Vector3i clampPublisherY(GeyserSession session, Vector3i position) {
        BedrockDimension dim = session.getBedrockDimension();
        int minY = dim != null ? dim.minY() : -64;
        int maxY = dim != null ? (dim.minY() + dim.height() - 1) : 319;
        int rawY = position.getY();
        int clampedY = (rawY < minY || rawY > maxY) ? Math.max(minY, Math.min(64, maxY)) : rawY;
        return clampedY == rawY ? position : Vector3i.from(position.getX(), clampedY, position.getZ());
    }

    public static void updateChunkPosition(GeyserSession session, Vector3i position) {
        updateChunkPosition(session, position, false);
    }

    public static void forceUpdateChunkPosition(GeyserSession session, Vector3i position) {
        updateChunkPosition(session, position, true);
    }

    public static void forceUpdateChunkPositionBlock(GeyserSession session, int blockX, int blockY, int blockZ) {
        updateChunkPosition(session, Vector3i.from(blockX, blockY, blockZ), true);
    }

    public static void updateChunkPosition(GeyserSession session, Vector3i position, boolean force) {
        Vector3i safePos = clampPublisherY(session, position);
        Vector2i chunkPos = session.getLastChunkPosition();
        Vector2i newChunkPos = Vector2i.from(safePos.getX() >> 4, safePos.getZ() >> 4);
        int blockRadius = computePublisherBlockRadius(session);
        Integer prevRadius = LAST_PUBLISHER_RADIUS.get(session);

        if (force || chunkPos == null || !chunkPos.equals(newChunkPos) || prevRadius == null || prevRadius != blockRadius) {
            NetworkChunkPublisherUpdatePacket chunkPublisherUpdatePacket = new NetworkChunkPublisherUpdatePacket();
            chunkPublisherUpdatePacket.setPosition(safePos);
            chunkPublisherUpdatePacket.setRadius(blockRadius);
            session.sendUpstreamPacket(chunkPublisherUpdatePacket);

            session.setLastChunkPosition(newChunkPos);
            LAST_PUBLISHER_RADIUS.put(session, blockRadius);
        }
    }

    public static void ensureChunkPublished(GeyserSession session, int chunkX, int chunkZ) {
        Vector2i lastCenter = session.getLastChunkPosition();
        int blockRadius = computePublisherBlockRadius(session);
        int chunkRadius = Math.max(4, (blockRadius >> 4) - 1);
        Vector3i playerPos = session.getPlayerEntity() != null
            ? session.getPlayerEntity().position().toInt()
            : Vector3i.from((chunkX << 4) + 8, 64, (chunkZ << 4) + 8);
        if (lastCenter == null) {
            updateChunkPosition(session, Vector3i.from((chunkX << 4) + 8, playerPos.getY(), (chunkZ << 4) + 8), true);
            return;
        }
        int dx = chunkX - lastCenter.getX();
        int dz = chunkZ - lastCenter.getY();
        if ((dx * dx + dz * dz) > (chunkRadius * chunkRadius)) {
            int playerChunkX = playerPos.getX() >> 4;
            int playerChunkZ = playerPos.getZ() >> 4;
            int pdx = chunkX - playerChunkX;
            int pdz = chunkZ - playerChunkZ;
            if ((pdx * pdx + pdz * pdz) <= (chunkRadius * chunkRadius)) {
                updateChunkPosition(session, playerPos, true);
            }
            // Never move the publisher center to an out-of-range prefetch/stale chunk.
            // Doing so unloads the chunks around the player and makes the world visibly flash.
        }
    }""",
        "ChunkUtils.reliableChunkPublisher",
    )

    replace_exact(
        chunk_utils,
        """    public static void sendEmptyChunks(GeyserSession session, Vector3i position, int radius, boolean forceUpdate) {
        int chunkX = position.getX() >> 4;
        int chunkZ = position.getZ() >> 4;""",
        """    public static void sendEmptyChunks(GeyserSession session, Vector3i position, int radius, boolean forceUpdate) {
        if (forceUpdate) {
            forceUpdateChunkPosition(session, position);
        } else {
            updateChunkPosition(session, position);
        }
        int chunkX = position.getX() >> 4;
        int chunkZ = position.getZ() >> 4;""",
        "ChunkUtils.sendEmptyChunksPublishFirst",
    )

    cache_center_translator = root / "core/src/main/java/org/geysermc/geyser/translator/protocol/java/level/JavaSetChunkCacheCenterTranslator.java"
    replace_exact(
        cache_center_translator,
        """        if (!session.isSpawned() && session.getLastChunkPosition() == null) {
            ChunkUtils.updateChunkPosition(session, Vector3i.from(packet.getChunkX() << 4, 64, packet.getChunkZ() << 4));
        }""",
        """        int centerY = session.getPlayerEntity() != null ? session.getPlayerEntity().position().toInt().getY() : 64;
        ChunkUtils.updateChunkPosition(session, Vector3i.from((packet.getChunkX() << 4) + 8, centerY, (packet.getChunkZ() << 4) + 8));""",
        "JavaSetChunkCacheCenterTranslator.alwaysUpdatePublisher",
    )

    player_pos_translator = root / "core/src/main/java/org/geysermc/geyser/translator/protocol/java/entity/player/JavaPlayerPositionTranslator.java"
    replace_exact(
        player_pos_translator,
        """                ChunkRadiusUpdatedPacket chunkRadiusUpdatedPacket = new ChunkRadiusUpdatedPacket();
                chunkRadiusUpdatedPacket.setRadius(session.getServerRenderDistance());
                session.sendUpstreamPacket(chunkRadiusUpdatedPacket);""",
        """                ChunkRadiusUpdatedPacket chunkRadiusUpdatedPacket = new ChunkRadiusUpdatedPacket();
                chunkRadiusUpdatedPacket.setRadius(session.purpurAdaptiveRenderDistance());
                session.sendUpstreamPacket(chunkRadiusUpdatedPacket);""",
        "JavaPlayerPositionTranslator.dimensionRadiusCircle",
    )
    replace_exact(
        player_pos_translator,
        """            ChunkUtils.updateChunkPosition(session, entityPosition.toInt());""",
        """            // Publish exactly once. A delayed duplicate publisher update can unload and
            // reload the same ring of chunks on low-memory clients, causing a visible flash.
            ChunkUtils.forceUpdateChunkPosition(session, entityPosition.toInt());""",
        "JavaPlayerPositionTranslator.forcePublishOnSpawnAndWorldSwitch",
    )
    replace_exact(
        player_pos_translator,
        """        session.setUnconfirmedTeleport(new TeleportCache(session, teleportDestination, deltaMovement, newPitch, newYaw, teleportId, type));
        entity.moveAbsolute(teleportDestination, newYaw, newPitch, false, true);""",
        """        session.setUnconfirmedTeleport(new TeleportCache(session, teleportDestination, deltaMovement, newPitch, newYaw, teleportId, type));
        entity.moveAbsolute(teleportDestination, newYaw, newPitch, false, true);
        // A normal teleport only needs a publisher update when its chunk actually changes.
        // Forcing the same center on small corrections makes weak clients flash their chunk ring.
        ChunkUtils.updateChunkPosition(session, teleportDestination.toInt());""",
        "JavaPlayerPositionTranslator.teleportUpdateChunkPosition",
    )

    level_chunk_translator = root / "core/src/main/java/org/geysermc/geyser/translator/protocol/java/level/JavaLevelChunkWithLightTranslator.java"
    replace_exact(
        level_chunk_translator,
        """        if (session.isSpawned()) {
            ChunkUtils.updateChunkPosition(session, session.getPlayerEntity().position().toInt());
        }""",
        """        if (session.isSpawned()) {
            ChunkUtils.updateChunkPosition(session, session.getPlayerEntity().position().toInt());
        }
        ChunkUtils.ensureChunkPublished(session, packet.getX(), packet.getZ());""",
        "JavaLevelChunkWithLightTranslator.ensureChunkPublished",
    )

    chunk_batch_translator = root / "core/src/main/java/org/geysermc/geyser/translator/protocol/java/level/JavaChunkBatchFinishedTranslator.java"
    replace_exact(
        chunk_batch_translator,
        """        session.sendDownstreamGamePacket(new ServerboundChunkBatchReceivedPacket(20));""",
        """        String devOs = (session.getClientData() != null && session.getClientData().getDeviceOs() != null)
            ? session.getClientData().getDeviceOs().name()
            : "";
        boolean desktopWindows = "UWP".equals(devOs) || "WIN32".equals(devOs) || "WINDOWS".equals(devOs);
        boolean consoleClient = "XBOX".equals(devOs) || "PS4".equals(devOs) || "SWITCH".equals(devOs);
        int rtt = session.ping();
        // Keep the first world allocation below Android's low-memory kill threshold. Unknown
        // device values are constrained too; modified Android clients frequently report UNKNOWN.
        float chunksPerSecond = desktopWindows ? 24f : (consoleClient ? 12f : 6f);
        if (rtt >= 220) {
            chunksPerSecond = Math.min(chunksPerSecond, 10f);
        } else if (rtt >= 140) {
            chunksPerSecond = Math.min(chunksPerSecond, 14f);
        }
        session.sendDownstreamGamePacket(new ServerboundChunkBatchReceivedPacket(chunksPerSecond));""",
        "JavaChunkBatchFinishedTranslator.higherChunkBatchRate",
    )

    replace_exact(
        geyser_session,
        """    private int clientRenderDistance = -1;
    private int serverRenderDistance = -1;""",
        """    private int clientRenderDistance = -1;
    private int serverRenderDistance = -1;
    private volatile int measuredRttMs = -1;
    private int rttProbeTicks = 0;""",
        "GeyserSession.measuredRttFields",
    )
    replace_exact(
        geyser_session,
        """        try {
            pistonCache.tick();""",
        """        try {
            if (++this.rttProbeTicks >= 60 && this.sentSpawnPacket && getUpstream().isInitialized() && !getUpstream().isClosed()) {
                this.rttProbeTicks = 0;
                if (this.measuredRttMs < 0 || !(getUpstream().getSession().getPeer().getChannel() instanceof RakChildChannel)) {
                    sendNetworkLatencyStackPacket(System.currentTimeMillis(), false, () -> {});
                }
            }
            pistonCache.tick();""",
        "GeyserSession.nethernetRttProbeTick",
    )
    replace_exact(
        geyser_session,
        """    public void setClientRenderDistance(int clientRenderDistance) {
        boolean oldSquareToCircle = this.clientRenderDistance < this.serverRenderDistance;
        this.clientRenderDistance = clientRenderDistance;
        boolean newSquareToCircle = this.clientRenderDistance < this.serverRenderDistance;

        if (this.serverRenderDistance != -1 && oldSquareToCircle != newSquareToCircle) {
            recalculateBedrockRenderDistance();
        }
    }""",
        """    public void setClientRenderDistance(int clientRenderDistance) {
        this.clientRenderDistance = clientRenderDistance;
        if (this.serverRenderDistance != -1) {
            recalculateBedrockRenderDistance();
        }
    }""",
        "GeyserSession.alwaysAckClientRenderDistance",
    )
    replace_exact(
        geyser_session,
        """    private void recalculateBedrockRenderDistance() {
        int renderDistance = ChunkUtils.squareToCircle(this.serverRenderDistance);
        ChunkRadiusUpdatedPacket chunkRadiusUpdatedPacket = new ChunkRadiusUpdatedPacket();
        chunkRadiusUpdatedPacket.setRadius(renderDistance);
        upstream.sendPacket(chunkRadiusUpdatedPacket);
    }""",
        """    private int purpurDeviceRenderCap() {
        String os = (this.getClientData() != null && this.getClientData().getDeviceOs() != null)
            ? this.getClientData().getDeviceOs().name()
            : "UNKNOWN";
        // Keep this stable for the whole session. RTT naturally fluctuates around threshold
        // values; using it here repeatedly changed the publisher radius and made chunks unload
        // and reload (visible flashing). RTT still throttles chunk batch throughput separately.
        return switch (os) {
            case "UWP", "WIN32", "WINDOWS" -> 10;
            case "XBOX", "PS4", "SWITCH" -> 8;
            // Unknown 26.x OS values must be treated as constrained; Windows GDK is
            // normalized to UWP earlier, while old/modified Android clients often report UNKNOWN.
            default -> 5;
        };
    }

    public int purpurAdaptiveRenderDistance() {
        return getRenderDistance();
    }

    private void recalculateBedrockRenderDistance() {
        int serverDist = Math.max(this.serverRenderDistance, 6);
        int deviceCap = purpurDeviceRenderCap();
        int effectiveClientDist = this.clientRenderDistance != -1
            ? Math.min(Math.max(this.clientRenderDistance, 5), Math.min(serverDist, deviceCap))
            : Math.min(serverDist, deviceCap);
        int renderDistance = Math.max(5, effectiveClientDist);
        ChunkRadiusUpdatedPacket chunkRadiusUpdatedPacket = new ChunkRadiusUpdatedPacket();
        chunkRadiusUpdatedPacket.setRadius(renderDistance);
        upstream.sendPacket(chunkRadiusUpdatedPacket);
        if (this.playerEntity != null && (this.sentSpawnPacket || this.lastChunkPosition != null)) {
            org.cloudburstmc.math.vector.Vector3i center = this.lastChunkPosition != null && !this.sentSpawnPacket
                ? org.cloudburstmc.math.vector.Vector3i.from((this.lastChunkPosition.getX() << 4) + 8, 64, (this.lastChunkPosition.getY() << 4) + 8)
                : this.playerEntity.position().toInt();
            ChunkUtils.forceUpdateChunkPosition(this, center);
        }
    }""",
        "GeyserSession.recalculateRenderDistanceRepublish",
    )
    replace_exact(
        geyser_session,
        """    private int getRenderDistance() {
        if (clientRenderDistance != -1) {
            // The client has sent a render distance
            return clientRenderDistance;
        } else if (serverRenderDistance != -1) {
            // only known once ClientboundLoginPacket is received
            return serverRenderDistance;
        }
        return 2; // unfortunate default until we got more info
    }""",
        """    private int getRenderDistance() {
        int cap = purpurDeviceRenderCap();
        if (clientRenderDistance != -1) {
            return Math.max(5, Math.min(clientRenderDistance, cap));
        } else if (serverRenderDistance != -1) {
            return Math.max(5, Math.min(serverRenderDistance, cap));
        }
        return Math.min(6, cap);
    }""",
        "GeyserSession.preventTinyInitialRenderDistance",
    )
    replace_exact(
        geyser_session,
        """    @Override
    public int ping() {
        // Can otherwise cause issues if the player isn't logged in yet / already left
        if (!getUpstream().isInitialized() || getUpstream().isClosed()) {
            return 0;
        }

        // TODO fixme
        // TODO NetherNet: expose the WebRTC round trip time
        if (!(getUpstream().getSession().getPeer().getChannel() instanceof RakChildChannel rakChannel)) {
            return 0;
        }

        RakSessionCodec rakSessionCodec = rakChannel.rakPipeline().get(RakSessionCodec.class);
        return (int) Math.floor(rakSessionCodec.getPing());
    }""",
        """    @Override
    public int ping() {
        if (!getUpstream().isInitialized() || getUpstream().isClosed()) {
            return Math.max(0, this.measuredRttMs);
        }

        if (getUpstream().getSession().getPeer().getChannel() instanceof RakChildChannel rakChannel) {
            RakSessionCodec rakSessionCodec = rakChannel.rakPipeline().get(RakSessionCodec.class);
            if (rakSessionCodec != null) {
                double rawPing = rakSessionCodec.getPing();
                if (rawPing > 0.0) {
                    return Math.max(1, (int) Math.round(rawPing));
                }
            }
        }

        return Math.max(0, this.measuredRttMs);
    }""",
        "GeyserSession.realRakNetAndNetherNetPing",
    )
    replace_exact(
        geyser_session,
        """    public void sendNetworkLatencyStackPacket(long timestamp, boolean ensureEventLoop, Runnable runnable) {
        NetworkStackLatencyPacket latencyPacket = new NetworkStackLatencyPacket();
        latencyPacket.setFromServer(true);
        latencyPacket.setTimestamp(timestamp);
        if (ensureEventLoop) {
            latencyPingCache.add(() -> ensureInEventLoop(runnable));
        } else {
            latencyPingCache.add(runnable);
        }
        sendUpstreamPacket(latencyPacket);
    }""",
        """    public void sendNetworkLatencyStackPacket(long timestamp, boolean ensureEventLoop, Runnable runnable) {
        final long sentAtNanos = System.nanoTime();
        Runnable timedCallback = () -> {
            this.measuredRttMs = Math.max(1, (int) Math.round((System.nanoTime() - sentAtNanos) / 1_000_000.0));
            runnable.run();
        };
        NetworkStackLatencyPacket latencyPacket = new NetworkStackLatencyPacket();
        latencyPacket.setFromServer(true);
        latencyPacket.setTimestamp(timestamp);
        if (ensureEventLoop) {
            latencyPingCache.add(() -> ensureInEventLoop(timedCallback));
        } else {
            latencyPingCache.add(timedCallback);
        }
        sendUpstreamPacket(latencyPacket);
    }""",
        "GeyserSession.measureLatencyStackRtt",
    )

    # 11. RaknetServer.java & BedrockClientData.java:
    #     - Prevent Cloudburst RakServerRateLimiter (default 120 datagrams/10ms) from blacklisting legitimate
    #       26.60 PC/CGNAT players during resource-pack (.mcpack), chunk-burst, or high-CPS gameplay.
    #     - Support Microsoft Windows GDK DeviceOS ordinal (16+) in Bedrock 26.x so PC clients (e.g. ZET Gaming / ASUS / MSI)
    #       resolve to DeviceOs.UWP ("Windows") instead of DeviceOs.UNKNOWN (which caused VoidTab to show kbmouse!).
    raknet_server = root / "core/src/main/java/org/geysermc/geyser/network/RaknetServer.java"
    replace_exact(
        raknet_server,
        """        int rakPacketLimit = positivePropOrDefault("Geyser.RakPacketLimit", DEFAULT_PACKET_LIMIT);
        this.geyser.getLogger().debug("Setting RakNet packet limit to " + rakPacketLimit);

        int rakGlobalPacketLimit = positivePropOrDefault("Geyser.RakGlobalPacketLimit", DEFAULT_GLOBAL_PACKET_LIMIT);
        this.geyser.getLogger().debug("Setting RakNet global packet limit to " + rakGlobalPacketLimit);

        boolean rakSendCookie = Boolean.parseBoolean(System.getProperty("Geyser.RakSendCookie", "true"));
        this.geyser.getLogger().debug("Setting RakNet send cookie to " + rakSendCookie);

        int maxConnectionsPerAddress =  positivePropOrDefault("Geyser.MaxConnectionsPerAddress", 10);""",
        """        int rakPacketLimit = positivePropOrDefault("Geyser.RakPacketLimit", Math.max(3000, DEFAULT_PACKET_LIMIT));
        this.geyser.getLogger().debug("Setting RakNet packet limit to " + rakPacketLimit);

        int rakGlobalPacketLimit = positivePropOrDefault("Geyser.RakGlobalPacketLimit", Math.max(300000, DEFAULT_GLOBAL_PACKET_LIMIT));
        this.geyser.getLogger().debug("Setting RakNet global packet limit to " + rakGlobalPacketLimit);

        // Keep stateless cookies enabled: they prove ownership of the source endpoint and let
        // a new handshake safely close a stale child channel immediately on the second join.
        boolean rakSendCookie = Boolean.parseBoolean(System.getProperty("Geyser.RakSendCookie", "true"));
        this.geyser.getLogger().debug("Setting RakNet send cookie to " + rakSendCookie);

        int maxConnectionsPerAddress = positivePropOrDefault("Geyser.MaxConnectionsPerAddress", 100);""",
        "RaknetServer.safeRateLimitsForPackAndCgnat",
    )

    client_data = root / "core/src/main/java/org/geysermc/geyser/session/auth/BedrockClientData.java"
    replace_exact(
        client_data,
        """    public DeviceOs getDeviceOs() {
        return deviceOs != null ? deviceOs : DeviceOs.UNKNOWN;
    }""",
        """    public DeviceOs getDeviceOs() {
        if (deviceOs != null && deviceOs != DeviceOs.UNKNOWN) {
            return deviceOs;
        }
        String modelUpper = deviceModel == null ? "" : deviceModel.trim().toUpperCase(java.util.Locale.ROOT);
        if (modelUpper.contains("PLAYSTATION") || modelUpper.startsWith("PS4") || modelUpper.startsWith("PS5")) {
            return DeviceOs.PS4;
        }
        if (modelUpper.contains("XBOX")) {
            return DeviceOs.XBOX;
        }
        if (modelUpper.startsWith("IPHONE") || modelUpper.startsWith("IPAD")) {
            return DeviceOs.IOS;
        }
        if (defaultInputMode == InputMode.KEYBOARD_MOUSE
            || currentInputMode == InputMode.KEYBOARD_MOUSE
            || uiProfile == UiProfile.CLASSIC) {
            // Bedrock 26.x Microsoft GDK for Windows sends DeviceOS >= 16 (outside legacy Floodgate enum)
            return DeviceOs.UWP;
        }
        if (defaultInputMode == InputMode.CONTROLLER || currentInputMode == InputMode.CONTROLLER) {
            return DeviceOs.XBOX;
        }
        return DeviceOs.UNKNOWN;
    }""",
        "BedrockClientData.windowsGdkGetDeviceOs",
    )
    replace_exact(
        client_data,
        """                public T read(JsonReader in) throws IOException {
                    int ordinal = in.nextInt();
                    if (ordinal < 0 || ordinal >= constants.length) {
                        return null;
                    }
                    return constants[ordinal];
                }""",
        """                @SuppressWarnings("unchecked")
                public T read(JsonReader in) throws IOException {
                    int ordinal = in.nextInt();
                    if (ordinal < 0 || ordinal >= constants.length) {
                        if (rawType == DeviceOs.class && ordinal >= constants.length) {
                            return (T) DeviceOs.UWP;
                        }
                        return null;
                    }
                    return constants[ordinal];
                }""",
        "BedrockClientData.windowsGdkOrdinalMapping",
    )

    # 12. Purpurbedrock Geyser Performance & Main-Thread Optimization Suite:
    #     - Async background pre-warm of Geyser registries during plugin enable so ServerLoadEvent spends ~0.00ms on Server thread.
    #     - Thread-safe O(1) VersionedRegistry cache + on-demand lazy loading for legacy (< 26.50 / < v2193) block, item, tag & potion palettes
    #       (cuts boot CPU by ~90% and saves ~350 MB of heap RAM when only modern 26.x players are online, while preserving 100% 1.21.0..26.60 support).
    #     - Algorithmic O(1) fixes in BlockRegistryPopulator, ItemRegistryPopulator, and TagRegistryPopulator (eliminating O(N^2) linear scans and NbtMap churn).
    #     - Runtime hot-path fixes: O(1) UUID player lookup in GeyserSpigotNativeWorldManager, lazy locale loading in SpigotCommandSource
    #       (fixing BrigadierPermissionPredicate.test() overhead), accurate GeyserChunkSection buffer sizing + zero-alloc empty subchunks +
    #       BitSet BedrockChunkWantsBlockEntityTag lookup in JavaLevelChunkWithLightTranslator, idle ScoreboardUpdater backoff, and disabled join update HTTP check.

    versioned_registry = root / "core/src/main/java/org/geysermc/geyser/registry/VersionedRegistry.java"
    replace_exact(
        versioned_registry,
        """public class VersionedRegistry<V> extends AbstractMappedRegistry<Integer, V, Int2ObjectMap<V>> {
    protected <I> VersionedRegistry(I input, RegistryLoader<I, Int2ObjectMap<V>> registryLoader) {
        super(input, registryLoader);
    }

    /**
     * Gets the closest value for the specified version. Only
     * returns versions higher up than the specified if one
     * does not exist for the given one. Useful in the event
     * that you want to get a resource which is guaranteed for
     * older versions, but not on newer ones.
     *
     * @param version the version
     * @return the closest value for the specified version
     * @throws IllegalArgumentException if no values exist at or above the given version
     */
    @NonNull
    public V forVersion(int version) {
        Int2ObjectMap.Entry<V> current = null;
        for (Int2ObjectMap.Entry<V> entry : this.mappings.int2ObjectEntrySet()) {
            int currentVersion = entry.getIntKey();
            if (version < currentVersion) {
                continue;
            }
            if (version == currentVersion) {
                return entry.getValue();
            }
            if (current == null || current.getIntKey() < currentVersion) {
                // This version is newer and should be prioritized
                current = entry;
            }
        }
        if (current == null) {
            throw new IllegalArgumentException("No appropriate value for version: " + version);
        }
        return current.getValue();
    }""",
        """public class VersionedRegistry<V> extends AbstractMappedRegistry<Integer, V, Int2ObjectMap<V>> {
    private final Int2ObjectMap<java.util.function.IntFunction<V>> lazyLoaders =
            new it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap<>();
    private final java.util.concurrent.ConcurrentHashMap<Integer, V> resolvedCache =
            new java.util.concurrent.ConcurrentHashMap<>();

    protected <I> VersionedRegistry(I input, RegistryLoader<I, Int2ObjectMap<V>> registryLoader) {
        super(input, registryLoader);
    }

    @Override
    public V register(Integer key, V value) {
        synchronized (this) {
            V previous = super.register(key, value);
            if (key != null) {
                this.lazyLoaders.remove(key.intValue());
            }
            this.resolvedCache.clear();
            return previous;
        }
    }

    public void registerLazy(int version, java.util.function.IntFunction<V> loader) {
        synchronized (this) {
            if (!this.mappings.containsKey(version)) {
                this.lazyLoaders.put(version, loader);
                this.resolvedCache.clear();
            }
        }
    }

    public int[] lazyVersions() {
        synchronized (this) {
            return this.lazyLoaders.keySet().toIntArray();
        }
    }

    /**
     * Gets the closest value for the specified version. Only
     * returns versions higher up than the specified if one
     * does not exist for the given one. Useful in the event
     * that you want to get a resource which is guaranteed for
     * older versions, but not on newer ones.
     *
     * @param version the version
     * @return the closest value for the specified version
     * @throws IllegalArgumentException if no values exist at or above the given version
     */
    @NonNull
    public V forVersion(int version) {
        V cached = this.resolvedCache.get(version);
        if (cached != null) {
            return cached;
        }
        synchronized (this) {
            cached = this.resolvedCache.get(version);
            if (cached != null) {
                return cached;
            }
            int bestVersion = Integer.MIN_VALUE;
            boolean bestIsLazy = false;
            for (Int2ObjectMap.Entry<V> entry : this.mappings.int2ObjectEntrySet()) {
                int v = entry.getIntKey();
                if (v <= version && v > bestVersion) {
                    bestVersion = v;
                    bestIsLazy = false;
                }
            }
            for (Int2ObjectMap.Entry<java.util.function.IntFunction<V>> entry : this.lazyLoaders.int2ObjectEntrySet()) {
                int v = entry.getIntKey();
                if (v <= version && v > bestVersion) {
                    bestVersion = v;
                    bestIsLazy = true;
                }
            }
            if (bestVersion == Integer.MIN_VALUE) {
                throw new IllegalArgumentException("No appropriate value for version: " + version);
            }
            V resolved;
            if (bestIsLazy) {
                java.util.function.IntFunction<V> loader = this.lazyLoaders.remove(bestVersion);
                resolved = loader.apply(bestVersion);
                this.mappings.put(bestVersion, resolved);
            } else {
                resolved = this.mappings.get(bestVersion);
            }
            this.resolvedCache.put(version, resolved);
            return resolved;
        }
    }""",
        "VersionedRegistry.lazyAndCachedForVersion",
    )

    versioned_deferred = root / "core/src/main/java/org/geysermc/geyser/registry/VersionedDeferredRegistry.java"
    replace_exact(
        versioned_deferred,
        """    @NonNull
    public V forVersion(int version) {
        return backingRegistry().forVersion(version);
    }""",
        """    @NonNull
    public V forVersion(int version) {
        return backingRegistry().forVersion(version);
    }

    public void registerLazy(int version, java.util.function.IntFunction<V> loader) {
        backingRegistry().registerLazy(version, loader);
    }""",
        "VersionedDeferredRegistry.registerLazy",
    )

    block_registries = root / "core/src/main/java/org/geysermc/geyser/registry/BlockRegistries.java"
    replace_exact(
        block_registries,
        """    public static final SimpleRegistry<BitSet> WATERLOGGED = SimpleRegistry.create(RegistryLoaders.empty(BitSet::new));""",
        """    public static final SimpleRegistry<BitSet> WATERLOGGED = SimpleRegistry.create(RegistryLoaders.empty(BitSet::new));

    public static final BitSet BEDROCK_CHUNK_BLOCK_ENTITIES = new BitSet();""",
        "BlockRegistries.BEDROCK_CHUNK_BLOCK_ENTITIES",
    )

    replace_exact(
        block_populator,
        """    /**
     * Stores the raw blocks NBT until it is no longer needed.
     */
    private static List<NbtMap> BLOCKS_NBT;
    public static int MIN_CUSTOM_RUNTIME_ID = -1;
    public static int JAVA_BLOCKS_SIZE = -1;

    private static void nullifyBlocksNbt() {
        BLOCKS_NBT = null;
    }

    private static void registerBedrockBlocks() {
        var blockMappers = ImmutableMap.<ObjectIntPair<String>, Remapper>builder()
                .put(ObjectIntPair.of("1_21_0", 685), tag -> tag)
                .put(ObjectIntPair.of("1_21_20", 712), tag -> tag)
                .put(ObjectIntPair.of("1_21_30", 729), tag -> tag)
                .put(ObjectIntPair.of("1_21_40", 748), tag -> tag)
                .put(ObjectIntPair.of("1_21_50", 766), tag -> tag)
                .put(ObjectIntPair.of("1_21_60", 776), tag -> tag)
                .put(ObjectIntPair.of("1_21_70", 786), tag -> tag)
                .put(ObjectIntPair.of("1_21_80", 800), tag -> tag)
                .put(ObjectIntPair.of("1_21_90", 818), tag -> tag)
                .put(ObjectIntPair.of("1_21_100", 827), tag -> tag)
                .put(ObjectIntPair.of("1_21_110", 844), tag -> tag)
                .put(ObjectIntPair.of("1_21_130", 898), tag -> tag)
                .put(ObjectIntPair.of("1_26_10", 944), tag -> tag)
                .put(ObjectIntPair.of("1_26_20", 975), tag -> tag)
                .put(ObjectIntPair.of("26_30", Bedrock_v1001.CODEC.getProtocolVersion()), tag -> tag)
                .put(ObjectIntPair.of("26_40", Bedrock_v2168.CODEC.getProtocolVersion()), tag -> tag)
                .put(ObjectIntPair.of("26_50", Bedrock_v2193.CODEC.getProtocolVersion()), tag -> tag)
                .put(ObjectIntPair.of("26_60", Bedrock_v2225.CODEC.getProtocolVersion()), tag -> tag)
            .build();

        // We can keep this strong as nothing should be garbage collected
        // Safe to intern since Cloudburst NBT is immutable
        //noinspection UnstableApiUsage
        Interner<NbtMap> statesInterner = Interners.newStrongInterner();

        for (ObjectIntPair<String> palette : blockMappers.keySet()) {
            int protocolVersion = palette.valueInt();
            List<NbtMap> vanillaBlockStates;
            List<NbtMap> blockStates;
            try (InputStream stream = GeyserImpl.getInstance().getBootstrap().getResourceOrThrow(String.format("bedrock/block_palette.%s.nbt", palette.key()));
                NBTInputStream nbtInputStream = new NBTInputStream(new DataInputStream(new GZIPInputStream(stream)), true, true)) {
                NbtMap blockPalette = (NbtMap) nbtInputStream.readTag();

                vanillaBlockStates = new ArrayList<>(blockPalette.getList("blocks", NbtType.COMPOUND));
                for (int i = 0; i < vanillaBlockStates.size(); i++) {
                    NbtMapBuilder builder = vanillaBlockStates.get(i).toBuilder();
                    builder.remove("version"); // Remove all nbt tags which are not needed for differentiating states
                    builder.remove("name_hash"); // Quick workaround - was added in 1.19.20
                    builder.remove("network_id"); // Added in 1.19.80
                    builder.remove("block_id"); // Added in 1.20.60
                    //noinspection UnstableApiUsage
                    builder.putCompound("states", statesInterner.intern((NbtMap) builder.remove("states")));
                    vanillaBlockStates.set(i, builder.build());
                }

                blockStates = new ArrayList<>(vanillaBlockStates);
            } catch (Exception e) {
                throw new AssertionError("Unable to get blocks from runtime block states", e);
            }

            List<BlockPropertyData> customBlockProperties = new ArrayList<>();
            List<NbtMap> customBlockStates = new ArrayList<>();
            List<CustomBlockState> customExtBlockStates = new ArrayList<>();
            int[] remappedVanillaIds = new int[0];

            // TODO Make this throw once we drop any version below 26.50, as it's required in 26.50+
            InputStream stream = GeyserImpl.getInstance().getBootstrap().getResourceOrNull(String.format("bedrock/data_driven_blocks.%s.nbt", palette.key()));
            if (stream != null) {
                // Data-driven blocks!!!
                try (stream; NBTInputStream nbtInputStream = new NBTInputStream(new DataInputStream(new GZIPInputStream(stream)))) {
                    NbtMap dataDrivenBlocks = (NbtMap) nbtInputStream.readTag();
                    for (Map.Entry<String, Object> entry : dataDrivenBlocks.entrySet()) {
                        customBlockProperties.add(new BlockPropertyData(entry.getKey(), (NbtMap) entry.getValue()));
                    }
                } catch (IOException e) {
                    throw new AssertionError("Unable to get data driven blocks from runtime definitions", e);
                }
            }

            if (BlockRegistries.CUSTOM_BLOCKS.get().length != 0) {
                CustomBlockRegistryPopulator.BLOCK_ID.set(CustomBlockRegistryPopulator.START_OFFSET);
                for (CustomBlockData customBlock : BlockRegistries.CUSTOM_BLOCKS.get()) {
                    customBlockProperties.add(CustomBlockRegistryPopulator.generateBlockPropertyData(customBlock));
                    CustomBlockRegistryPopulator.generateCustomBlockStates(customBlock, customBlockStates, customExtBlockStates);
                }
                blockStates.addAll(customBlockStates);
                GeyserImpl.getInstance().getLogger().debug("Added " + customBlockStates.size() + " custom block states to v" + protocolVersion + " palette.");

                // The palette is sorted by the FNV1 64-bit hash of the name
                blockStates.sort((a, b) -> Long.compareUnsigned(fnv164(a.getString("name")), fnv164(b.getString("name"))));
            }

            // New since 1.16.100 - find the block runtime ID by the order given to us in the block palette,
            // as we no longer send a block palette
            Object2ObjectMap<NbtMap, GeyserBedrockBlock> blockStateOrderedMap = new Object2ObjectOpenHashMap<>(blockStates.size());
            Map<String, List<GeyserBedrockBlock>> blocksByName = new Object2ObjectOpenHashMap<>();
            GeyserBedrockBlock[] bedrockRuntimeMap = new GeyserBedrockBlock[blockStates.size()];
            for (int i = 0; i < blockStates.size(); i++) {
                NbtMap tag = blockStates.get(i);
                GeyserBedrockBlock block = new GeyserBedrockBlock(i, tag);
                if (blockStateOrderedMap.put(tag, block) != null) {
                    throw new AssertionError("Duplicate block states in Bedrock palette: " + tag);
                }
                bedrockRuntimeMap[i] = block;
                blocksByName.computeIfAbsent(tag.getString("name"), k -> new ArrayList<>()).add(block);
            }

            Object2ObjectMap<CustomBlockState, GeyserBedrockBlock> customBlockStateDefinitions = Object2ObjectMaps.emptyMap();
            if (BlockRegistries.CUSTOM_BLOCKS.get().length != 0) {
                customBlockStateDefinitions = new Object2ObjectOpenHashMap<>(customExtBlockStates.size());
                for (int i = 0; i < customExtBlockStates.size(); i++) {
                    NbtMap tag = customBlockStates.get(i);
                    CustomBlockState blockState = customExtBlockStates.get(i);
                    GeyserBedrockBlock bedrockBlock = blockStateOrderedMap.get(tag);
                    customBlockStateDefinitions.put(blockState, bedrockBlock);
                }

                remappedVanillaIds = new int[vanillaBlockStates.size()];
                for (int i = 0; i < vanillaBlockStates.size(); i++) {
                    GeyserBedrockBlock bedrockBlock = blockStateOrderedMap.get(vanillaBlockStates.get(i));
                    remappedVanillaIds[i] = bedrockBlock != null ? bedrockBlock.getRuntimeId() : -1;
                }
            }

            int javaRuntimeId = -1;

            List<BlockState> javaBlockStates = BlockRegistries.BLOCK_STATES.get();

            GeyserBedrockBlock airDefinition = null;
            BlockDefinition commandBlockDefinition = null;
            BlockDefinition mobSpawnerBlockDefinition = null;
            BlockDefinition netherPortalBlockDefinition = null;
            BlockDefinition waterDefinition = null;
            BlockDefinition movingBlockDefinition = null;
            Iterator<NbtMap> blocksIterator = BLOCKS_NBT.iterator();

            Remapper stateMapper = blockMappers.get(palette);

            GeyserBedrockBlock[] javaToBedrockBlocks = new GeyserBedrockBlock[JAVA_BLOCKS_SIZE];
            GeyserBedrockBlock[] javaToVanillaBedrockBlocks = new GeyserBedrockBlock[JAVA_BLOCKS_SIZE];

            var javaToBedrockIdentifiers = new Int2ObjectOpenHashMap<String>();
            Block lastBlockSeen = null;

            // Stream isn't ideal.
            List<Block> javaPottable = BlockRegistries.JAVA_BLOCKS.get()
                    .parallelStream()
                    .flatMap(block -> {
                        if (block instanceof FlowerPotBlock flowerPot && flowerPot.flower() != Blocks.AIR) {
                            return Stream.of(flowerPot.flower());
                        }
                        return null;
                    })
                    .toList();
            Map<Block, NbtMap> flowerPotBlocks = new Object2ObjectOpenHashMap<>();
            Map<NbtMap, BlockDefinition> itemFrames = new Object2ObjectOpenHashMap<>();
            IntArrayList collisionIgnoredBlocks = new IntArrayList();

            Set<BlockDefinition> jigsawDefinitions = new ObjectOpenHashSet<>();
            Map<String, BlockDefinition> structureBlockDefinitions = new Object2ObjectOpenHashMap<>();

            BlockMappings.BlockMappingsBuilder builder = BlockMappings.builder();
            while (blocksIterator.hasNext()) {
                javaRuntimeId++;
                NbtMap entry = blocksIterator.next();
                BlockState blockState = javaBlockStates.get(javaRuntimeId);
                String javaId = blockState.toString();

                NbtMap originalBedrockTag = buildBedrockState(blockState, entry);
                NbtMap bedrockTag = MultiVersionPaletteHelper.remapBlockForVersion(protocolVersion, blockState, stateMapper.remap(originalBedrockTag));

                GeyserBedrockBlock vanillaBedrockDefinition = MultiVersionPaletteHelper.resolveBlockDefinition(bedrockTag, blockStateOrderedMap, blocksByName);

                GeyserBedrockBlock bedrockDefinition;
                CustomBlockState blockStateOverride = BlockRegistries.CUSTOM_BLOCK_STATE_OVERRIDES.get(javaRuntimeId);
                if (blockStateOverride == null) {
                    bedrockDefinition = vanillaBedrockDefinition;
                    if (bedrockDefinition == null) {
                        throw new RuntimeException(\"\"\"
                            Unable to find %s Bedrock runtime ID for %s! Original block tag:
                            %s
                            Updated block tag:
                            %s\"\"\".formatted(javaId, palette.key(), originalBedrockTag, bedrockTag));
                    }
                } else {
                    bedrockDefinition = customBlockStateDefinitions.get(blockStateOverride);
                    if (bedrockDefinition == null) {
                        throw new RuntimeException("Unable to find " + javaId + " Bedrock runtime ID! Custom block override: \\n" +
                            blockStateOverride);
                    }
                }

                switch (javaId) {
                    case "minecraft:air" -> airDefinition = bedrockDefinition;
                    case "minecraft:water[level=0]" -> waterDefinition = bedrockDefinition;
                    case "minecraft:command_block[conditional=false,facing=north]" -> commandBlockDefinition = bedrockDefinition;
                    case "minecraft:spawner" -> mobSpawnerBlockDefinition = bedrockDefinition;
                    case "minecraft:moving_piston[facing=north,type=normal]" -> movingBlockDefinition = bedrockDefinition;
                }

                Block block = blockState.block();
                if (block != lastBlockSeen) {
                    lastBlockSeen = block;
                    String bedrockName = bedrockDefinition.getState().getString("name");
                    if (!block.javaIdentifier().toString().equals(bedrockName)) {
                        javaToBedrockIdentifiers.put(block.javaId(), bedrockName.substring("minecraft:".length()).intern());
                    }
                }

                if (block == Blocks.JIGSAW) {
                    jigsawDefinitions.add(bedrockDefinition);
                }

                if (block == Blocks.STRUCTURE_BLOCK) {
                    String mode = blockState.getValue(Properties.STRUCTUREBLOCK_MODE);
                    structureBlockDefinitions.put(mode.toUpperCase(Locale.ROOT), bedrockDefinition);
                }

                if (block == Blocks.NETHER_PORTAL) {
                    netherPortalBlockDefinition = bedrockDefinition;
                }

                if (block == Blocks.BAMBOO || block == Blocks.POINTED_DRIPSTONE) {
                    collisionIgnoredBlocks.add(javaRuntimeId);
                }

                boolean waterlogged = blockState.getValue(Properties.WATERLOGGED, false)
                        || block == Blocks.BUBBLE_COLUMN || block == Blocks.KELP || block == Blocks.KELP_PLANT
                        || block == Blocks.SEAGRASS || block == Blocks.TALL_SEAGRASS;

                if (waterlogged) {
                    BlockRegistries.WATERLOGGED.get().set(javaRuntimeId);
                }

                // Get the tag needed for non-empty flower pots
                if (javaPottable.contains(block)) {
                    // Specifically NOT putIfAbsent - mangrove propagule breaks otherwise
                    flowerPotBlocks.put(block, blockStates.get(bedrockDefinition.getRuntimeId()));
                }

                javaToVanillaBedrockBlocks[javaRuntimeId] = vanillaBedrockDefinition;
                javaToBedrockBlocks[javaRuntimeId] = bedrockDefinition;
            }

            builder.collisionIgnoredBlocks(collisionIgnoredBlocks);

            if (commandBlockDefinition == null) {
                throw new AssertionError("Unable to find command block in palette");
            }
            builder.commandBlock(commandBlockDefinition);

            if (mobSpawnerBlockDefinition == null) {
                throw new AssertionError("Unable to find mob spawner block in palette");
            }
            builder.mobSpawnerBlock(mobSpawnerBlockDefinition);

            if (netherPortalBlockDefinition == null) {
                throw new AssertionError("Unable to find nether portal block in palette");
            }
            builder.netherPortalBlock(netherPortalBlockDefinition);

            if (waterDefinition  == null) {
                throw new AssertionError("Unable to find water in palette");
            }
            builder.bedrockWater(waterDefinition);

            if (airDefinition  == null) {
                throw new AssertionError("Unable to find air in palette");
            }
            builder.bedrockAir(airDefinition);

            if (movingBlockDefinition  == null) {
                throw new AssertionError("Unable to find moving block in palette");
            }
            builder.bedrockMovingBlock(movingBlockDefinition);

            Map<JavaBlockState, CustomBlockState> nonVanillaStateOverrides = BlockRegistries.NON_VANILLA_BLOCK_STATE_OVERRIDES.get();
            if (!nonVanillaStateOverrides.isEmpty()) {
                // First ensure all non vanilla runtime IDs at minimum are air in case they aren't consecutive
                Arrays.fill(javaToVanillaBedrockBlocks, MIN_CUSTOM_RUNTIME_ID, javaToVanillaBedrockBlocks.length, airDefinition);
                Arrays.fill(javaToBedrockBlocks, MIN_CUSTOM_RUNTIME_ID, javaToBedrockBlocks.length, airDefinition);

                for (Map.Entry<JavaBlockState, CustomBlockState> entry : nonVanillaStateOverrides.entrySet()) {
                    GeyserBedrockBlock bedrockDefinition = customBlockStateDefinitions.get(entry.getValue());
                    if (bedrockDefinition == null) {
                        GeyserImpl.getInstance().getLogger().warning("Unable to find custom block for " + entry.getValue());
                        continue;
                    }

                    JavaBlockState javaState = entry.getKey();
                    int stateRuntimeId = javaState.javaId();

                    boolean waterlogged = javaState.waterlogged();

                    if (waterlogged) {
                        BlockRegistries.WATERLOGGED.register(set -> set.set(stateRuntimeId));
                    }

                    javaToVanillaBedrockBlocks[stateRuntimeId] = bedrockDefinition; // TODO: Check this?
                    javaToBedrockBlocks[stateRuntimeId] = bedrockDefinition;
                    javaToBedrockIdentifiers.put(entry.getKey().stateGroupId(), entry.getValue().block().identifier());
                }
            }

            javaToBedrockIdentifiers.trim();

            // Loop around again to find all item frame runtime IDs
            Object2ObjectMaps.fastForEach(blockStateOrderedMap, entry -> {
                String name = entry.getKey().getString("name");
                if (name.equals("minecraft:frame") || name.equals("minecraft:glow_frame")) {
                    itemFrames.put(entry.getKey(), entry.getValue());
                }
            });

            BlockRegistries.BLOCKS.register(palette.valueInt(), builder.bedrockRuntimeMap(bedrockRuntimeMap)
                    .javaToBedrockBlocks(javaToBedrockBlocks)
                    .javaToVanillaBedrockBlocks(javaToVanillaBedrockBlocks)
                    .javaToBedrockIdentifiers(javaToBedrockIdentifiers)
                    .stateDefinitionMap(blockStateOrderedMap)
                    .itemFrames(itemFrames)
                    .flowerPotBlocks(flowerPotBlocks)
                    .jigsawStates(jigsawDefinitions)
                    .structureBlockStates(structureBlockDefinitions)
                    .remappedVanillaIds(remappedVanillaIds)
                    .blockProperties(customBlockProperties)
                    .customBlockStateDefinitions(customBlockStateDefinitions)
                    .build());
        }
    }

    private static void registerJavaBlocks() {
        List<NbtMap> blocksNbt;
        try (InputStream stream = GeyserImpl.getInstance().getBootstrap().getResourceOrThrow("mappings/blocks.nbt")) {
            blocksNbt = ((NbtMap) NbtUtils.createGZIPReader(stream).readTag())
                    .getList("bedrock_mappings", NbtType.COMPOUND);
        } catch (Exception e) {
            throw new AssertionError("Unable to load Java block mappings", e);
        }

        int javaRuntimeId = -1;
        for (BlockState javaBlockState : BlockRegistries.BLOCK_STATES.get()) {
            javaRuntimeId++;
            String javaId = javaBlockState.toString().intern();

            BlockRegistries.JAVA_BLOCK_STATE_IDENTIFIER_TO_ID.register(javaId, javaRuntimeId);
        }

        BLOCKS_NBT = blocksNbt;
        JAVA_BLOCKS_SIZE = blocksNbt.size();

        JsonObject blockInteractionsJson;
        try (InputStream stream = GeyserImpl.getInstance().getBootstrap().getResourceOrThrow("mappings/interactions.json")) {
            blockInteractionsJson = JsonUtils.fromJson(stream);
        } catch (Exception e) {
            throw new AssertionError("Unable to load Java block interaction mappings", e);
        }

        BlockRegistries.INTERACTIVE.set(toBlockStateSet(blockInteractionsJson.getAsJsonArray("always_consumes")));
        BlockRegistries.INTERACTIVE_MAY_BUILD.set(toBlockStateSet(blockInteractionsJson.getAsJsonArray("requires_may_build")));
    }""",
        """    @SuppressWarnings("UnstableApiUsage")
    private static final Interner<NbtMap> STATES_INTERNER = Interners.newStrongInterner();
    private static List<NbtMap> BLOCKS_NBT;
    private static NbtMap[] BASE_BEDROCK_TAGS;
    private static Set<Block> POTTABLE_JAVA_BLOCKS;
    private static IntArrayList SHARED_COLLISION_IGNORED_BLOCKS;
    private static int AIR_JAVA_ID = -1;
    private static int WATER_LEVEL0_JAVA_ID = -1;
    private static int CMD_BLOCK_NORTH_JAVA_ID = -1;
    private static int SPAWNER_JAVA_ID = -1;
    private static int MOVING_PISTON_NORTH_JAVA_ID = -1;
    public static int MIN_CUSTOM_RUNTIME_ID = -1;
    public static int JAVA_BLOCKS_SIZE = -1;

    private static void nullifyBlocksNbt() {
        BLOCKS_NBT = null;
    }

    private static void registerBedrockBlocks() {
        var blockMappers = ImmutableMap.<ObjectIntPair<String>, Remapper>builder()
                .put(ObjectIntPair.of("1_21_0", 685), tag -> tag)
                .put(ObjectIntPair.of("1_21_20", 712), tag -> tag)
                .put(ObjectIntPair.of("1_21_30", 729), tag -> tag)
                .put(ObjectIntPair.of("1_21_40", 748), tag -> tag)
                .put(ObjectIntPair.of("1_21_50", 766), tag -> tag)
                .put(ObjectIntPair.of("1_21_60", 776), tag -> tag)
                .put(ObjectIntPair.of("1_21_70", 786), tag -> tag)
                .put(ObjectIntPair.of("1_21_80", 800), tag -> tag)
                .put(ObjectIntPair.of("1_21_90", 818), tag -> tag)
                .put(ObjectIntPair.of("1_21_100", 827), tag -> tag)
                .put(ObjectIntPair.of("1_21_110", 844), tag -> tag)
                .put(ObjectIntPair.of("1_21_130", 898), tag -> tag)
                .put(ObjectIntPair.of("1_26_10", 944), tag -> tag)
                .put(ObjectIntPair.of("1_26_20", 975), tag -> tag)
                .put(ObjectIntPair.of("26_30", Bedrock_v1001.CODEC.getProtocolVersion()), tag -> tag)
                .put(ObjectIntPair.of("26_40", Bedrock_v2168.CODEC.getProtocolVersion()), tag -> tag)
                .put(ObjectIntPair.of("26_50", Bedrock_v2193.CODEC.getProtocolVersion()), tag -> tag)
                .put(ObjectIntPair.of("26_60", Bedrock_v2225.CODEC.getProtocolVersion()), tag -> tag)
            .build();

        ensureSharedJavaBlockTables();
        boolean eagerAll = Boolean.getBoolean("purpurbedrock.eagerAllPalettes");
        int primaryProto = Bedrock_v2225.CODEC.getProtocolVersion();

        for (Map.Entry<ObjectIntPair<String>, Remapper> entry : blockMappers.entrySet()) {
            ObjectIntPair<String> palette = entry.getKey();
            Remapper stateMapper = entry.getValue();
            int protocolVersion = palette.valueInt();
            if (eagerAll || protocolVersion == primaryProto) {
                BlockRegistries.BLOCKS.register(protocolVersion, buildBedrockPalette(palette, stateMapper));
            } else {
                BlockRegistries.BLOCKS.registerLazy(protocolVersion, ver -> buildBedrockPalette(palette, stateMapper));
            }
        }
    }

    @SuppressWarnings("UnstableApiUsage")
    private static synchronized void ensureSharedJavaBlockTables() {
        if (BASE_BEDROCK_TAGS != null && BASE_BEDROCK_TAGS.length == JAVA_BLOCKS_SIZE) {
            return;
        }
        List<BlockState> javaBlockStates = BlockRegistries.BLOCK_STATES.get();
        BASE_BEDROCK_TAGS = new NbtMap[JAVA_BLOCKS_SIZE];
        int vanillaCount = Math.min(BLOCKS_NBT.size(), javaBlockStates.size());
        SHARED_COLLISION_IGNORED_BLOCKS = new IntArrayList();
        POTTABLE_JAVA_BLOCKS = new it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet<>();
        for (Block b : BlockRegistries.JAVA_BLOCKS.get()) {
            if (b instanceof FlowerPotBlock flowerPot && flowerPot.flower() != Blocks.AIR) {
                POTTABLE_JAVA_BLOCKS.add(flowerPot.flower());
            }
        }

        BitSet waterloggedSet = BlockRegistries.WATERLOGGED.get();
        for (int id = 0; id < vanillaCount; id++) {
            BlockState blockState = javaBlockStates.get(id);
            NbtMap raw = BLOCKS_NBT.get(id);
            NbtMap built = buildBedrockState(blockState, raw);
            NbtMap states = STATES_INTERNER.intern(built.getCompound("states"));
            BASE_BEDROCK_TAGS[id] = NbtMap.builder()
                    .putString("name", built.getString("name").intern())
                    .putCompound("states", states)
                    .build();

            Block block = blockState.block();
            if (block == Blocks.BAMBOO || block == Blocks.POINTED_DRIPSTONE) {
                SHARED_COLLISION_IGNORED_BLOCKS.add(id);
            }
            if (block instanceof org.geysermc.geyser.translator.level.block.entity.BedrockChunkWantsBlockEntityTag) {
                BlockRegistries.BEDROCK_CHUNK_BLOCK_ENTITIES.set(id);
            }
            boolean waterlogged = blockState.getValue(Properties.WATERLOGGED, false)
                    || block == Blocks.BUBBLE_COLUMN || block == Blocks.KELP || block == Blocks.KELP_PLANT
                    || block == Blocks.SEAGRASS || block == Blocks.TALL_SEAGRASS;
            if (waterlogged) {
                waterloggedSet.set(id);
            }
        }

        Map<JavaBlockState, CustomBlockState> nonVanillaStateOverrides = BlockRegistries.NON_VANILLA_BLOCK_STATE_OVERRIDES.get();
        if (!nonVanillaStateOverrides.isEmpty()) {
            for (JavaBlockState javaState : nonVanillaStateOverrides.keySet()) {
                if (javaState.waterlogged()) {
                    waterloggedSet.set(javaState.javaId());
                }
            }
        }
    }

    @SuppressWarnings("UnstableApiUsage")
    private static synchronized BlockMappings buildBedrockPalette(ObjectIntPair<String> palette, Remapper stateMapper) {
        int protocolVersion = palette.valueInt();
        List<NbtMap> vanillaBlockStates;
        List<NbtMap> blockStates;
        try (InputStream stream = GeyserImpl.getInstance().getBootstrap().getResourceOrThrow(String.format("bedrock/block_palette.%s.nbt", palette.key()));
            NBTInputStream nbtInputStream = new NBTInputStream(new DataInputStream(new GZIPInputStream(stream)), true, true)) {
            NbtMap blockPalette = (NbtMap) nbtInputStream.readTag();

            vanillaBlockStates = new ArrayList<>(blockPalette.getList("blocks", NbtType.COMPOUND));
            for (int i = 0; i < vanillaBlockStates.size(); i++) {
                NbtMapBuilder builder = vanillaBlockStates.get(i).toBuilder();
                builder.remove("version");
                builder.remove("name_hash");
                builder.remove("network_id");
                builder.remove("block_id");
                builder.putCompound("states", STATES_INTERNER.intern((NbtMap) builder.remove("states")));
                vanillaBlockStates.set(i, builder.build());
            }

            blockStates = new ArrayList<>(vanillaBlockStates);
        } catch (Exception e) {
            throw new AssertionError("Unable to get blocks from runtime block states", e);
        }

        List<BlockPropertyData> customBlockProperties = new ArrayList<>();
        List<NbtMap> customBlockStates = new ArrayList<>();
        List<CustomBlockState> customExtBlockStates = new ArrayList<>();
        int[] remappedVanillaIds = new int[0];

        InputStream stream = GeyserImpl.getInstance().getBootstrap().getResourceOrNull(String.format("bedrock/data_driven_blocks.%s.nbt", palette.key()));
        if (stream != null) {
            try (stream; NBTInputStream nbtInputStream = new NBTInputStream(new DataInputStream(new GZIPInputStream(stream)))) {
                NbtMap dataDrivenBlocks = (NbtMap) nbtInputStream.readTag();
                for (Map.Entry<String, Object> entry : dataDrivenBlocks.entrySet()) {
                    customBlockProperties.add(new BlockPropertyData(entry.getKey(), (NbtMap) entry.getValue()));
                }
            } catch (IOException e) {
                throw new AssertionError("Unable to get data driven blocks from runtime definitions", e);
            }
        }

        if (BlockRegistries.CUSTOM_BLOCKS.get().length != 0) {
            CustomBlockRegistryPopulator.BLOCK_ID.set(CustomBlockRegistryPopulator.START_OFFSET);
            for (CustomBlockData customBlock : BlockRegistries.CUSTOM_BLOCKS.get()) {
                customBlockProperties.add(CustomBlockRegistryPopulator.generateBlockPropertyData(customBlock));
                CustomBlockRegistryPopulator.generateCustomBlockStates(customBlock, customBlockStates, customExtBlockStates);
            }
            blockStates.addAll(customBlockStates);
            blockStates.sort((a, b) -> Long.compareUnsigned(fnv164(a.getString("name")), fnv164(b.getString("name"))));
        }

        Object2ObjectMap<NbtMap, GeyserBedrockBlock> blockStateOrderedMap = new Object2ObjectOpenHashMap<>(blockStates.size());
        Map<String, List<GeyserBedrockBlock>> blocksByName = new Object2ObjectOpenHashMap<>();
        Map<NbtMap, BlockDefinition> itemFrames = new Object2ObjectOpenHashMap<>();
        GeyserBedrockBlock[] bedrockRuntimeMap = new GeyserBedrockBlock[blockStates.size()];
        for (int i = 0; i < blockStates.size(); i++) {
            NbtMap tag = blockStates.get(i);
            GeyserBedrockBlock block = new GeyserBedrockBlock(i, tag);
            if (blockStateOrderedMap.put(tag, block) != null) {
                throw new AssertionError("Duplicate block states in Bedrock palette: " + tag);
            }
            bedrockRuntimeMap[i] = block;
            String blockName = tag.getString("name");
            blocksByName.computeIfAbsent(blockName, k -> new ArrayList<>()).add(block);
            if (blockName.equals("minecraft:frame") || blockName.equals("minecraft:glow_frame")) {
                itemFrames.put(tag, block);
            }
        }

        Object2ObjectMap<CustomBlockState, GeyserBedrockBlock> customBlockStateDefinitions = Object2ObjectMaps.emptyMap();
        if (BlockRegistries.CUSTOM_BLOCKS.get().length != 0) {
            customBlockStateDefinitions = new Object2ObjectOpenHashMap<>(customExtBlockStates.size());
            for (int i = 0; i < customExtBlockStates.size(); i++) {
                NbtMap tag = customBlockStates.get(i);
                CustomBlockState blockState = customExtBlockStates.get(i);
                GeyserBedrockBlock bedrockBlock = blockStateOrderedMap.get(tag);
                customBlockStateDefinitions.put(blockState, bedrockBlock);
            }

            remappedVanillaIds = new int[vanillaBlockStates.size()];
            for (int i = 0; i < vanillaBlockStates.size(); i++) {
                GeyserBedrockBlock bedrockBlock = blockStateOrderedMap.get(vanillaBlockStates.get(i));
                remappedVanillaIds[i] = bedrockBlock != null ? bedrockBlock.getRuntimeId() : -1;
            }
        }

        List<BlockState> javaBlockStates = BlockRegistries.BLOCK_STATES.get();
        int vanillaLimit = MIN_CUSTOM_RUNTIME_ID >= 0 ? MIN_CUSTOM_RUNTIME_ID : JAVA_BLOCKS_SIZE;

        GeyserBedrockBlock airDefinition = null;
        BlockDefinition commandBlockDefinition = null;
        BlockDefinition mobSpawnerBlockDefinition = null;
        BlockDefinition netherPortalBlockDefinition = null;
        BlockDefinition waterDefinition = null;
        BlockDefinition movingBlockDefinition = null;

        GeyserBedrockBlock[] javaToBedrockBlocks = new GeyserBedrockBlock[JAVA_BLOCKS_SIZE];
        GeyserBedrockBlock[] javaToVanillaBedrockBlocks = new GeyserBedrockBlock[JAVA_BLOCKS_SIZE];

        var javaToBedrockIdentifiers = new Int2ObjectOpenHashMap<String>();
        Block lastBlockSeen = null;

        Map<Block, NbtMap> flowerPotBlocks = new Object2ObjectOpenHashMap<>();
        Set<BlockDefinition> jigsawDefinitions = new ObjectOpenHashSet<>();
        Map<String, BlockDefinition> structureBlockDefinitions = new Object2ObjectOpenHashMap<>();

        BlockMappings.BlockMappingsBuilder builder = BlockMappings.builder();
        for (int javaRuntimeId = 0; javaRuntimeId < vanillaLimit; javaRuntimeId++) {
            BlockState blockState = javaBlockStates.get(javaRuntimeId);
            NbtMap originalBedrockTag = BASE_BEDROCK_TAGS[javaRuntimeId];
            NbtMap bedrockTag = MultiVersionPaletteHelper.remapBlockForVersion(protocolVersion, blockState, stateMapper.remap(originalBedrockTag));

            GeyserBedrockBlock vanillaBedrockDefinition = MultiVersionPaletteHelper.resolveBlockDefinition(bedrockTag, blockStateOrderedMap, blocksByName);

            GeyserBedrockBlock bedrockDefinition;
            CustomBlockState blockStateOverride = BlockRegistries.CUSTOM_BLOCK_STATE_OVERRIDES.get(javaRuntimeId);
            if (blockStateOverride == null) {
                bedrockDefinition = vanillaBedrockDefinition;
                if (bedrockDefinition == null) {
                    throw new RuntimeException("Unable to find " + blockState + " Bedrock runtime ID for " + palette.key());
                }
            } else {
                bedrockDefinition = customBlockStateDefinitions.get(blockStateOverride);
                if (bedrockDefinition == null) {
                    throw new RuntimeException("Unable to find " + blockState + " Bedrock runtime ID! Custom block override: " + blockStateOverride);
                }
            }

            if (javaRuntimeId == AIR_JAVA_ID) {
                airDefinition = bedrockDefinition;
            } else if (javaRuntimeId == WATER_LEVEL0_JAVA_ID) {
                waterDefinition = bedrockDefinition;
            } else if (javaRuntimeId == CMD_BLOCK_NORTH_JAVA_ID) {
                commandBlockDefinition = bedrockDefinition;
            } else if (javaRuntimeId == SPAWNER_JAVA_ID) {
                mobSpawnerBlockDefinition = bedrockDefinition;
            } else if (javaRuntimeId == MOVING_PISTON_NORTH_JAVA_ID) {
                movingBlockDefinition = bedrockDefinition;
            }

            Block block = blockState.block();
            if (block != lastBlockSeen) {
                lastBlockSeen = block;
                String bedrockName = bedrockDefinition.getState().getString("name");
                if (!block.javaIdentifier().toString().equals(bedrockName)) {
                    javaToBedrockIdentifiers.put(block.javaId(), bedrockName.substring("minecraft:".length()).intern());
                }
            }

            if (block == Blocks.JIGSAW) {
                jigsawDefinitions.add(bedrockDefinition);
            } else if (block == Blocks.STRUCTURE_BLOCK) {
                String mode = blockState.getValue(Properties.STRUCTUREBLOCK_MODE);
                structureBlockDefinitions.put(mode.toUpperCase(Locale.ROOT), bedrockDefinition);
            } else if (block == Blocks.NETHER_PORTAL) {
                netherPortalBlockDefinition = bedrockDefinition;
            }

            if (POTTABLE_JAVA_BLOCKS.contains(block)) {
                flowerPotBlocks.put(block, blockStates.get(bedrockDefinition.getRuntimeId()));
            }

            javaToVanillaBedrockBlocks[javaRuntimeId] = vanillaBedrockDefinition;
            javaToBedrockBlocks[javaRuntimeId] = bedrockDefinition;
        }

        builder.collisionIgnoredBlocks(new IntArrayList(SHARED_COLLISION_IGNORED_BLOCKS));

        if (commandBlockDefinition == null) {
            throw new AssertionError("Unable to find command block in palette");
        }
        builder.commandBlock(commandBlockDefinition);

        if (mobSpawnerBlockDefinition == null) {
            throw new AssertionError("Unable to find mob spawner block in palette");
        }
        builder.mobSpawnerBlock(mobSpawnerBlockDefinition);

        if (netherPortalBlockDefinition == null) {
            throw new AssertionError("Unable to find nether portal block in palette");
        }
        builder.netherPortalBlock(netherPortalBlockDefinition);

        if (waterDefinition == null) {
            throw new AssertionError("Unable to find water in palette");
        }
        builder.bedrockWater(waterDefinition);

        if (airDefinition == null) {
            throw new AssertionError("Unable to find air in palette");
        }
        builder.bedrockAir(airDefinition);

        if (movingBlockDefinition == null) {
            throw new AssertionError("Unable to find moving block in palette");
        }
        builder.bedrockMovingBlock(movingBlockDefinition);

        Map<JavaBlockState, CustomBlockState> nonVanillaStateOverrides = BlockRegistries.NON_VANILLA_BLOCK_STATE_OVERRIDES.get();
        if (!nonVanillaStateOverrides.isEmpty()) {
            Arrays.fill(javaToVanillaBedrockBlocks, MIN_CUSTOM_RUNTIME_ID, javaToVanillaBedrockBlocks.length, airDefinition);
            Arrays.fill(javaToBedrockBlocks, MIN_CUSTOM_RUNTIME_ID, javaToBedrockBlocks.length, airDefinition);

            for (Map.Entry<JavaBlockState, CustomBlockState> entry : nonVanillaStateOverrides.entrySet()) {
                GeyserBedrockBlock bedrockDefinition = customBlockStateDefinitions.get(entry.getValue());
                if (bedrockDefinition == null) {
                    GeyserImpl.getInstance().getLogger().warning("Unable to find custom block for " + entry.getValue());
                    continue;
                }

                JavaBlockState javaState = entry.getKey();
                int stateRuntimeId = javaState.javaId();
                javaToVanillaBedrockBlocks[stateRuntimeId] = bedrockDefinition;
                javaToBedrockBlocks[stateRuntimeId] = bedrockDefinition;
                javaToBedrockIdentifiers.put(entry.getKey().stateGroupId(), entry.getValue().block().identifier());
            }
        }

        javaToBedrockIdentifiers.trim();

        return builder.bedrockRuntimeMap(bedrockRuntimeMap)
                .javaToBedrockBlocks(javaToBedrockBlocks)
                .javaToVanillaBedrockBlocks(javaToVanillaBedrockBlocks)
                .javaToBedrockIdentifiers(javaToBedrockIdentifiers)
                .stateDefinitionMap(blockStateOrderedMap)
                .itemFrames(itemFrames)
                .flowerPotBlocks(flowerPotBlocks)
                .jigsawStates(jigsawDefinitions)
                .structureBlockStates(structureBlockDefinitions)
                .remappedVanillaIds(remappedVanillaIds)
                .blockProperties(customBlockProperties)
                .customBlockStateDefinitions(customBlockStateDefinitions)
                .build();
    }

    private static void registerJavaBlocks() {
        List<NbtMap> blocksNbt;
        try (InputStream stream = GeyserImpl.getInstance().getBootstrap().getResourceOrThrow("mappings/blocks.nbt")) {
            blocksNbt = ((NbtMap) NbtUtils.createGZIPReader(stream).readTag())
                    .getList("bedrock_mappings", NbtType.COMPOUND);
        } catch (Exception e) {
            throw new AssertionError("Unable to load Java block mappings", e);
        }

        int javaRuntimeId = -1;
        for (BlockState javaBlockState : BlockRegistries.BLOCK_STATES.get()) {
            javaRuntimeId++;
            String javaId = javaBlockState.toString().intern();
            switch (javaId) {
                case "minecraft:air" -> AIR_JAVA_ID = javaRuntimeId;
                case "minecraft:water[level=0]" -> WATER_LEVEL0_JAVA_ID = javaRuntimeId;
                case "minecraft:command_block[conditional=false,facing=north]" -> CMD_BLOCK_NORTH_JAVA_ID = javaRuntimeId;
                case "minecraft:spawner" -> SPAWNER_JAVA_ID = javaRuntimeId;
                case "minecraft:moving_piston[facing=north,type=normal]" -> MOVING_PISTON_NORTH_JAVA_ID = javaRuntimeId;
            }

            BlockRegistries.JAVA_BLOCK_STATE_IDENTIFIER_TO_ID.register(javaId, javaRuntimeId);
        }

        BLOCKS_NBT = blocksNbt;
        JAVA_BLOCKS_SIZE = blocksNbt.size();

        JsonObject blockInteractionsJson;
        try (InputStream stream = GeyserImpl.getInstance().getBootstrap().getResourceOrThrow("mappings/interactions.json")) {
            blockInteractionsJson = JsonUtils.fromJson(stream);
        } catch (Exception e) {
            throw new AssertionError("Unable to load Java block interaction mappings", e);
        }

        BlockRegistries.INTERACTIVE.set(toBlockStateSet(blockInteractionsJson.getAsJsonArray("always_consumes")));
        BlockRegistries.INTERACTIVE_MAY_BUILD.set(toBlockStateSet(blockInteractionsJson.getAsJsonArray("requires_may_build")));
    }""",
        "BlockRegistryPopulator.lazyAndPrecomputedOptimization",
    )

    replace_exact(
        item_populator,
        """        // We can reduce some operations as Java information is the same across all palette versions
        boolean firstMappingsPass = true;

        /* Load item palette */
        for (PaletteVersion palette : paletteVersions) {""",
        """        boolean firstMappingsPass = true;
        boolean eagerAll = Boolean.getBoolean("purpurbedrock.eagerAllPalettes");
        int primaryProto = Bedrock_v2225.CODEC.getProtocolVersion();
        for (PaletteVersion palette : paletteVersions) {
            if (eagerAll || palette.protocolVersion() == primaryProto) {
                boolean firstPass = firstMappingsPass;
                firstMappingsPass = false;
                Registries.ITEMS.register(palette.protocolVersion(),
                        buildItemMappingsForPalette(palette, bootstrap, items, customItems, nonVanillaCustomItems, firstPass));
            } else {
                Registries.ITEMS.registerLazy(palette.protocolVersion(),
                        ver -> buildItemMappingsForPalette(palette, bootstrap, items, customItems, nonVanillaCustomItems, false));
            }
        }
    }

    private static synchronized ItemMappings buildItemMappingsForPalette(
            PaletteVersion palette,
            GeyserBootstrap bootstrap,
            Map<String, GeyserMappingItem> items,
            Multimap<Identifier, CustomItemDefinition> customItems,
            Multimap<Identifier, NonVanillaCustomItemDefinition> nonVanillaCustomItems,
            boolean firstMappingsPass) {
        {""",
        "ItemRegistryPopulator.lazyPaletteDispatch",
    )
    replace_exact(
        item_populator,
        """            BlockMappings blockMappings = BlockRegistries.BLOCKS.forVersion(palette.protocolVersion());""",
        """            BlockMappings blockMappings = BlockRegistries.BLOCKS.forVersion(palette.protocolVersion());
            Map<String, List<GeyserBedrockBlock>> runtimeBlocksByName = new Object2ObjectOpenHashMap<>();
            for (GeyserBedrockBlock candidateBlock : blockMappings.getBedrockRuntimeMap()) {
                if (candidateBlock != null) {
                    runtimeBlocksByName.computeIfAbsent(candidateBlock.getState().getString("name"), k -> new ArrayList<>()).add(candidateBlock);
                }
            }""",
        "ItemRegistryPopulator.indexRuntimeBlocksByName",
    )
    replace_exact(
        item_populator,
        """                                for (GeyserBedrockBlock block : blockMappings.getBedrockRuntimeMap()) {
                                    if (block == null) {
                                        continue;
                                    }
                                    NbtMap blockTag = block.getState();
                                    if (blockTag.getString("name").equals(correctBedrockIdentifier)) {""",
        """                                for (GeyserBedrockBlock block : runtimeBlocksByName.getOrDefault(correctBedrockIdentifier, Collections.emptyList())) {
                                    NbtMap blockTag = block.getState();
                                    if (true) {""",
        "ItemRegistryPopulator.fastBlockMatchByName",
    )
    replace_exact(
        item_populator,
        """            Registries.ITEMS.register(palette.protocolVersion(), itemMappings);

            firstMappingsPass = false;
        }
    }""",
        """            return itemMappings;
        }
    }""",
        "ItemRegistryPopulator.returnItemMappings",
    )

    replace_exact(
        tag_populator,
        """public final class TagRegistryPopulator {
    private static final Gson GSON = new GsonBuilder().create(); // temporary

    public static void populate() {""",
        """public final class TagRegistryPopulator {
    private static final Gson GSON = new GsonBuilder().create(); // temporary
    private static final Map<String, Map<String, List<String>>> TAG_JSON_CACHE = new java.util.concurrent.ConcurrentHashMap<>();

    public static void populate() {""",
        "TagRegistryPopulator.tagJsonCacheField",
    )
    replace_exact(
        tag_populator,
        """        for (var palette : paletteVersions) {
            ItemMappings mappings = Registries.ITEMS.forVersion(palette.rightInt());

            Map<String, List<String>> bedrockTags;
            try (InputStream stream = bootstrap.getResourceOrThrow(String.format("bedrock/item_tags.%s.json", palette.left()))) {
                bedrockTags = GSON.fromJson(new InputStreamReader(stream), type);
            } catch (Exception e) {
                throw new AssertionError("Unable to load Bedrock runtime item IDs", e);
            }

            var javaItemsToBedrockTag = new Object2ObjectOpenCustomHashMap<int[], String>(hashStrategy);

            for (var entry : bedrockTags.entrySet()) {
                List<String> value = entry.getValue();
                if (value.isEmpty() || value.size() == 1) {
                    // For our usecase, we don't need this. Empty values are worthless; one value can just be a reference
                    // to the item itself, instead of the tag.
                    continue;
                }

                // In some cases, the int list will need to be minimized
                IntList javaNetworkIds = new IntArrayList(value.size());
                for (int i = 0; i < value.size(); i++) {
                    String bedrockIdentifier = value.get(i);
                    Item javaItem = Registries.JAVA_ITEM_IDENTIFIERS.get(bedrockIdentifier);
                    if (javaItem == null) {
                        // Time to search the long way around.
                        for (ItemMapping mapping : mappings.getItems()) {
                            if (mapping.getBedrockIdentifier().equals(bedrockIdentifier)) {
                                javaItem = mapping.getJavaItem();
                                break;
                            }
                        }
                    }
                    if (javaItem == null) {
                        // Triggers for Bedrock-only spawn eggs. We don't care.
                        continue;
                    }

                    javaNetworkIds.add(javaItem.javaId());
                }

                int[] javaNetworkIdArray = javaNetworkIds.toIntArray();
                // Sort IDs so equality checks just have to match if each is equal and not necessarily an order difference.
                Arrays.sort(javaNetworkIdArray);

                javaItemsToBedrockTag.put(javaNetworkIdArray, entry.getKey());
            }

            javaItemsToBedrockTag.trim();
            Registries.TAGS.register(palette.rightInt(), javaItemsToBedrockTag);
        }""",
        """        boolean eagerAll = Boolean.getBoolean("purpurbedrock.eagerAllPalettes");
        int primaryProto = Bedrock_v2225.CODEC.getProtocolVersion();
        for (var palette : paletteVersions) {
            int proto = palette.rightInt();
            String tagFileVer = palette.left();
            if (eagerAll || proto == primaryProto) {
                Registries.TAGS.register(proto, buildTagsForPalette(bootstrap, type, hashStrategy, tagFileVer, proto));
            } else {
                Registries.TAGS.registerLazy(proto, ver -> buildTagsForPalette(bootstrap, type, hashStrategy, tagFileVer, ver));
            }
        }
    }

    private static synchronized Object2ObjectOpenCustomHashMap<int[], String> buildTagsForPalette(
            GeyserBootstrap bootstrap,
            Type type,
            Hash.Strategy<int[]> hashStrategy,
            String tagFileVer,
            int protocolVersion) {
        ItemMappings mappings = Registries.ITEMS.forVersion(protocolVersion);
        Map<String, List<String>> bedrockTags = TAG_JSON_CACHE.computeIfAbsent(tagFileVer, key -> {
            try (InputStream stream = bootstrap.getResourceOrThrow(String.format("bedrock/item_tags.%s.json", key))) {
                return GSON.fromJson(new InputStreamReader(stream, java.nio.charset.StandardCharsets.UTF_8), type);
            } catch (Exception e) {
                throw new AssertionError("Unable to load Bedrock runtime item IDs", e);
            }
        });

        Map<String, Item> fallbackByBedrockId = null;
        var javaItemsToBedrockTag = new Object2ObjectOpenCustomHashMap<int[], String>(hashStrategy);

        for (var entry : bedrockTags.entrySet()) {
            List<String> value = entry.getValue();
            if (value.isEmpty() || value.size() == 1) {
                continue;
            }

            IntList javaNetworkIds = new IntArrayList(value.size());
            for (int i = 0; i < value.size(); i++) {
                String bedrockIdentifier = value.get(i);
                Item javaItem = Registries.JAVA_ITEM_IDENTIFIERS.get(bedrockIdentifier);
                if (javaItem == null) {
                    if (fallbackByBedrockId == null) {
                        fallbackByBedrockId = new it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap<>(mappings.getItems().length);
                        for (ItemMapping mapping : mappings.getItems()) {
                            if (mapping != null && mapping.getBedrockIdentifier() != null) {
                                fallbackByBedrockId.putIfAbsent(mapping.getBedrockIdentifier(), mapping.getJavaItem());
                            }
                        }
                    }
                    javaItem = fallbackByBedrockId.get(bedrockIdentifier);
                }
                if (javaItem == null) {
                    continue;
                }

                javaNetworkIds.add(javaItem.javaId());
            }

            int[] javaNetworkIdArray = javaNetworkIds.toIntArray();
            Arrays.sort(javaNetworkIdArray);
            javaItemsToBedrockTag.put(javaNetworkIdArray, entry.getKey());
        }

        javaItemsToBedrockTag.trim();
        return javaItemsToBedrockTag;""",
        "TagRegistryPopulator.lazyAndCachedTags",
    )

    potion_loader = root / "core/src/main/java/org/geysermc/geyser/registry/loader/PotionMixRegistryLoader.java"
    replace_exact(
        potion_loader,
        """    @Override
    public Int2ObjectMap<Set<PotionMixData>> load(Object input) {
        var allPotionMixes = new Int2ObjectOpenHashMap<Set<PotionMixData>>(Registries.ITEMS.get().size());
        for (var entry : Registries.ITEMS.get().int2ObjectEntrySet()) {
            ItemMappings mappings = entry.getValue();""",
        """    @Override
    public Int2ObjectMap<Set<PotionMixData>> load(Object input) {
        var allPotionMixes = new Int2ObjectOpenHashMap<Set<PotionMixData>>(Registries.ITEMS.get().size());
        for (var entry : Registries.ITEMS.get().int2ObjectEntrySet()) {
            allPotionMixes.put(entry.getIntKey(), buildForMappings(entry.getValue()));
        }
        allPotionMixes.trim();
        return allPotionMixes;
    }

    public static Set<PotionMixData> buildForMappings(ItemMappings mappings) {
        {""",
        "PotionMixRegistryLoader.extractBuildForMappingsHead",
    )
    replace_exact(
        potion_loader,
        """            allPotionMixes.put(entry.getIntKey(), potionMixes);
        }
        allPotionMixes.trim();
        return allPotionMixes;
    }""",
        """            return potionMixes;
        }
    }""",
        "PotionMixRegistryLoader.extractBuildForMappingsTail",
    )

    registries_java = root / "core/src/main/java/org/geysermc/geyser/registry/Registries.java"
    replace_exact(
        registries_java,
        """        // potion mixes depend on other registries
        POTION_MIXES.load();""",
        """        // potion mixes depend on other registries
        POTION_MIXES.load();
        POTION_MIXES.register(2225, PotionMixRegistryLoader.buildForMappings(ITEMS.forVersion(2225)));
        for (int lazyProto : ITEMS.lazyVersions()) {
            POTION_MIXES.registerLazy(lazyProto, ver -> PotionMixRegistryLoader.buildForMappings(ITEMS.forVersion(ver)));
        }""",
        "Registries.registerLazyPotionMixes",
    )

    replace_exact(
        geyser_impl,
        """        eventBus.subscribe(this, GeyserDefineCustomBlocksEvent.class, BuiltInMappings::registerBlocks);
        eventBus.subscribe(this, GeyserDefineCustomItemsEvent.class, BuiltInMappings::registerItems);

        /*
        First load the registries and then populate them.
        Both the block registries and the common registries depend on each other,
        so maintaining this order is crucial for Geyser to load.
         */
        Registries.load();
        BlockRegistries.populate();
        Registries.populate();

        RegistryCache.init();

        /* Initialize translators */
        VanillaEntities.init();
        MessageTranslator.init();""",
        """        ensureCoreRegistriesReady();""",
        "GeyserImpl.initializeEnsureCoreRegistriesReady",
    )
    replace_exact(
        geyser_impl,
        """    private boolean isEnabled;""",
        """    private boolean isEnabled;
    private final Object coreRegistryLock = new Object();
    private volatile boolean coreRegistriesReady = false;

    public void ensureCoreRegistriesReady() {
        if (this.coreRegistriesReady) {
            return;
        }
        synchronized (this.coreRegistryLock) {
            if (this.coreRegistriesReady) {
                return;
            }
            eventBus.subscribe(this, GeyserDefineCustomBlocksEvent.class, BuiltInMappings::registerBlocks);
            eventBus.subscribe(this, GeyserDefineCustomItemsEvent.class, BuiltInMappings::registerItems);

            Registries.load();
            BlockRegistries.populate();
            Registries.populate();

            RegistryCache.init();
            VanillaEntities.init();
            MessageTranslator.init();
            this.coreRegistriesReady = true;
        }
    }""",
        "GeyserImpl.ensureCoreRegistriesReadyMethod",
    )

    replace_exact(
        spigot_plugin,
        """        this.commandRegistry = new SpigotCommandRegistry(geyser, cloud);

        // Needs to be an anonymous inner class otherwise Bukkit complains about missing classes""",
        """        this.commandRegistry = new SpigotCommandRegistry(geyser, cloud);

        if (canPrewarmRegistriesAsync()) {
            Thread prewarmThread = new Thread(() -> {
                try {
                    geyser.ensureCoreRegistriesReady();
                } catch (Throwable t) {
                    geyserLogger.debug("Async registry prewarm deferred to ServerLoadEvent: " + t.getMessage());
                }
            }, "Purpurbedrock-Geyser-Prewarm");
            prewarmThread.setDaemon(true);
            prewarmThread.start();
        }

        // Needs to be an anonymous inner class otherwise Bukkit complains about missing classes""",
        "GeyserSpigotPlugin.startAsyncPrewarm",
    )
    replace_exact(
        spigot_plugin,
        """    @Override
    public MetricsPlatform createMetricsPlatform() {""",
        """    private boolean canPrewarmRegistriesAsync() {
        if (!Boolean.parseBoolean(System.getProperty("purpurbedrock.asyncPrewarm", "true"))) {
            return false;
        }
        for (Plugin p : Bukkit.getPluginManager().getPlugins()) {
            String n = p.getName().toLowerCase(java.util.Locale.ROOT);
            if (n.contains("itemsadder") || n.contains("oraxen") || n.contains("nexo") || n.contains("crucible")) {
                return false;
            }
        }
        return true;
    }

    @Override
    public MetricsPlatform createMetricsPlatform() {""",
        "GeyserSpigotPlugin.canPrewarmRegistriesAsync",
    )

    spigot_cmd_source = root / "bootstrap/spigot/src/main/java/org/geysermc/geyser/platform/spigot/command/SpigotCommandSource.java"
    replace_exact(
        spigot_cmd_source,
        """    public SpigotCommandSource(CommandSender handle) {
        this.handle = handle;
        // Ensure even Java players' languages are loaded
        GeyserLocale.loadGeyserLocale(locale());
    }""",
        """    public SpigotCommandSource(CommandSender handle) {
        this.handle = handle;
    }""",
        "SpigotCommandSource.noEagerLocaleInCtor",
    )
    replace_exact(
        spigot_cmd_source,
        """    @SuppressWarnings("deprecation")
    @Override
    public String locale() {
        if (this.handle instanceof Player player) {
            // getLocale() is deprecated on Paper, but not on Spigot
            return player.getLocale();
        }

        return GeyserLocale.getDefaultLocale();
    }""",
        """    @SuppressWarnings("deprecation")
    @Override
    public String locale() {
        if (this.handle instanceof Player player) {
            String loc = player.getLocale();
            GeyserLocale.loadGeyserLocale(loc);
            return loc;
        }

        return GeyserLocale.getDefaultLocale();
    }""",
        "SpigotCommandSource.lazyLocaleLoad",
    )

    native_world_mgr = root / "bootstrap/spigot/src/main/java/org/geysermc/geyser/platform/spigot/world/manager/GeyserSpigotNativeWorldManager.java"
    replace_exact(
        native_world_mgr,
        """    @Override
    public int getBlockAt(GeyserSession session, int x, int y, int z) {
        Player player = Bukkit.getPlayer(session.getPlayerEntity().getUsername());
        if (player == null) {
            return Block.JAVA_AIR_ID;
        }
        return adapter.getBlockAt(player.getWorld(), x, y, z);
    }""",
        """    @Override
    public int getBlockAt(GeyserSession session, int x, int y, int z) {
        java.util.UUID uuid = session.getPlayerEntity().uuid();
        Player player = uuid != null ? Bukkit.getPlayer(uuid) : Bukkit.getPlayerExact(session.getPlayerEntity().getUsername());
        if (player == null) {
            return Block.JAVA_AIR_ID;
        }
        return adapter.getBlockAt(player.getWorld(), x, y, z);
    }""",
        "GeyserSpigotNativeWorldManager.fastUuidGetBlockAt",
    )

    chunk_section = root / "core/src/main/java/org/geysermc/geyser/level/chunk/GeyserChunkSection.java"
    replace_exact(
        chunk_section,
        """    public void writeToNetwork(ByteBuf buffer) {
        buffer.writeByte(CHUNK_SECTION_VERSION);
        buffer.writeByte(this.storage.length);
        // Required for chunk version 9+
        buffer.writeByte(this.subChunkIndex);
        for (BlockStorage blockStorage : this.storage) {
            blockStorage.writeToNetwork(buffer);
        }
    }

    public int estimateNetworkSize() {
        int size = 2; // Version + storage count
        for (BlockStorage blockStorage : this.storage) {
            size += blockStorage.estimateNetworkSize();
        }
        return size;
    }""",
        """    public static void writeEmptyToNetwork(ByteBuf buffer, int subChunkIndex) {
        buffer.writeByte(CHUNK_SECTION_VERSION);
        buffer.writeByte(0);
        buffer.writeByte(subChunkIndex);
    }

    public void writeToNetwork(ByteBuf buffer) {
        buffer.writeByte(CHUNK_SECTION_VERSION);
        buffer.writeByte(this.storage.length);
        // Required for chunk version 9+
        buffer.writeByte(this.subChunkIndex);
        for (BlockStorage blockStorage : this.storage) {
            blockStorage.writeToNetwork(buffer);
        }
    }

    public int estimateNetworkSize() {
        int size = 3; // Version + storage count + subChunkIndex
        for (BlockStorage blockStorage : this.storage) {
            size += blockStorage.estimateNetworkSize();
        }
        return size;
    }""",
        "GeyserChunkSection.accurateSizeAndZeroAllocEmpty",
    )

    replace_exact(
        level_chunk_translator,
        """                    // Check if block is piston, flower or cauldron to see if we'll need to create additional block entities, as they're only block entities in Bedrock
                    // TODO this needs a performance check when my head is clearer
                    BlockState state = BlockState.of(javaId);
                    if (state.block() instanceof BedrockChunkWantsBlockEntityTag) {
                        bedrockOnlyBlockEntityIds.set(i);
                    }""",
        """                    if (BlockRegistries.BEDROCK_CHUNK_BLOCK_ENTITIES.get(javaId)) {
                        bedrockOnlyBlockEntityIds.set(i);
                    }""",
        "JavaLevelChunkWithLightTranslator.fastBitSetBlockEntityCheck",
    )
    replace_exact(
        level_chunk_translator,
        """                } else {
                    int subChunkIndex = (i + (bedrockDimension.minY() >> 4));
                    new GeyserChunkSection(EMPTY_BLOCK_STORAGE, subChunkIndex).writeToNetwork(byteBuf);
                }""",
        """                } else {
                    int subChunkIndex = (i + (bedrockDimension.minY() >> 4));
                    GeyserChunkSection.writeEmptyToNetwork(byteBuf, subChunkIndex);
                }""",
        "JavaLevelChunkWithLightTranslator.zeroAllocEmptySection",
    )
    replace_exact(
        level_chunk_translator,
        """        for (Map.Entry<Vector3i, ItemFrameEntity> entry : session.getItemFrameCache().entrySet()) {
            Vector3i position = entry.getKey();
            if ((position.getX() >> 4) == packet.getX() && (position.getZ() >> 4) == packet.getZ()) {
                // Update this item frame so it doesn't get lost in the abyss
                //TODO optimize
                entry.getValue().updateBlock(true);
            }
        }""",
        """        if (!session.getItemFrameCache().isEmpty()) {
            for (Map.Entry<Vector3i, ItemFrameEntity> entry : session.getItemFrameCache().entrySet()) {
                Vector3i position = entry.getKey();
                if ((position.getX() >> 4) == packet.getX() && (position.getZ() >> 4) == packet.getZ()) {
                    entry.getValue().updateBlock(true);
                }
            }
        }""",
        "JavaLevelChunkWithLightTranslator.skipEmptyItemFrameCache",
    )

    scoreboard_updater = root / "core/src/main/java/org/geysermc/geyser/scoreboard/ScoreboardUpdater.java"
    replace_exact(
        scoreboard_updater,
        """    public static ScoreboardUpdater init() {
        ScoreboardUpdater updater = new ScoreboardUpdater();
        updater.start();
        return updater;
    }""",
        """    public static ScoreboardUpdater init() {
        ScoreboardUpdater updater = new ScoreboardUpdater();
        updater.setName("Purpurbedrock-Scoreboard-Updater");
        updater.setDaemon(true);
        updater.start();
        return updater;
    }""",
        "ScoreboardUpdater.namedDaemonThread",
    )
    replace_exact(
        scoreboard_updater,
        """                // reset score-packets per second every second
                Collection<GeyserSession> sessions = geyser.getSessionManager().getSessions().values();""",
        """                // reset score-packets per second every second
                Collection<GeyserSession> sessions = geyser.getSessionManager().getSessions().values();
                if (sessions.isEmpty()) {
                    lastUpdate = currentTime;
                    lastPacketsPerSecondUpdate = currentTime;
                    sleepFor(SECOND_MILLIS_BETWEEN_UPDATES);
                    continue;
                }""",
        "ScoreboardUpdater.idleSleepWhenEmpty",
    )

    update_listener = root / "bootstrap/spigot/src/main/java/org/geysermc/geyser/platform/spigot/GeyserSpigotUpdateListener.java"
    replace_exact(
        update_listener,
        """    @EventHandler
    public void onPlayerJoin(final PlayerJoinEvent event) {
        if (GeyserImpl.getInstance().config().notifyOnNewBedrockUpdate()) {
            final Player player = event.getPlayer();
            if (player.hasPermission(Permissions.CHECK_UPDATE)) {
                VersionCheckUtils.checkForGeyserUpdate(() -> new SpigotCommandSource(player));
            }
        }
    }""",
        """    @EventHandler
    public void onPlayerJoin(final PlayerJoinEvent event) {
        // Purpurbedrock: embedded engine is versioned with the server core; skip external update checks on join
    }""",
        "GeyserSpigotUpdateListener.noOpJoinUpdateCheck",
    )

    # 13. Waypoint Console-Spam & LocatorBar 20Hz Flood Fix + Bedrock Client FPS Protections
    waypoint_translator = root / "core/src/main/java/org/geysermc/geyser/translator/protocol/java/level/JavaTrackedWaypointTranslator.java"
    replace_exact(
        waypoint_translator,
        """    @Override
    public void translate(GeyserSession session, ClientboundTrackedWaypointPacket packet) {
        session.getWaypointCache().handlePacket(packet);
    }""",
        """    @Override
    public void translate(GeyserSession session, ClientboundTrackedWaypointPacket packet) {
        if (session.protocolVersion() < 800) {
            return;
        }
        session.getWaypointCache().handlePacket(packet);
    }""",
        "JavaTrackedWaypointTranslator.gateLocatorBarProtocol",
    )

    waypoint_cache = root / "core/src/main/java/org/geysermc/geyser/session/cache/waypoint/WaypointCache.java"
    replace_exact(
        waypoint_cache,
        """    public void tick() {
        for (GeyserWaypoint waypoint : waypoints.values()) {
            if (waypoint instanceof TickingWaypoint ticking) {
                ticking.tick();
            }
        }
    }""",
        """    public void tick() {
        if (waypoints.isEmpty()) {
            return;
        }
        for (GeyserWaypoint waypoint : waypoints.values()) {
            if (waypoint instanceof TickingWaypoint ticking) {
                ticking.tick();
            }
        }
    }""",
        "WaypointCache.fastEmptyTick",
    )
    replace_exact(
        waypoint_cache,
        """    private void update(TrackedWaypoint waypoint) {
        getWaypoint(waypoint).ifPresent(tracked -> tracked.update(waypoint.data()));
    }""",
        """    private void update(TrackedWaypoint waypoint) {
        Optional<GeyserWaypoint> existing = getWaypoint(waypoint);
        if (existing.isEmpty()) {
            track(waypoint);
            return;
        }
        GeyserWaypoint tracked = existing.get();
        boolean matchesType = switch (waypoint.type()) {
            case EMPTY -> false;
            case VEC3I -> tracked instanceof CoordinatesWaypoint;
            case CHUNK -> tracked instanceof ChunkWaypoint;
            case AZIMUTH -> tracked instanceof AzimuthWaypoint;
        };
        if (!matchesType) {
            track(waypoint);
            return;
        }
        tracked.update(waypoint.data());
    }""",
        "WaypointCache.handleSubtypeTransitionOnUpdate",
    )

    coords_waypoint = root / "core/src/main/java/org/geysermc/geyser/session/cache/waypoint/CoordinatesWaypoint.java"
    replace_exact(
        coords_waypoint,
        """        } else {
            session.getGeyser().getLogger().warning("Received incorrect waypoint data " + data.getClass() + " for coordinates waypoint");
        }""",
        """        } else {
            session.getGeyser().getLogger().debug("Received incorrect waypoint data " + data.getClass() + " for coordinates waypoint");
        }""",
        "CoordinatesWaypoint.downgradeMismatchWarning",
    )

    chunk_waypoint = root / "core/src/main/java/org/geysermc/geyser/session/cache/waypoint/ChunkWaypoint.java"
    replace_exact(
        chunk_waypoint,
        """        } else {
            session.getGeyser().getLogger().warning("Received incorrect waypoint data " + data.getClass() + " for chunk waypoint");
        }""",
        """        } else {
            session.getGeyser().getLogger().debug("Received incorrect waypoint data " + data.getClass() + " for chunk waypoint");
        }""",
        "ChunkWaypoint.downgradeMismatchWarning",
    )

    azimuth_waypoint = root / "core/src/main/java/org/geysermc/geyser/session/cache/waypoint/AzimuthWaypoint.java"
    replace_exact(
        azimuth_waypoint,
        """    private static final float WAYPOINT_DISTANCE = Integer.MAX_VALUE;

    // The angle, in radians, where the waypoint should appear on the bar
    private float angle = 0.0F;

    public AzimuthWaypoint(GeyserSession session, UUID uuid, CustomWaypointStyle style, Identifier styleIdentifier, Color color, Optional<Entity> entity) {
        super(session, uuid, style, styleIdentifier, color, entity);
    }

    @Override
    public void setData(WaypointData data) {
        if (data instanceof AzimuthWaypointData(float azimuthAngle)) {
            angle = azimuthAngle;
            updatePosition();
        } else {
            session.getGeyser().getLogger().warning("Received incorrect waypoint data " + data.getClass() + " for azimuth waypoint");
        }
    }

    @Override
    public void tick() {
        // Update position so that it remains accurate to the angle as the player moves around
        updatePosition();
        sendLocationPacket();
    }""",
        """    private static final float WAYPOINT_DISTANCE = 65536.0F;

    // The angle, in radians, where the waypoint should appear on the bar
    private float angle = 0.0F;
    private float lastSentAngle = Float.NaN;
    private Vector3f lastAnchorPosition = null;
    private int tickCounter = 0;

    public AzimuthWaypoint(GeyserSession session, UUID uuid, CustomWaypointStyle style, Identifier styleIdentifier, Color color, Optional<Entity> entity) {
        super(session, uuid, style, styleIdentifier, color, entity);
    }

    @Override
    public void setData(WaypointData data) {
        if (data instanceof AzimuthWaypointData(float azimuthAngle)) {
            angle = azimuthAngle;
            if (Float.isNaN(lastSentAngle) || Math.abs(azimuthAngle - lastSentAngle) >= 0.012F) {
                lastSentAngle = azimuthAngle;
                lastAnchorPosition = session.getPlayerEntity().position();
                updatePosition();
            }
        } else {
            session.getGeyser().getLogger().debug("Received incorrect waypoint data " + data.getClass() + " for azimuth waypoint");
        }
    }

    @Override
    public void tick() {
        if ((++tickCounter % 10) != 0) {
            return;
        }
        Vector3f playerPosition = session.getPlayerEntity().position();
        if (!Float.isNaN(lastSentAngle)
                && Math.abs(angle - lastSentAngle) < 0.0175F
                && lastAnchorPosition != null
                && playerPosition.distanceSquared(lastAnchorPosition) < 256.0F) {
            return;
        }
        lastSentAngle = angle;
        lastAnchorPosition = playerPosition;
        updatePosition();
        sendLocationPacket();
    }""",
        "AzimuthWaypoint.floatSafeAndThrottledTick",
    )

    particles_translator = root / "core/src/main/java/org/geysermc/geyser/translator/protocol/java/level/JavaLevelParticlesTranslator.java"
    replace_exact(
        particles_translator,
        """    private static final int MAX_PARTICLES = 100;""",
        """    private static final int MAX_PARTICLES = Math.max(1, Integer.getInteger("purpurbedrock.maxParticlesPerPacket", 16));""",
        "JavaLevelParticlesTranslator.clientFpsParticleCap",
    )

    motion_translator = root / "core/src/main/java/org/geysermc/geyser/translator/protocol/java/entity/JavaSetEntityMotionTranslator.java"
    replace_exact(
        motion_translator,
        """        Entity entity = session.getEntityCache().getEntityByJavaId(packet.getEntityId());
        if (entity == null) return;

        entity.setMotion(packet.getMovement().toFloat());""",
        """        Entity entity = session.getEntityCache().getEntityByJavaId(packet.getEntityId());
        if (entity == null) return;

        org.cloudburstmc.math.vector.Vector3f prevMotion = entity.getMotion();
        org.cloudburstmc.math.vector.Vector3f newMotion = packet.getMovement().toFloat();
        entity.setMotion(newMotion);
        if (entity != session.getPlayerEntity()
                && newMotion.lengthSquared() < 1.0E-6F
                && prevMotion != null
                && prevMotion.lengthSquared() < 1.0E-6F) {
            return;
        }""",
        "JavaSetEntityMotionTranslator.skipRedundantZeroMotion",
    )

    # =========================================================================
    # 14. Universal Join Reliability Across 1.21.0–26.60 & Non-Xbox XUID Isolation:
    #     - Non-Xbox Bedrock clients (xbox-auth-required: false) send empty extraData.xuid (""),
    #       which collided in SessionManager.isXuidAlreadyPending("") / sessionByXuid("") and kicked
    #       every 2nd+ non-Xbox subscriber with geyser.auth.already_loggedin!
    #     - Leaves ALL already-valid [a-zA-Z0-9_]{3,16} (including space->underscore Gamertags) 100% untouched,
    #       while auto-transliterating/sanitizing broken Bedrock nicknames (Cyrillic "Стив"/"Игрок", hyphens, dots, >16/<3).
    #     - Prevents forced GeyserIntegratedPack kicks on cellular/LTE clients when force-resource-packs: false.
    #     - Backports Oct 2026 Geyser fixes: duplicate rak-error-handler guard (#6746/#6824),
    #       null-safe 26.40-26.43 CodecProcessor.updateCodec, 1.21.130+ SkinManager PlayerList fix (#6725),
    #       and heterogeneous sign NBT safety (#6783).
    # =========================================================================
    login_enc_utils = root / "core/src/main/java/org/geysermc/geyser/util/LoginEncryptionUtils.java"
    replace_exact(
        login_enc_utils,
        """            session.setAuthData(new AuthData(extraData.displayName, extraData.identity, xuid, issuedAt, extraData.minecraftId));""",
        """            String effectiveDisplayName = sanitizeBedrockUsername(extraData.displayName, data.getDeviceId());
            if (!result.signed() || xuid == null || xuid.isBlank() || "0".equals(xuid)) {
                xuid = computeDeterministicOfflineXuid(effectiveDisplayName);
            }
            session.setAuthData(new AuthData(effectiveDisplayName, extraData.identity, xuid, issuedAt, extraData.minecraftId));""",
        "LoginEncryptionUtils.offlineXuidAndSafeUsername",
    )
    replace_exact(
        login_enc_utils,
        """    private static void startEncryptionHandshake(GeyserSession session, PublicKey key) throws Exception {""",
        """    public static String computeDeterministicOfflineXuid(String username) {
        String normalized = (username == null ? "player" : username.trim().toLowerCase(java.util.Locale.ROOT));
        java.util.UUID offlineId = java.util.UUID.nameUUIDFromBytes(
            ("OfflineBedrock:" + normalized).getBytes(java.nio.charset.StandardCharsets.UTF_8)
        );
        long synthetic = (offlineId.getLeastSignificantBits() & 0x0003FFFFFFFFFFFFL) | 0x0008000000000000L;
        return Long.toString(synthetic);
    }

    public static String sanitizeBedrockUsername(String rawName, String deviceId) {
        if (rawName == null) {
            rawName = "";
        }
        String spaceNormalized = rawName.trim().replace(' ', '_');
        if (isAsciiValidJavaName(spaceNormalized)) {
            return spaceNormalized;
        }
        String lowerTrimmed = rawName.trim().toLowerCase(java.util.Locale.ROOT);
        boolean genericDefault = lowerTrimmed.isEmpty()
            || lowerTrimmed.equals("стив")
            || lowerTrimmed.equals("игрок")
            || lowerTrimmed.equals("алекс");

        StringBuilder sb = new StringBuilder(spaceNormalized.length() + 4);
        for (int i = 0; i < spaceNormalized.length(); i++) {
            char c = spaceNormalized.charAt(i);
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_') {
                sb.append(c);
            } else if (c == '-' || c == '.') {
                sb.append('_');
            } else {
                sb.append(transliterateCyrillicChar(c));
            }
        }
        String cleaned = sb.toString().replaceAll("_+", "_");
        while (cleaned.startsWith("_") && cleaned.length() > 3) {
            cleaned = cleaned.substring(1);
        }
        while (cleaned.endsWith("_") && cleaned.length() > 3) {
            cleaned = cleaned.substring(0, cleaned.length() - 1);
        }
        if (cleaned.isEmpty()) {
            cleaned = "Player";
            genericDefault = true;
        }
        if (genericDefault || cleaned.length() < 3) {
            String seed = (deviceId != null && !deviceId.isBlank()) ? deviceId.trim() : rawName;
            int hash = seed.hashCode() & 0xFFFF;
            String hex = String.format(java.util.Locale.ROOT, "%04x", hash);
            int maxPrefix = Math.min(cleaned.length(), 11);
            String prefix = cleaned.substring(0, maxPrefix);
            if (prefix.isEmpty()) {
                prefix = "Plr";
            }
            cleaned = prefix + "_" + hex;
        }
        if (cleaned.length() > 16) {
            cleaned = cleaned.substring(0, 16);
        }
        while (cleaned.length() < 3) {
            cleaned = cleaned + "_";
        }
        return cleaned;
    }

    private static boolean isAsciiValidJavaName(String s) {
        if (s == null || s.length() < 3 || s.length() > 16) {
            return false;
        }
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            boolean ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_';
            if (!ok) {
                return false;
            }
        }
        return true;
    }

    private static String transliterateCyrillicChar(char ch) {
        boolean upper = Character.isUpperCase(ch);
        char lower = Character.toLowerCase(ch);
        String mapped = switch (lower) {
            case 'а' -> "a";
            case 'б' -> "b";
            case 'в' -> "v";
            case 'г' -> "g";
            case 'д' -> "d";
            case 'е', 'ё', 'э' -> "e";
            case 'ж' -> "zh";
            case 'з' -> "z";
            case 'и', 'і', 'ї' -> "i";
            case 'й' -> "y";
            case 'к' -> "k";
            case 'л' -> "l";
            case 'м' -> "m";
            case 'н' -> "n";
            case 'о' -> "o";
            case 'п' -> "p";
            case 'р' -> "r";
            case 'с' -> "s";
            case 'т' -> "t";
            case 'у' -> "u";
            case 'ф' -> "f";
            case 'х' -> "kh";
            case 'ц' -> "ts";
            case 'ч' -> "ch";
            case 'ш', 'щ' -> "sh";
            case 'ы' -> "y";
            case 'ю' -> "yu";
            case 'я' -> "ya";
            case 'ґ' -> "g";
            case 'є' -> "ye";
            default -> "";
        };
        if (mapped.isEmpty() || !upper) {
            return mapped;
        }
        return Character.toUpperCase(mapped.charAt(0)) + mapped.substring(1);
    }

    private static void startEncryptionHandshake(GeyserSession session, PublicKey key) throws Exception {""",
        "LoginEncryptionUtils.helperMethods",
    )

    session_mgr = root / "core/src/main/java/org/geysermc/geyser/session/SessionManager.java"
    replace_exact(
        session_mgr,
        """    public boolean isXuidAlreadyPending(String xuid) {
        for (GeyserSession session : pendingSessions) {
            if (session.xuid().equals(xuid)) {
                return true;
            }
        }
        return false;
    }

    public @Nullable GeyserSession sessionByXuid(@NonNull String xuid) {
        Objects.requireNonNull(xuid);
        for (GeyserSession session : sessions.values()) {
            if (session.xuid().equals(xuid)) {
                return session;
            }
        }
        return null;
    }""",
        """    public boolean isXuidAlreadyPending(String xuid) {
        if (xuid == null || xuid.isBlank() || "0".equals(xuid)) {
            return false;
        }
        for (GeyserSession session : pendingSessions) {
            if (xuid.equals(session.xuid())) {
                return true;
            }
        }
        return false;
    }

    public @Nullable GeyserSession sessionByXuid(@NonNull String xuid) {
        Objects.requireNonNull(xuid);
        if (xuid.isBlank() || "0".equals(xuid)) {
            return null;
        }
        for (GeyserSession session : sessions.values()) {
            if (xuid.equals(session.xuid())) {
                return session;
            }
        }
        return null;
    }""",
        "SessionManager.ignoreBlankOrZeroXuid",
    )

    replace_exact(
        upstream_handler,
        """        resourcePacksInfo.setVibrantVisualsForceDisabled(!session.isAllowVibrantVisuals());

        resourcePacksInfo.setForcedToAccept(GeyserImpl.getInstance().config().gameplay().forceResourcePacks() ||
            resourcePackLoadEvent.isIntegratedPackActive());""",
        """        boolean allowVibrant = Boolean.getBoolean("purpurbedrock.allowVibrantVisuals") && session.isAllowVibrantVisuals();
        resourcePacksInfo.setVibrantVisualsForceDisabled(!allowVibrant);

        resourcePacksInfo.setForcedToAccept(GeyserImpl.getInstance().config().gameplay().forceResourcePacks());""",
        "UpstreamPacketHandler.nonBlockingIntegratedPack",
    )
    replace_exact(
        upstream_handler,
        """            case REFUSED -> session.disconnect("disconnectionScreen.resourcePack");""",
        """            case REFUSED -> {
                if (GeyserImpl.getInstance().config().gameplay().forceResourcePacks()) {
                    session.disconnect("disconnectionScreen.resourcePack");
                } else {
                    ResourcePackStackPacket stackPacket = new ResourcePackStackPacket();
                    stackPacket.setExperimentsPreviouslyToggled(false);
                    stackPacket.setForcedToAccept(false);
                    stackPacket.setGameVersion("*");
                    if (session.protocolVersion() == 800) {
                        stackPacket.getExperiments().add(new org.cloudburstmc.protocol.bedrock.data.ExperimentData("y_2025_drop_2", true));
                        stackPacket.getExperiments().add(new org.cloudburstmc.protocol.bedrock.data.ExperimentData("locator_bar", true));
                    } else if (session.protocolVersion() == 827) {
                        stackPacket.getExperiments().add(new org.cloudburstmc.protocol.bedrock.data.ExperimentData("y_2025_drop_3", true));
                    }
                    session.sendUpstreamPacket(stackPacket);
                }
            }""",
        "UpstreamPacketHandler.allowJoinWhenOptionalPacksSkipped",
    )

    server_init = root / "core/src/main/java/org/geysermc/geyser/network/GeyserServerInitializer.java"
    replace_exact(
        server_init,
        """                channel.pipeline().addAfter(BedrockPeer.NAME, InvalidPacketHandler.NAME, new InvalidPacketHandler(session));""",
        """                if (channel.pipeline().get(InvalidPacketHandler.NAME) != null) {
                    channel.pipeline().replace(InvalidPacketHandler.NAME, InvalidPacketHandler.NAME, new InvalidPacketHandler(session));
                } else {
                    channel.pipeline().addAfter(BedrockPeer.NAME, InvalidPacketHandler.NAME, new InvalidPacketHandler(session));
                }""",
        "GeyserServerInitializer.duplicateRakErrorHandlerGuard",
    )

    replace_exact(
        codec_processor,
        """    public static void updateCodec(UpstreamSession upstreamSession, String version) {
        // Support all older 1.26.4x builds
        switch (version) {
            case "1.26.40", "1.26.41", "1.26.42", "1.26.43" -> {
                upstreamSession.getSession().setCodec(processCodec(Bedrock_v2168.CODEC));
            }
        }
    }""",
        """    public static void updateCodec(UpstreamSession upstreamSession, String version) {
        if (version == null) {
            return;
        }
        // Support all older 1.26.4x / 26.4x builds without NPE on custom clients
        switch (version.trim()) {
            case "1.26.40", "1.26.41", "1.26.42", "1.26.43",
                 "26.40", "26.41", "26.42", "26.43" -> {
                upstreamSession.getSession().setCodec(processCodec(Bedrock_v2168.CODEC));
            }
        }
    }""",
        "CodecProcessor.nullSafeUpdateCodec",
    )

    # Explicit opt-in diagnosis; no payloads or addresses, and only a volatile check while idle.
    diagnostic = root / "core/src/main/java/org/geysermc/geyser/session/RemoteSpawnDiagnostics.java"
    diagnostic.write_text((Path(__file__).resolve().parent / "assets/java/RemoteSpawnDiagnostics.java").read_text())
    session_source = root / "core/src/main/java/org/geysermc/geyser/session/GeyserSession.java"
    replace_exact(
        session_source,
        """    public void sendUpstreamPacket(BedrockPacket packet) {
        upstream.sendPacket(packet);
    }""",
        """    public void sendUpstreamPacket(BedrockPacket packet) {
        RemoteSpawnDiagnostics.recordBedrock(this, packet);
        upstream.sendPacket(packet);
    }""",
        "GeyserSession.observeNormalUpstream",
    )
    replace_exact(
        session_source,
        """    public void sendUpstreamPacketImmediately(BedrockPacket packet) {
        upstream.sendPacketImmediately(packet);
    }""",
        """    public void sendUpstreamPacketImmediately(BedrockPacket packet) {
        RemoteSpawnDiagnostics.recordBedrock(this, packet);
        upstream.sendPacketImmediately(packet);
    }""",
        "GeyserSession.observeImmediateUpstream",
    )
    adapter = root / "core/src/main/java/org/geysermc/geyser/session/GeyserSessionAdapter.java"
    replace_exact(
        adapter,
        """    public void packetReceived(Session session, Packet packet) {
        Registries.JAVA_PACKET_TRANSLATORS.translate(packet.getClass(), packet, this.session, true);
    }""",
        """    public void packetReceived(Session session, Packet packet) {
        RemoteSpawnDiagnostics.recordJava(this.session, packet);
        Registries.JAVA_PACKET_TRANSLATORS.translate(packet.getClass(), packet, this.session, true);
    }""",
        "GeyserSessionAdapter.observeJavaPackets",
    )

    steve_asset = root / "core/src/main/resources/bedrock/steve-wide.png"
    steve_asset.parent.mkdir(parents=True, exist_ok=True)
    steve_asset.write_bytes((Path(__file__).resolve().parent / "assets/steve-wide.png").read_bytes())
    skin_provider = root / "core/src/main/java/org/geysermc/geyser/skin/SkinProvider.java"
    replace_exact(
        skin_provider,
        """        return new SkinData(skin, cape, geometry);
    }

    /**
     * Used as a fallback if an official Java cape doesn't exist for this user.
     */""",
        """        return new SkinData(skin, cape, geometry);
    }

    /**
     * Lightweight 64x64 vanilla skin used for remote players on constrained Bedrock clients.
     * It deliberately excludes Bedrock persona geometry and capes, which can stall mobile rendering.
     */
    static SkinData determinePerformanceSafeSkinData(UUID uuid) {
        return BasicSteve.DATA;
    }

    // Loaded once from the engine JAR, never from the asynchronous client-asset cache.
    private static final class BasicSteve {
        private static final SkinData DATA = load();

        private static SkinData load() {
            try (var stream = SkinProvider.class.getResourceAsStream("/bedrock/steve-wide.png")) {
                if (stream == null) throw new IllegalStateException("Missing bundled Steve texture");
                BufferedImage image = ImageIO.read(stream);
                if (image == null || image.getWidth() != 64 || image.getHeight() != 64) {
                    throw new IllegalStateException("Invalid bundled Steve texture");
                }
                byte[] pixels = bufferedImageToImageData(image);
                image.flush();
                return new SkinData(new Skin("purpurbedrock:steve_wide_v1", pixels, true),
                        EMPTY_CAPE, SkinGeometry.WIDE);
            } catch (IOException e) {
                throw new IllegalStateException("Cannot read bundled Steve texture", e);
            }
        }
    }

    /**
     * Used as a fallback if an official Java cape doesn't exist for this user.
     */""",
        "SkinProvider.performanceSafeRemoteSkin",
    )

    skin_manager = root / "core/src/main/java/org/geysermc/geyser/skin/SkinManager.java"
    replace_exact(
        skin_manager,
        """public class SkinManager {

    private static final Map<ResolvableProfile, CompletableFuture<GameProfile>> requestedProfiles""",
        """public class SkinManager {

    public static boolean usePerformanceSafeRemoteSkin(GeyserSession session, UUID playerUuid) {
        // Every remote player is always rendered with one bundled wide Steve skin. This is
        // deliberately unconditional: no JVM flag, device detection, custom skin download,
        // persona geometry, cape, or post-spawn skin replacement can re-enter this hot path.
        // Only the viewer's own player keeps their real skin.
        return session.getPlayerEntity() != null
            && !playerUuid.equals(session.getPlayerEntity().uuid());
    }

    // A weak session map prevents repeated PlayerList ADD / skin recompilation every time
    // the same remote player enters view, teleports or respawns. Bedrock 26.x can otherwise
    // block its render thread for 10-20+ seconds on low-end Android/iOS devices.
    private static final Map<GeyserSession, java.util.Set<UUID>> PERFORMANCE_SAFE_SKINS_SENT =
        java.util.Collections.synchronizedMap(new java.util.WeakHashMap<>());

    private static boolean markPerformanceSafeSkinSent(GeyserSession session, UUID playerUuid) {
        synchronized (PERFORMANCE_SAFE_SKINS_SENT) {
            return PERFORMANCE_SAFE_SKINS_SENT
                .computeIfAbsent(session, ignored -> new java.util.HashSet<>())
                .add(playerUuid);
        }
    }

    // This tracks actual Bedrock list membership, not an irreversible "ever sent" flag.
    public static boolean forgetPerformanceSafeEntry(GeyserSession session, UUID playerUuid) {
        synchronized (PERFORMANCE_SAFE_SKINS_SENT) {
            java.util.Set<UUID> entries = PERFORMANCE_SAFE_SKINS_SENT.get(session);
            return entries != null && entries.remove(playerUuid);
        }
    }

    public static boolean hasPerformanceSafeEntry(GeyserSession session, UUID playerUuid) {
        synchronized (PERFORMANCE_SAFE_SKINS_SENT) {
            java.util.Set<UUID> entries = PERFORMANCE_SAFE_SKINS_SENT.get(session);
            return entries != null && entries.contains(playerUuid);
        }
    }

    private static PlayerListPacket.Entry buildPerformanceSafeEntry(GeyserSession session, AvatarEntity entity, SkinData safe) {
        PlayerListPacket.Entry entry = PlayerListUtils.buildEntryManually(
            session,
            entity.uuid(),
            entity.getUsername(),
            entity.geyserId(),
            getSkin(session, safe.skin().textureUrl(), safe.skin(), safe.cape(), safe.geometry())
        );
        // Never expose a remote Xbox identity on constrained clients. A non-empty XUID makes
        // Bedrock perform its own profile/appearance lookup and defeats the shared bundled skin.
        entry.setXuid("");
        entry.setPlatformChatId("");
        return entry;
    }

    public static void ensurePerformanceSafeEntryBeforeSpawn(GeyserSession session, AvatarEntity entity) {
        if (!usePerformanceSafeRemoteSkin(session, entity.uuid())
                || !markPerformanceSafeSkinSent(session, entity.uuid())) {
            return;
        }
        SkinData safe = SkinProvider.determinePerformanceSafeSkinData(entity.uuid());
        PlayerListUtils.sendSkinUsingPlayerList(
            session, buildPerformanceSafeEntry(session, entity, safe), entity, true
        );
    }

    private static final Map<ResolvableProfile, CompletableFuture<GameProfile>> requestedProfiles""",
        "SkinManager.performanceSafeRemoteSkinClassifier",
    )
    replace_exact(
        skin_manager,
        """    public static PlayerListPacket.Entry buildEntryFromCachedSkin(GeyserSession session, AvatarEntity playerEntity) {
        // First: see if we have the cached skin texture ID.""",
        """    public static PlayerListPacket.Entry buildEntryFromCachedSkin(GeyserSession session, AvatarEntity playerEntity) {
        if (usePerformanceSafeRemoteSkin(session, playerEntity.uuid())) {
            markPerformanceSafeSkinSent(session, playerEntity.uuid());
            SkinData safe = SkinProvider.determinePerformanceSafeSkinData(playerEntity.uuid());
            return buildPerformanceSafeEntry(session, playerEntity, safe);
        }
        // First: see if we have the cached skin texture ID.""",
        "SkinManager.performanceSafeCachedEntry",
    )
    replace_exact(
        skin_manager,
        """    public static void sendSkinPacket(GeyserSession session, AvatarEntity entity, SkinData skinData) {
        Skin skin = skinData.skin();""",
        """    public static void sendSkinPacket(GeyserSession session, AvatarEntity entity, SkinData skinData) {
        boolean performanceSafe = usePerformanceSafeRemoteSkin(session, entity.uuid());
        if (performanceSafe) {
            // Remote appearance is installed once through PlayerList before AddPlayer. Never send
            // PlayerSkin or another PlayerList ADD afterwards: even an identical replacement can
            // synchronously rebuild the model and freeze the render thread on powerful clients.
            return;
        }
        Skin skin = skinData.skin();""",
        "SkinManager.performanceSafeSkinUpdates",
    )
    replace_exact(
        skin_manager,
        """    public static void requestAndHandleSkinAndCape(AvatarEntity entity, GeyserSession session, Consumer<SkinProvider.SkinAndCape> skinAndCapeConsumer) {
        SkinProvider.requestSkinData(entity, session).whenCompleteAsync((skinData, throwable) -> {""",
        """    public static void requestAndHandleSkinAndCape(AvatarEntity entity, GeyserSession session, Consumer<SkinProvider.SkinAndCape> skinAndCapeConsumer) {
        if (usePerformanceSafeRemoteSkin(session, entity.uuid())) {
            SkinData safe = SkinProvider.determinePerformanceSafeSkinData(entity.uuid());
            // The single Steve entry is installed before AddPlayer. Satisfy callbacks without
            // downloading or sending any skin update after the remote entity becomes visible.
            if (skinAndCapeConsumer != null) {
                skinAndCapeConsumer.accept(new SkinProvider.SkinAndCape(safe.skin(), safe.cape()));
            }
            return;
        }
        SkinProvider.requestSkinData(entity, session).whenCompleteAsync((skinData, throwable) -> {""",
        "SkinManager.skipRemoteSkinFetchOnConstrainedClients",
    )
    replace_exact(
        skin_manager,
        """            PlayerListPacket.Entry entry = PlayerListUtils.buildEntryManually(
                session,
                entity.uuid(),
                entity.getUsername(),
                entity.geyserId(),
                getSkin(session, skin.textureUrl(), skin, cape, geometry)
            );

            // Slight delay ensures skins are actually shown""",
        """            PlayerListPacket.Entry entry = performanceSafe
                ? buildPerformanceSafeEntry(session, entity, skinData)
                : PlayerListUtils.buildEntryManually(
                    session,
                    entity.uuid(),
                    entity.getUsername(),
                    entity.geyserId(),
                    getSkin(session, skin.textureUrl(), skin, cape, geometry)
                );

            // Slight delay ensures skins are actually shown""",
        "SkinManager.clearRemoteIdentityForSafeSkinUpdates",
    )
    replace_exact(
        skin_manager,
        """        // Since 1.21.130: PlayerSkinPacket only works if player is listed; might as well always use the player list packet
        if (entity.uuid().equals(session.getPlayerEntity().uuid()) || !entity.isListed()) {""",
        """        // Upstream #6725: Since 1.21.130 (v898+), PlayerSkinPacket no longer reliably updates listed players
        if (session.protocolVersion() >= 898 || entity.uuid().equals(session.getPlayerEntity().uuid()) || !entity.isListed()) {""",
        "SkinManager.playerListSkinOnModernProtocols",
    )

    player_info_update = root / "core/src/main/java/org/geysermc/geyser/translator/protocol/java/entity/player/JavaPlayerInfoUpdateTranslator.java"
    replace_exact(
        player_info_update,
        """                if (entry.isListed()) {
                    if (!PlayerListUtils.shouldLimitPlayerListEntries(session)) {""",
        """                if (entry.isListed()) {
                    // Some servers repeat UPDATE_LISTED=true around respawns and teleports.
                    // Re-adding an already listed player forces weak clients to rebuild appearance data.
                    if (SkinManager.usePerformanceSafeRemoteSkin(session, entity.uuid())
                            && SkinManager.hasPerformanceSafeEntry(session, entity.uuid())) {
                        entity.setListed(true);
                        continue;
                    }
                    if (!PlayerListUtils.shouldLimitPlayerListEntries(session)) {""",
        "JavaPlayerInfoUpdateTranslator.deduplicateConstrainedPlayerListAdds",
    )

    replace_exact(
        player_info_update,
        """                        PlayerListPacket.Entry playerListEntry = new PlayerListPacket.Entry(entity.getTabListUuid());
                        playerListEntry.setAction(PlayerListPacket.Action.REMOVE);""",
        """                        SkinManager.forgetPerformanceSafeEntry(session, entity.uuid());
                        PlayerListPacket.Entry playerListEntry = new PlayerListPacket.Entry(entity.getTabListUuid());
                        playerListEntry.setAction(PlayerListPacket.Action.REMOVE);""",
        "JavaPlayerInfoUpdateTranslator.forgetRemovedSafeEntry",
    )

    player_info_remove = root / "core/src/main/java/org/geysermc/geyser/translator/protocol/java/entity/player/JavaPlayerInfoRemoveTranslator.java"
    replace_exact(
        player_info_remove,
        "import org.geysermc.geyser.session.GeyserSession;",
        "import org.geysermc.geyser.session.GeyserSession;\nimport org.geysermc.geyser.skin.SkinManager;",
        "JavaPlayerInfoRemoveTranslator.importSafeSkinTracker",
    )
    replace_exact(
        player_info_remove,
        """                // Only unlist entities that are actually listed
                if (!entity.isListed()) {
                    continue;
                }""",
        """                // A hidden Java entry may still have been installed for actor spawning.
                boolean safeEntry = SkinManager.forgetPerformanceSafeEntry(session, id);
                if (!entity.isListed() && !safeEntry) {
                    continue;
                }""",
        "JavaPlayerInfoRemoveTranslator.forgetSafeEntry",
    )

    player_entity = root / "core/src/main/java/org/geysermc/geyser/entity/type/player/PlayerEntity.java"
    replace_exact(
        player_entity,
        "import org.geysermc.geyser.util.PlayerListUtils;",
        "import org.geysermc.geyser.util.PlayerListUtils;\nimport org.geysermc.geyser.skin.SkinManager;",
        "PlayerEntity.importSafeSkinTracker",
    )
    replace_exact(
        player_entity,
        """    private boolean listed = false;

    public PlayerEntity""",
        """    private boolean listed = false;

    private final RemoteEquipmentBatch remoteEquipmentBatch = new RemoteEquipmentBatch(
        task -> session.scheduleInEventLoop(task, 75, TimeUnit.MILLISECONDS),
        flags -> {
            if (!isValid()) return;
            if ((flags & RemoteEquipmentBatch.ARMOR) != 0) updateArmor();
            if ((flags & RemoteEquipmentBatch.MAIN_HAND) != 0) updateMainHand();
            if ((flags & RemoteEquipmentBatch.OFF_HAND) != 0) updateOffHand();
        });

    public void queueRemoteEquipment(boolean armor, boolean mainHand, boolean offHand) {
        int flags = (armor ? RemoteEquipmentBatch.ARMOR : 0)
            | (mainHand ? RemoteEquipmentBatch.MAIN_HAND : 0)
            | (offHand ? RemoteEquipmentBatch.OFF_HAND : 0);
        remoteEquipmentBatch.update(flags);
    }

    public PlayerEntity""",
        "PlayerEntity.coalesceRemoteEquipment",
    )
    replace_exact(
        player_entity,
        """    public void despawnEntity() {
        super.despawnEntity();""",
        """    public void despawnEntity() {
        remoteEquipmentBatch.invalidate();
        super.despawnEntity();""",
        "PlayerEntity.invalidateRemoteEquipmentOnDespawn",
    )
    replace_exact(
        player_entity,
        """        if (PlayerListUtils.shouldLimitPlayerListEntries(session)) {
            PlayerListPacket packet = new PlayerListPacket();""",
        """        if (PlayerListUtils.shouldLimitPlayerListEntries(session)) {
            SkinManager.forgetPerformanceSafeEntry(session, uuid());
            PlayerListPacket packet = new PlayerListPacket();""",
        "PlayerEntity.forgetLimitedPlayerListEntry",
    )
    remote_batch = root / "core/src/main/java/org/geysermc/geyser/entity/type/player/RemoteEquipmentBatch.java"
    remote_batch.write_text((Path(__file__).resolve().parent / "assets/java/RemoteEquipmentBatch.java").read_text())

    add_entity_translator = root / "core/src/main/java/org/geysermc/geyser/translator/protocol/java/entity/JavaAddEntityTranslator.java"
    replace_exact(
        add_entity_translator,
        """            entity.sendPlayer();
            // only load skin if we're not in a test environment.
            // Otherwise, it tries to load various resources
            if (!EnvironmentUtils.IS_UNIT_TESTING) {
                SkinManager.requestAndHandleSkinAndCape(entity, session, null);
            }""",
        """            // Install the shared 64x64 skin before AddPlayer. If AddPlayer arrives first,
            // Bedrock may synchronously resolve/compile the remote persona and freeze rendering.
            SkinManager.ensurePerformanceSafeEntryBeforeSpawn(session, entity);
            entity.sendPlayer();
            // Never send a post-spawn skin replacement or start a second asynchronous pipeline.
            if (!EnvironmentUtils.IS_UNIT_TESTING
                    && !SkinManager.usePerformanceSafeRemoteSkin(session, entity.uuid())) {
                SkinManager.requestAndHandleSkinAndCape(entity, session, null);
            }""",
        "JavaAddEntityTranslator.safeSkinBeforeSpawn",
    )

    # Keep upstream 20 Hz player movement semantics. Coalescing player deltas here can
    # desynchronise the first movement after AddPlayer and prolong the client's spawn stall.

    avatar_entity = root / "core/src/main/java/org/geysermc/geyser/entity/type/player/AvatarEntity.java"
    replace_exact(
        avatar_entity,
        """import org.cloudburstmc.protocol.bedrock.data.command.CommandPermission;
import org.cloudburstmc.protocol.bedrock.data.entity.EntityDataTypes;""",
        """import org.cloudburstmc.protocol.bedrock.data.command.CommandPermission;
import org.cloudburstmc.protocol.bedrock.data.inventory.ItemData;
import org.cloudburstmc.protocol.bedrock.data.entity.EntityDataTypes;""",
        "AvatarEntity.importAirItem",
    )
    replace_exact(
        avatar_entity,
        """        addPlayerPacket.setHand(ItemTranslator.translateToBedrock(session, getMainHandItem()));""",
        """        // Remote players are deliberately one immutable basic Steve. Do not put custom
        // item components into AddPlayer: decoding a large held item on the render thread can
        // freeze every class of client exactly when the actor enters tracking distance.
        addPlayerPacket.setHand(this instanceof SessionPlayerEntity
            ? ItemTranslator.translateToBedrock(session, getMainHandItem())
            : ItemData.AIR);""",
        "AvatarEntity.basicRemoteSpawnHand",
    )

    equipment_translator = root / "core/src/main/java/org/geysermc/geyser/translator/protocol/java/entity/JavaSetEquipmentTranslator.java"
    replace_exact(
        equipment_translator,
        """        if (!(entity instanceof LivingEntity livingEntity)) {
            session.getGeyser().getLogger().debug("Attempted to add armor to a non-living entity (" +
                    entity.definition().identifier() + ").");
            return;
        }

        boolean armorUpdated = false;""",
        """        if (!(entity instanceof LivingEntity livingEntity)) {
            session.getGeyser().getLogger().debug("Attempted to add armor to a non-living entity (" +
                    entity.definition().identifier() + ").");
            return;
        }

        // Restore vanilla equipment visuals, but never translate remote custom components.
        boolean basicRemoteEquipment = livingEntity instanceof PlayerEntity
                && livingEntity != session.getPlayerEntity();

        boolean armorUpdated = false;""",
        "JavaSetEquipmentTranslator.suppressRemotePlayerVisualEquipment",
    )

    replace_exact(
        equipment_translator,
        "            GeyserItemStack stack = GeyserItemStack.from(session, equipment.getItem());",
        """            var item = equipment.getItem();
            GeyserItemStack stack = basicRemoteEquipment && item != null
                    ? GeyserItemStack.of(session, item.getId(), item.getAmount())
                    : GeyserItemStack.from(session, item);""",
        "JavaSetEquipmentTranslator.basicRemoteEquipment",
    )

    replace_exact(
        equipment_translator,
        """        if (armorUpdated) {
            livingEntity.updateArmor();
        }""",
        """        if (basicRemoteEquipment) {
            // Merge bursts on the viewer's event loop; never discard the final slot values.
            ((PlayerEntity) livingEntity).queueRemoteEquipment(armorUpdated, mainHandUpdated, offHandUpdated);
            return;
        }
        if (armorUpdated) {
            livingEntity.updateArmor();
        }""",
        "JavaSetEquipmentTranslator.coalesceRemoteVisualUpdates",
    )

    sign_translator = root / "core/src/main/java/org/geysermc/geyser/translator/level/block/entity/SignBlockEntityTranslator.java"
    replace_exact(
        sign_translator,
        """        List<?> rawMessages = javaNbt.getList("messages", NbtType.COMPOUND);
        if (rawMessages.isEmpty()) {
            rawMessages = javaNbt.getList("messages", NbtType.STRING);
        }
        List<String> messages = MessageTranslator.signTextFromNbtTag(session, rawMessages);""",
        """        List<String> messages;
        try {
            Object rawObj = javaNbt.get("messages");
            List<?> rawMessages = (rawObj instanceof List<?> rawList) ? rawList : java.util.Collections.emptyList();
            messages = MessageTranslator.signTextFromNbtTag(session, rawMessages);
        } catch (RuntimeException ignored) {
            messages = java.util.Collections.emptyList();
        }""",
        "SignBlockEntityTranslator.safeHeterogeneousNbtSignList",
    )

    # =========================================================================
    # 15. Mobile Anti-Crash & Instant-Join Suite (Galaxy A07 / 3-4GB RAM Android & iOS):
    #     - Upstream #6698 CustomSkull / SkullCache allocation optimization + thread-safe SkullSkinManager.
    #     - Slim AvailableCommandsPacket on 50+ plugin servers (strips plugin:cmd duplicates & caps at 96).
    #     - UTF-8 byte-safe BossBar title truncation (<= 236 UTF-8 bytes for 2-byte Cyrillic + hex gradients).
    #     - Mobile render-distance clamp (<= 8 chunks on Android/iOS/Switch; PC & Xbox/PS5 uncapped).
    # =========================================================================
    custom_skull_cls = root / "core/src/main/java/org/geysermc/geyser/registry/type/CustomSkull.java"
    replace_exact(
        custom_skull_cls,
        """    private static final int[] ROTATIONS = {0, -90, 180, 90};""",
        """    private static final int[] ROTATIONS = {0, -90, 180, 90};
    private static final String[] QUADRANT_NAMES = {"a", "b", "c", "d"};""",
        "CustomSkull.staticQuadrantNames",
    )
    replace_exact(
        custom_skull_cls,
        """                .intProperty(BITS_A_PROPERTY, IntStream.rangeClosed(0, 6).boxed().toList()) // This gives us exactly 21 block states
                .intProperty(BITS_B_PROPERTY, IntStream.rangeClosed(0, 2).boxed().toList())""",
        """                .intProperty(BITS_A_PROPERTY, List.of(0, 1, 2, 3, 4, 5, 6)) // This gives us exactly 21 block states
                .intProperty(BITS_B_PROPERTY, List.of(0, 1, 2))""",
        "CustomSkull.staticPropertyLists",
    )
    replace_exact(
        custom_skull_cls,
        """    private void addFloorPermutations(List<CustomBlockPermutation> permutations) {
        String[] quadrantNames = {"a", "b", "c", "d"};

        for (int quadrant = 0; quadrant < 4; quadrant++) {
            for (int i = 0; i < 4; i++) {
                int floorRotation = 4 * quadrant + i;
                CustomBlockComponents components = new GeyserCustomBlockComponents.Builder()
                        .selectionBox(FLOOR_BOX)
                        .collisionBox(FLOOR_BOX)
                        .geometry(new GeyserGeometryComponent.Builder()
                                .identifier("geometry.geyser.player_skull_floor_" + quadrantNames[i])""",
        """    private void addFloorPermutations(List<CustomBlockPermutation> permutations) {
        for (int quadrant = 0; quadrant < 4; quadrant++) {
            for (int i = 0; i < 4; i++) {
                int floorRotation = 4 * quadrant + i;
                CustomBlockComponents components = new GeyserCustomBlockComponents.Builder()
                        .selectionBox(FLOOR_BOX)
                        .collisionBox(FLOOR_BOX)
                        .geometry(new GeyserGeometryComponent.Builder()
                                .identifier("geometry.geyser.player_skull_floor_" + QUADRANT_NAMES[i])""",
        "CustomSkull.useStaticQuadrants",
    )

    skull_cache_cls = root / "core/src/main/java/org/geysermc/geyser/session/cache/SkullCache.java"
    replace_exact(
        skull_cache_cls,
        """public class SkullCache {
    private final int maxVisibleSkulls;""",
        """public class SkullCache {
    private static final Comparator<Skull> DISTANCE_COMPARATOR = Comparator.comparingInt(Skull::getDistanceSquared);
    private final int maxVisibleSkulls;""",
        "SkullCache.staticDistanceComparator",
    )
    replace_exact(
        skull_cache_cls,
        """                int i = Collections.binarySearch(inRangeSkulls, skull, Comparator.comparingInt(Skull::getDistanceSquared));""",
        """                int i = Collections.binarySearch(inRangeSkulls, skull, DISTANCE_COMPARATOR);""",
        "SkullCache.binarySearchStaticComparator",
    )
    replace_exact(
        skull_cache_cls,
        """            inRangeSkulls.sort(Comparator.comparingInt(Skull::getDistanceSquared));""",
        """            inRangeSkulls.sort(DISTANCE_COMPARATOR);""",
        "SkullCache.sortStaticComparator",
    )

    skull_skin_mgr = root / "core/src/main/java/org/geysermc/geyser/skin/SkullSkinManager.java"
    replace_exact(
        skull_skin_mgr,
        """            .geometryDataEngineVersion(session.getClientData().getGameVersion())""",
        """            .geometryDataEngineVersion(session.getClientData() != null && session.getClientData().getGameVersion() != null ? session.getClientData().getGameVersion() : "")""",
        "SkullSkinManager.nullSafeEngineVersion",
    )
    replace_exact(
        skull_skin_mgr,
        """        BiConsumer<Skin, Throwable> applySkin = (skin, throwable) -> {
            SerializedSkin serializedSkin = buildSkullEntryManually(session, skin.textureUrl(), skin.skinData());
            // Since 1.21.130: PlayerSkinPacket only works if player entity is listed
            PlayerListUtils.sendSkinUsingPlayerList(session, PlayerListUtils.forSkullPlayerEntity(entity, serializedSkin), entity, false);

            if (skinConsumer != null) {
                skinConsumer.accept(skin);
            }
        };""",
        """        BiConsumer<Skin, Throwable> applySkin = (skin, throwable) -> {
            if (throwable != null || skin == null || session.isClosed()) {
                return;
            }
            session.ensureInEventLoop(() -> {
                if (session.isClosed()) {
                    return;
                }
                SerializedSkin serializedSkin = buildSkullEntryManually(session, skin.textureUrl(), skin.skinData());
                // Since 1.21.130: PlayerSkinPacket only works if player entity is listed
                PlayerListUtils.sendSkinUsingPlayerList(session, PlayerListUtils.forSkullPlayerEntity(entity, serializedSkin), entity, false);

                if (skinConsumer != null) {
                    skinConsumer.accept(skin);
                }
            });
        };""",
        "SkullSkinManager.eventLoopAndNullSafeApplySkin",
    )

    commands_translator = root / "core/src/main/java/org/geysermc/geyser/translator/protocol/java/JavaCommandsTranslator.java"
    replace_exact(
        commands_translator,
        """    private static final String[] ENUM_BOOLEAN = {"true", "false"};""",
        """    private static final String[] ENUM_BOOLEAN = {"true", "false"};
    private static final Set<String> PRIORITY_PLAYER_COMMANDS = Set.of(
        "reg", "register", "l", "login", "changepassword", "logout",
        "spawn", "hub", "lobby", "rtp", "wild", "tpa", "tpahere", "tpaccept", "tpdeny", "tpyes", "tpno",
        "home", "homes", "sethome", "delhome", "warp", "warps", "back", "near",
        "shop", "menu", "donate", "cases", "pay", "bal", "balance", "money",
        "ah", "auc", "auction", "clan", "clans", "kit", "kits",
        "msg", "tell", "w", "r", "reply", "ignore", "bc",
        "ec", "enderchest", "craft", "wb", "anvil", "repair", "fix", "feed", "heal", "fly",
        "pvp", "duel", "rules", "report", "list", "help", "pb", "purpurbedrock"
    );""",
        "JavaCommandsTranslator.priorityPlayerCommands",
    )
    replace_exact(
        commands_translator,
        """        // Loop through the root nodes to get all commands
        for (int nodeIndex : rootNode.getChildIndices()) {
            CommandNode node = nodes[nodeIndex];

            // Make sure we don't have duplicated commands (happens if there is more than 1 root node)
            if (!commandNodes.add(nodeIndex) || !knownAliases.add(node.getName().toLowerCase(Locale.ROOT))) continue;

            // Get and update the commandArgs list with the found arguments
            if (node.getChildIndices().length >= 1) {
                for (int childIndex : node.getChildIndices()) {
                    commandArgs.computeIfAbsent(nodeIndex, ($) -> new ArrayList<>()).add(nodes[childIndex]);
                }
            }

            // Get and parse all params
            CommandOverloadData[] params = getParams(session, nodes[nodeIndex], nodes);

            // Insert the alias name into the command list
            String name = node.getName().toLowerCase(Locale.ROOT);
            String description = registry.description(name, session.locale());
            BedrockCommandInfo info = new BedrockCommandInfo(name, description, params);
            commands.computeIfAbsent(info, $ -> new HashSet<>()).add(name);

            // Add the command to the command lists
            knownCommands.add(name);
            if (node.isAllowsRestricted()) { // Name is a bit confusing - this is what we want
                restrictedCommands.add(name);
            }
        }""",
        """        int maxClientCommands = Math.max(32, Integer.getInteger("purpurbedrock.maxClientCommands", 96));
        int advertisedCount = 0;
        // Loop through the root nodes to get all commands
        for (int nodeIndex : rootNode.getChildIndices()) {
            CommandNode node = nodes[nodeIndex];
            String name = node.getName().toLowerCase(Locale.ROOT);

            // Make sure we don't have duplicated commands (happens if there is more than 1 root node)
            if (!commandNodes.add(nodeIndex) || !knownAliases.add(name)) continue;

            // Always keep 100% of commands in server-side knownCommands
            knownCommands.add(name);
            if (node.isAllowsRestricted()) {
                restrictedCommands.add(name);
            }

            // Skip plugin:command namespaced duplicates and WorldEdit //-commands in client packet to prevent mobile crashes
            if (name.indexOf(':') >= 0 || name.startsWith("/")) {
                continue;
            }
            if (advertisedCount >= maxClientCommands && !PRIORITY_PLAYER_COMMANDS.contains(name)) {
                continue;
            }

            // Get and update the commandArgs list with the found arguments
            if (node.getChildIndices().length >= 1) {
                for (int childIndex : node.getChildIndices()) {
                    commandArgs.computeIfAbsent(nodeIndex, ($) -> new ArrayList<>()).add(nodes[childIndex]);
                }
            }

            // Get and parse all params
            CommandOverloadData[] params = getParams(session, nodes[nodeIndex], nodes);
            String description = registry.description(name, session.locale());
            BedrockCommandInfo info = new BedrockCommandInfo(name, description, params);
            commands.computeIfAbsent(info, $ -> new HashSet<>()).add(name);
            advertisedCount++;
        }""",
        "JavaCommandsTranslator.slimPluginCommandsForMobile",
    )

    boss_bar_cls = root / "core/src/main/java/org/geysermc/geyser/session/cache/BossBar.java"
    replace_exact(
        boss_bar_cls,
        """    private String bossbarTitle(Component title) {
        String message = MessageTranslator.convertMessage(title, session.locale()).replace("%", "%%%%");

        if (message.length() > 256) {
            GeyserImpl.getInstance().getLogger().debug(session, "Bossbar with a length higher than 256! Limiting length.");
            message = message.substring(0, 253) + "...";
        }

        return message;
    }""",
        """    private String bossbarTitle(Component title) {
        String message = MessageTranslator.convertMessage(title, session.locale()).replace("%", "%%%%");
        byte[] utf8 = message.getBytes(java.nio.charset.StandardCharsets.UTF_8);
        if (utf8.length <= 236) {
            return message;
        }
        GeyserImpl.getInstance().getLogger().debug(session, "Bossbar UTF-8 byte length > 236 (" + utf8.length + "B)! Limiting length.");
        int byteCount = 0;
        int endIdx = 0;
        while (endIdx < message.length()) {
            int cp = message.codePointAt(endIdx);
            int cpBytes = cp <= 0x7F ? 1 : (cp <= 0x7FF ? 2 : (cp <= 0xFFFF ? 3 : 4));
            if (byteCount + cpBytes > 233) {
                break;
            }
            byteCount += cpBytes;
            endIdx += Character.charCount(cp);
        }
        if (endIdx > 0 && message.charAt(endIdx - 1) == '\\u00a7') {
            endIdx--;
        }
        return message.substring(0, endIdx) + "...";
    }""",
        "BossBar.utf8ByteSafeCyrillicTitleCap",
    )

    req_chunk_radius = root / "core/src/main/java/org/geysermc/geyser/translator/protocol/bedrock/BedrockRequestChunkRadiusTranslator.java"
    replace_exact(
        req_chunk_radius,
        """    @Override
    public void translate(GeyserSession session, RequestChunkRadiusPacket packet) {
        session.setClientRenderDistance(packet.getRadius());""",
        """    @Override
    public void translate(GeyserSession session, RequestChunkRadiusPacket packet) {
        int requested = packet.getRadius();
        String devOs = (session.getClientData() != null && session.getClientData().getDeviceOs() != null)
            ? session.getClientData().getDeviceOs().name()
            : "";
        if ("GOOGLE".equals(devOs) || "IOS".equals(devOs) || "AMAZON".equals(devOs) || "NX".equals(devOs)) {
            int maxMobileDist = Math.max(5, Integer.getInteger("purpurbedrock.maxMobileRenderDistance", 8));
            requested = Math.min(requested, maxMobileDist);
        }
        session.setClientRenderDistance(requested);""",
        "BedrockRequestChunkRadiusTranslator.mobileSafeChunkRadius",
    )

    # 16. Configuration-phase Dialog & USER_BUSY Form Resilience Suite:
    # - FormCache: handle ModalFormCancelReason.USER_BUSY by keeping the form cached and
    #   retrying 350ms later instead of firing closedOrInvalidResultHandler (which previously
    #   either cancelled Configuration dialogs -> 30s Bedrock timeout or entered a 0ms reopen loop).
    # - BedrockSetLocalPlayerAsInitializedTranslator: wait 350ms after SetLocalPlayerAsInitialized
    #   before pushing queued Configuration/Auth forms so mobile clients finish dismissing the
    #   "Loading world / Leave" screen without a C++ UI ScreenController crash.
    # - DialogHolder: rate-limit non-escapable reopenDialog() by 250ms to prevent 0ms packet storms.
    # - GeyserSession.prepareForConfigurationForm: publish a temporary 4-chunk view + 5x5 empty
    #   chunks + SERVER_READY respawn at (0, 66, 0) without setting spawned=true or lastChunkPosition
    #   so Bedrock clients immediately exit the loading screen during CONFIGURATION phase.
    # - JavaLoginTranslator: flush sendPostStartGamePackets() and reset lastChunkPosition when
    #   transitioning from prepareForConfigurationForm() (!needsSpawnPacket) into GAME state.
    # - Dialog / DialogButton / JavaShowDialogueConfigurationTranslator: null-safe labels & titles
    #   and exception guard so malformed plugin dialog NBT never crashes CONFIGURATION login.
    form_cache_cls = root / "core/src/main/java/org/geysermc/geyser/session/cache/FormCache.java"
    replace_exact(
        form_cache_cls,
        """    private final Int2ObjectMap<Form> forms = new Int2ObjectOpenHashMap<>();
    private final GeyserSession session;""",
        """    private final Int2ObjectMap<Form> forms = new Int2ObjectOpenHashMap<>();
    private final java.util.concurrent.ConcurrentHashMap<Integer, Integer> userBusyRetries = new java.util.concurrent.ConcurrentHashMap<>();
    private final GeyserSession session;""",
        "FormCache.userBusyRetriesField",
    )
    replace_exact(
        form_cache_cls,
        """    public void handleResponse(ModalFormResponsePacket response) {
        Form form = forms.remove(response.getFormId());
        if (form == null) {
            return;
        }""",
        """    public void handleResponse(ModalFormResponsePacket response) {
        if (response.getCancelReason() != null
                && response.getCancelReason().isPresent()
                && response.getCancelReason().get() == org.cloudburstmc.protocol.bedrock.data.ModalFormCancelReason.USER_BUSY) {
            Form busyForm = forms.get(response.getFormId());
            if (busyForm != null) {
                int retries = userBusyRetries.getOrDefault(response.getFormId(), 0);
                if (retries < 25) {
                    userBusyRetries.put(response.getFormId(), retries + 1);
                    final int fid = response.getFormId();
                    session.scheduleInEventLoop(() -> {
                        Form current = forms.get(fid);
                        if (current != null && session.getUpstream().isInitialized() && !session.isClosed()) {
                            sendForm(fid, current);
                        }
                    }, 350, TimeUnit.MILLISECONDS);
                    return;
                }
            }
        }
        userBusyRetries.remove(response.getFormId());

        Form form = forms.remove(response.getFormId());
        if (form == null) {
            return;
        }""",
        "FormCache.handleUserBusyRetry",
    )
    replace_exact(
        form_cache_cls,
        """    public void closeForms() {
        if (!this.forms.isEmpty()) {""",
        """    public void closeForms() {
        userBusyRetries.clear();
        if (!this.forms.isEmpty()) {""",
        "FormCache.clearUserBusyRetriesOnClose",
    )

    init_trans = root / "core/src/main/java/org/geysermc/geyser/translator/protocol/bedrock/BedrockSetLocalPlayerAsInitializedTranslator.java"
    replace_exact(
        init_trans,
        """                    // What am I to expect - as of Bedrock 1.18
                    session.getFormCache().resendAllForms();""",
        """                    // Purpurbedrock: allow mobile clients 350ms to finish dismissing the "Loading world / Leave"
                    // screen before pushing queued Configuration/Auth ModalFormRequestPackets onto the UI stack
                    if (session.getFormCache().hasFormOpen()) {
                        session.scheduleInEventLoop(() -> {
                            if (!session.isClosed() && session.getFormCache().hasFormOpen()) {
                                session.getFormCache().resendAllForms();
                            }
                        }, 350, java.util.concurrent.TimeUnit.MILLISECONDS);
                    }""",
        "BedrockSetLocalPlayerAsInitializedTranslator.delayedPostLoadFormSend",
    )

    replace_exact(
        dialog_holder,
        """        // If player should not have been able to close the dialog, reopen it with the last inputs
        reopenDialog();""",
        """        // Purpurbedrock: debounce non-escapable reopen by 250ms to prevent 0ms ModalFormRequest storms on mobile
        session.scheduleInEventLoop(this::reopenDialog, 250, java.util.concurrent.TimeUnit.MILLISECONDS);""",
        "DialogHolder.debounceNonEscapableReopen",
    )

    replace_exact(
        geyser_session,
        """    public void prepareForConfigurationForm() {
        if (!sentSpawnPacket) {
            connect();
        }
        // Disable time progression whilst the form is open
        // Once logged into the game this is set correctly when receiving a time packet from the server
        resetTimeParameters();
    }""",
        """    public void prepareForConfigurationForm() {
        if (!sentSpawnPacket) {
            connect();
            upstream.sendPostStartGamePackets();

            org.cloudburstmc.protocol.bedrock.packet.ChunkRadiusUpdatedPacket configRadiusPacket =
                new org.cloudburstmc.protocol.bedrock.packet.ChunkRadiusUpdatedPacket();
            configRadiusPacket.setRadius(4);
            upstream.sendPacket(configRadiusPacket);

            org.cloudburstmc.math.vector.Vector3i zeroPos = org.cloudburstmc.math.vector.Vector3i.from(0, 64, 0);
            ChunkUtils.forceUpdateChunkPosition(this, zeroPos);
            ChunkUtils.sendEmptyChunks(this, zeroPos, 2, false);

            org.cloudburstmc.math.vector.Vector3f holdPos = org.cloudburstmc.math.vector.Vector3f.from(0, 66, 0);
            org.cloudburstmc.protocol.bedrock.packet.RespawnPacket configRespawnPacket =
                new org.cloudburstmc.protocol.bedrock.packet.RespawnPacket();
            configRespawnPacket.setRuntimeEntityId(0);
            configRespawnPacket.setPosition(holdPos);
            configRespawnPacket.setState(org.cloudburstmc.protocol.bedrock.packet.RespawnPacket.State.SERVER_READY);
            upstream.sendPacket(configRespawnPacket);

            org.cloudburstmc.protocol.bedrock.packet.MovePlayerPacket configMovePacket =
                new org.cloudburstmc.protocol.bedrock.packet.MovePlayerPacket();
            configMovePacket.setRuntimeEntityId(playerEntity.geyserId());
            configMovePacket.setPosition(holdPos);
            configMovePacket.setRotation(org.cloudburstmc.math.vector.Vector3f.ZERO);
            configMovePacket.setMode(org.cloudburstmc.protocol.bedrock.packet.MovePlayerPacket.Mode.RESPAWN);
            upstream.sendPacket(configMovePacket);
        }
        // Disable time progression whilst the form is open
        // Once logged into the game this is set correctly when receiving a time packet from the server
        resetTimeParameters();
    }""",
        "GeyserSession.prepareForConfigurationFormExitLoadingScreen",
    )

    java_login_trans = root / "core/src/main/java/org/geysermc/geyser/translator/protocol/java/JavaLoginTranslator.java"
    replace_exact(
        java_login_trans,
        """        } else {
            SetPlayerGameTypePacket playerGameTypePacket = new SetPlayerGameTypePacket();
            playerGameTypePacket.setGamemode(EntityUtils.toBedrockGamemode(spawnInfo.getGameMode()).ordinal());
            session.sendUpstreamPacket(playerGameTypePacket);
        }""",
        """        } else {
            SetPlayerGameTypePacket playerGameTypePacket = new SetPlayerGameTypePacket();
            playerGameTypePacket.setGamemode(EntityUtils.toBedrockGamemode(spawnInfo.getGameMode()).ordinal());
            session.sendUpstreamPacket(playerGameTypePacket);
            session.getUpstream().sendPostStartGamePackets();
            session.setLastChunkPosition(null);
        }""",
        "JavaLoginTranslator.postConfigDialogCleanup",
    )

    dialog_cls = root / "core/src/main/java/org/geysermc/geyser/session/dialog/Dialog.java"
    replace_exact(
        dialog_cls,
        """        title = MessageTranslator.convertFromNullableNbtTag(session, map.get("title"));""",
        """        title = Objects.requireNonNullElse(MessageTranslator.convertFromNullableNbtTag(session, map.get("title")), "");""",
        "Dialog.nullSafeTitle",
    )

    dialog_btn_cls = root / "core/src/main/java/org/geysermc/geyser/session/dialog/DialogButton.java"
    replace_exact(
        dialog_btn_cls,
        """        return Optional.of(new DialogButton(MessageTranslator.convertFromNullableNbtTag(session, map.get("label")), DialogAction.read(map.get("action"), idGetter)));""",
        """        return Optional.of(new DialogButton(java.util.Objects.requireNonNullElse(MessageTranslator.convertFromNullableNbtTag(session, map.get("label")), ""), DialogAction.read(map.get("action"), idGetter)));""",
        "DialogButton.nullSafeLabel",
    )

    show_dialog_cfg = root / "core/src/main/java/org/geysermc/geyser/translator/protocol/java/dialogues/JavaShowDialogueConfigurationTranslator.java"
    replace_exact(
        show_dialog_cfg,
        """    @Override
    public void translate(GeyserSession session, ClientboundShowDialogConfigurationPacket packet) {
        session.prepareForConfigurationForm();
        session.getDialogManager().openDialog(Holder.ofCustom(packet.getDialog()));
    }""",
        """    @Override
    public void translate(GeyserSession session, ClientboundShowDialogConfigurationPacket packet) {
        try {
            session.prepareForConfigurationForm();
            session.getDialogManager().openDialog(Holder.ofCustom(packet.getDialog()));
        } catch (Throwable t) {
            session.getGeyser().getLogger().warning("Failed to open configuration dialog for " + session.bedrockUsername() + ": " + t.getMessage());
        }
    }""",
        "JavaShowDialogueConfigurationTranslator.safeOpenDialog",
    )

    # =========================================================================
    # 17. Chunk Translation Bounds-Safety (Fixes ClientboundLevelChunkWithLightPacket
    #     ArrayIndexOutOfBoundsException #5341/#3863/#3369 & Spawn Join Timeouts)
    #     + Live Toggleable Custom Skulls & Resource-Pack Prompt Suppression:
    #     - Self-heals uninitialized/mismatched ChunkCache minY/heightY and decodes
    #       actual ChunkSection count from packet.getChunkData() so Limbo/Auth/multi-world
    #       transitions never mismatch javaChunks[] or javaBiomes[] lengths.
    #     - Bounds-checks BlockEntityInfo Y/section lookups, custom-skull bedrockSectionY
    #       lookups (fixing subChunkIndex & null FAWE empty-count sections), paletteId
    #       indices, and BiomeTranslator palette indices so a single out-of-bounds
    #       schematic block entity never aborts the entire LevelChunkPacket.
    #     - Adds clean runtime/config toggle (purpurbedrock.customSkullsEnabled &
    #       purpurbedrock.promptOptionalPacks) that disables custom skulls and suppresses
    #       the Bedrock resource-pack download prompt without deleting player_skulls/*.png
    #       or removing custom-skull support from the core.
    # =========================================================================
    replace_exact(
        level_chunk_translator,
        """        // Ensure that, if the player is using lower world heights, the position is not offset
        int yOffset = session.getChunkCache().getChunkMinY();
        int chunkSize = session.getChunkCache().getChunkHeightY();

        DataPalette[] javaChunks = new DataPalette[chunkSize];
        DataPalette[] javaBiomes = new DataPalette[chunkSize];

        final BlockEntityInfo[] blockEntities = packet.getBlockEntities();
        final List<NbtMap> bedrockBlockEntities = new ObjectArrayList<>(blockEntities.length);

        BitSet waterloggedPaletteIds = new BitSet();
        BitSet bedrockOnlyBlockEntityIds = new BitSet();

        BedrockDimension bedrockDimension = session.getBedrockDimension();
        int maxBedrockSectionY = (bedrockDimension.height() >> 4) - 1;

        int sectionCount;
        ByteBuf byteBuf = null;

        // calculate the difference between the java dimension minY and the bedrock dimension minY as
        // the java chunk sections may need to be placed higher up in the bedrock chunk section array
        int sectionCountDiff = yOffset - (bedrockDimension.minY() >> 4);
        GeyserChunkSection[] sections = new GeyserChunkSection[chunkSize + sectionCountDiff];

        try {
            ByteBuf in = Unpooled.wrappedBuffer(packet.getChunkData());
            for (int sectionY = 0; sectionY < chunkSize; sectionY++) {
                ChunkSection javaSection = MinecraftTypes.readChunkSection(in, BlockRegistries.BLOCK_STATES.get().size(),
                    session.getRegistryCache().registry(JavaRegistries.BIOME).size());
                javaChunks[sectionY] = javaSection.getBlockData();
                javaBiomes[sectionY] = javaSection.getBiomeData();""",
        """        if (session.getChunkCache().getChunkHeightY() <= 0 && session.getDimensionType() != null) {
            ChunkUtils.loadDimension(session);
        }
        // Ensure that, if the player is using lower world heights, the position is not offset
        int yOffset = session.getChunkCache().getChunkMinY();
        int chunkSize = session.getChunkCache().getChunkHeightY();

        final BlockEntityInfo[] blockEntities = packet.getBlockEntities();
        final List<NbtMap> bedrockBlockEntities = new ObjectArrayList<>(blockEntities.length);

        BitSet waterloggedPaletteIds = new BitSet();
        BitSet bedrockOnlyBlockEntityIds = new BitSet();

        BedrockDimension bedrockDimension = session.getBedrockDimension();
        int maxBedrockSectionY = (bedrockDimension.height() >> 4) - 1;

        int sectionCount;
        ByteBuf byteBuf = null;

        try {
            ByteBuf in = Unpooled.wrappedBuffer(packet.getChunkData());
            int blockStateRegistrySize = BlockRegistries.BLOCK_STATES.get().size();
            int biomeRegistrySize = session.getRegistryCache().registry(JavaRegistries.BIOME).size();
            ObjectArrayList<ChunkSection> decodedSections = new ObjectArrayList<>(chunkSize > 0 ? chunkSize : 24);
            while (in.isReadable() && decodedSections.size() < 64) {
                int readerBefore = in.readerIndex();
                try {
                    decodedSections.add(MinecraftTypes.readChunkSection(in, blockStateRegistrySize, biomeRegistrySize));
                } catch (RuntimeException ex) {
                    if (!decodedSections.isEmpty()) {
                        in.readerIndex(readerBefore);
                        break;
                    }
                    throw ex;
                }
                if (in.readerIndex() <= readerBefore) {
                    break;
                }
            }

            if (decodedSections.isEmpty()) {
                ChunkUtils.sendEmptyChunk(session, packet.getX(), packet.getZ(), false);
                return;
            }

            if (decodedSections.size() != chunkSize) {
                int actualSize = decodedSections.size();
                if (actualSize == 24 && bedrockDimension.minY() == -64) {
                    yOffset = -4;
                } else if (actualSize == 16 && yOffset < 0) {
                    yOffset = 0;
                }
                chunkSize = actualSize;
            }

            DataPalette[] javaChunks = new DataPalette[chunkSize];
            DataPalette[] javaBiomes = new DataPalette[chunkSize];

            // calculate the difference between the java dimension minY and the bedrock dimension minY as
            // the java chunk sections may need to be placed higher up in the bedrock chunk section array
            int sectionCountDiff = yOffset - (bedrockDimension.minY() >> 4);
            int maxAllocSections = Math.max(maxBedrockSectionY + 1, Math.max(0, chunkSize + sectionCountDiff));
            GeyserChunkSection[] sections = new GeyserChunkSection[maxAllocSections];

            for (int sectionY = 0; sectionY < chunkSize; sectionY++) {
                ChunkSection javaSection = decodedSections.get(sectionY);
                javaChunks[sectionY] = javaSection.getBlockData();
                javaBiomes[sectionY] = javaSection.getBiomeData();""",
        "JavaLevelChunkWithLightTranslator.safeDecodeAndDynamicHeight",
    )
    replace_exact(
        level_chunk_translator,
        """                if (bedrockSectionY < 0 || maxBedrockSectionY < bedrockSectionY) {
                    // Ignore this chunk section since it goes outside the bounds accepted by the Bedrock client
                    continue;
                }""",
        """                if (bedrockSectionY < 0 || maxBedrockSectionY < bedrockSectionY || bedrockSectionY >= sections.length) {
                    // Ignore this chunk section since it goes outside the bounds accepted by the Bedrock client
                    continue;
                }""",
        "JavaLevelChunkWithLightTranslator.guardBedrockSectionY",
    )
    replace_exact(
        level_chunk_translator,
        """                if (!bedrockOnlyBlockEntityIds.isEmpty()) {
                    for (int yzx = 0; yzx < BlockStorage.SIZE; yzx++) {
                        int paletteId = javaData.get(yzx);
                        if (bedrockOnlyBlockEntityIds.get(paletteId)) {""",
        """                if (javaPalette.size() <= 0 || javaData == null) {
                    continue;
                }

                if (!bedrockOnlyBlockEntityIds.isEmpty()) {
                    for (int yzx = 0; yzx < BlockStorage.SIZE; yzx++) {
                        int paletteId = javaData.get(yzx);
                        if (paletteId >= 0 && bedrockOnlyBlockEntityIds.get(paletteId)) {""",
        "JavaLevelChunkWithLightTranslator.guardPaletteAndBitSet",
    )
    replace_exact(
        level_chunk_translator,
        """                // Convert data array from YZX to XZY coordinate order
                if (waterloggedPaletteIds.isEmpty()) {
                    // No blocks are waterlogged, simply convert coordinate order
                    // This could probably be optimized further...
                    for (int yzx = 0; yzx < BlockStorage.SIZE; yzx++) {
                        int paletteId = javaData.get(yzx);
                        int xzy = indexYZXtoXZY(yzx);
                        bedrockData.set(xzy, paletteId);
                    }

                    layers = new BlockStorage[]{ layer0 };
                } else {
                    // The section contains waterlogged blocks, we need to convert coordinate order AND generate a V1 block storage for
                    // layer 1 with palette ID 1 indicating water
                    int[] layer1Data = new int[BlockStorage.SIZE >> 5];
                    for (int yzx = 0; yzx < BlockStorage.SIZE; yzx++) {
                        int paletteId = javaData.get(yzx);
                        int xzy = indexYZXtoXZY(yzx);
                        bedrockData.set(xzy, paletteId);

                        if (waterloggedPaletteIds.get(paletteId)) {
                            layer1Data[xzy >> 5] |= 1 << (xzy & 0x1F);
                        }
                    }""",
        """                int maxValidPaletteId = bedrockPalette.size() - 1;
                // Convert data array from YZX to XZY coordinate order
                if (waterloggedPaletteIds.isEmpty()) {
                    // No blocks are waterlogged, simply convert coordinate order
                    for (int yzx = 0; yzx < BlockStorage.SIZE; yzx++) {
                        int paletteId = javaData.get(yzx);
                        if (paletteId < 0 || paletteId > maxValidPaletteId) {
                            paletteId = 0;
                        }
                        int xzy = indexYZXtoXZY(yzx);
                        bedrockData.set(xzy, paletteId);
                    }

                    layers = new BlockStorage[]{ layer0 };
                } else {
                    // The section contains waterlogged blocks, we need to convert coordinate order AND generate a V1 block storage for
                    // layer 1 with palette ID 1 indicating water
                    int[] layer1Data = new int[BlockStorage.SIZE >> 5];
                    for (int yzx = 0; yzx < BlockStorage.SIZE; yzx++) {
                        int paletteId = javaData.get(yzx);
                        if (paletteId < 0 || paletteId > maxValidPaletteId) {
                            paletteId = 0;
                        }
                        int xzy = indexYZXtoXZY(yzx);
                        bedrockData.set(xzy, paletteId);

                        if (waterloggedPaletteIds.get(paletteId)) {
                            layer1Data[xzy >> 5] |= 1 << (xzy & 0x1F);
                        }
                    }""",
        "JavaLevelChunkWithLightTranslator.clampPaletteIds",
    )
    replace_exact(
        level_chunk_translator,
        """                int x = blockEntity.getX(); // Relative to chunk
                int y = blockEntity.getY();
                int z = blockEntity.getZ(); // Relative to chunk

                // Get the Java block state ID from block entity position
                DataPalette section = javaChunks[(y >> 4) - yOffset];
                BlockState blockState = BlockState.of(section.get(x, y & 0xF, z));

                // Note that, since 1.20.5, tags can be null, but Bedrock still needs a default tag to render the item
                // Also, some properties - like banner base colors - are part of the tag and is processed here.
                BlockEntityTranslator blockEntityTranslator = BlockEntityUtils.getBlockEntityTranslator(type);

                // The Java server can send block entity data for blocks that aren't actually those blocks.
                // A Java client ignores these
                if (type == blockState.block().blockEntityType()) {
                    bedrockBlockEntities.add(blockEntityTranslator.getBlockEntityTag(session, type, x + chunkBlockX, y, z + chunkBlockZ, tag, blockState));

                    // Check for custom skulls
                    if (session.getPreferencesCache().showCustomSkulls() && type == BlockEntityType.SKULL && tag != null && tag.containsKey("profile")) {
                        BlockDefinition blockDefinition = SkullBlockEntityTranslator.translateSkull(session, tag, Vector3i.from(x + chunkBlockX, y, z + chunkBlockZ), blockState);
                        if (blockDefinition != null) {
                            int bedrockSectionY = (y >> 4) - (bedrockDimension.minY() >> 4);
                            int subChunkIndex = (y >> 4) + (bedrockDimension.minY() >> 4);
                            if (0 <= bedrockSectionY && bedrockSectionY < maxBedrockSectionY) {
                                // Custom skull is in a section accepted by Bedrock
                                GeyserChunkSection bedrockSection = sections[bedrockSectionY];
                                IntList palette = bedrockSection.getBlockStorageArray()[0].getPalette();
                                if (palette instanceof IntImmutableList || palette instanceof IntLists.Singleton) {
                                    // TODO there has to be a better way to expand the palette .-.
                                    bedrockSection = bedrockSection.copy(subChunkIndex);
                                    sections[bedrockSectionY] = bedrockSection;
                                }
                                bedrockSection.setFullBlock(x, y & 0xF, z, 0, blockDefinition.getRuntimeId());
                            }
                        }
                    }
                }""",
        """                int x = blockEntity.getX() & 0xF; // Relative to chunk
                int y = blockEntity.getY();
                int z = blockEntity.getZ() & 0xF; // Relative to chunk

                // Bounds-check block entity Y section so schematic/out-of-bounds/cross-world tile entities never throw AIOOBE
                int javaSectionIdx = (y >> 4) - yOffset;
                if (javaSectionIdx < 0 || javaSectionIdx >= javaChunks.length) {
                    continue;
                }
                DataPalette section = javaChunks[javaSectionIdx];
                if (section == null) {
                    continue;
                }
                BlockState blockState = BlockState.of(section.get(x, y & 0xF, z));

                // Note that, since 1.20.5, tags can be null, but Bedrock still needs a default tag to render the item
                // Also, some properties - like banner base colors - are part of the tag and is processed here.
                BlockEntityTranslator blockEntityTranslator = BlockEntityUtils.getBlockEntityTranslator(type);
                if (blockEntityTranslator == null) {
                    continue;
                }

                // The Java server can send block entity data for blocks that aren't actually those blocks.
                // A Java client ignores these
                if (type == blockState.block().blockEntityType()) {
                    bedrockBlockEntities.add(blockEntityTranslator.getBlockEntityTag(session, type, x + chunkBlockX, y, z + chunkBlockZ, tag, blockState));

                    // Check for custom skulls (respects runtime/config toggle purpurbedrock.customSkullsEnabled)
                    if (Boolean.parseBoolean(System.getProperty("purpurbedrock.customSkullsEnabled", "true"))
                            && session.getPreferencesCache().showCustomSkulls()
                            && type == BlockEntityType.SKULL && tag != null && tag.containsKey("profile")) {
                        BlockDefinition blockDefinition = SkullBlockEntityTranslator.translateSkull(session, tag, Vector3i.from(x + chunkBlockX, y, z + chunkBlockZ), blockState);
                        if (blockDefinition != null) {
                            int bedrockSectionY = (y >> 4) - (bedrockDimension.minY() >> 4);
                            int subChunkIndex = (y >> 4);
                            if (0 <= bedrockSectionY && bedrockSectionY <= maxBedrockSectionY && bedrockSectionY < sections.length) {
                                // Custom skull is in a section accepted by Bedrock
                                GeyserChunkSection bedrockSection = sections[bedrockSectionY];
                                if (bedrockSection == null) {
                                    bedrockSection = new GeyserChunkSection(session.getBlockMappings().getBedrockAir().getRuntimeId(), subChunkIndex);
                                    sections[bedrockSectionY] = bedrockSection;
                                }
                                IntList palette = bedrockSection.getBlockStorageArray()[0].getPalette();
                                if (palette instanceof IntImmutableList || palette instanceof IntLists.Singleton) {
                                    bedrockSection = bedrockSection.copy(subChunkIndex);
                                    sections[bedrockSectionY] = bedrockSection;
                                }
                                bedrockSection.setFullBlock(x, y & 0xF, z, 0, blockDefinition.getRuntimeId());
                            }
                        }
                    }
                }""",
        "JavaLevelChunkWithLightTranslator.safeBlockEntityAndSkullBounds",
    )
    replace_exact(
        level_chunk_translator,
        """            int dimensionOffset = bedrockDimension.minY() >> 4;
            for (int i = 0; i < biomeCount; i++) {
                int biomeYOffset = dimensionOffset + i;
                if (biomeYOffset < yOffset) {
                    // Ignore this biome section since it goes below the height of the Java world
                    byteBuf.writeBytes(ChunkUtils.EMPTY_BIOME_DATA);
                    continue;
                }
                if (biomeYOffset >= (chunkSize + yOffset)) {
                    // This biome section goes above the height of the Java world
                    // The byte written here is a header that says to carry on the biome data from the previous chunk
                    byteBuf.writeByte((127 << 1) | 1);
                    continue;
                }

                BiomeTranslator.toNewBedrockBiome(session, javaBiomes[i + (dimensionOffset - yOffset)]).writeToNetwork(byteBuf);
            }""",
        """            int dimensionOffset = bedrockDimension.minY() >> 4;
            for (int i = 0; i < biomeCount; i++) {
                int biomeYOffset = dimensionOffset + i;
                int javaBiomeIdx = i + (dimensionOffset - yOffset);
                if (biomeYOffset < yOffset || javaBiomeIdx < 0) {
                    // Ignore this biome section since it goes below the height of the Java world
                    byteBuf.writeBytes(ChunkUtils.EMPTY_BIOME_DATA);
                    continue;
                }
                if (biomeYOffset >= (chunkSize + yOffset) || javaBiomeIdx >= javaBiomes.length || javaBiomes[javaBiomeIdx] == null) {
                    // Subchunk 0 has no previous subchunk to copy from; write full empty biome data if i == 0
                    if (i == 0) {
                        byteBuf.writeBytes(ChunkUtils.EMPTY_BIOME_DATA);
                    } else {
                        byteBuf.writeByte((127 << 1) | 1);
                    }
                    continue;
                }

                BiomeTranslator.toNewBedrockBiome(session, javaBiomes[javaBiomeIdx]).writeToNetwork(byteBuf);
            }""",
        "JavaLevelChunkWithLightTranslator.safeBiomeBounds",
    )

    biome_translator = root / "core/src/main/java/org/geysermc/geyser/translator/level/BiomeTranslator.java"
    replace_exact(
        biome_translator,
        """                BitStorage bitStorage = biomeData.getStorage();
                int size = palette.size();""",
        """                BitStorage bitStorage = biomeData.getStorage();
                int size = palette.size();
                if (size <= 0 || bitStorage == null) {
                    return new BlockStorage(SingletonBitArray.INSTANCE, IntLists.singleton(fallbackBiomeId(session.getDimensionType())));
                }""",
        "BiomeTranslator.guardEmptyBiomePalette",
    )
    replace_exact(
        biome_translator,
        """                    // Each section of biome corresponding to a chunk section contains 4 * 4 * 4 entries
                    for (int i = 0; i < 64; i++) {
                        int idx = bitStorage.get(i);""",
        """                    // Each section of biome corresponding to a chunk section contains 4 * 4 * 4 entries
                    for (int i = 0; i < 64; i++) {
                        int idx = bitStorage.get(i);
                        if (idx < 0 || idx >= size) {
                            idx = 0;
                        }""",
        "BiomeTranslator.clampBiomePaletteIdx",
    )

    java_respawn_trans = root / "core/src/main/java/org/geysermc/geyser/translator/protocol/java/JavaRespawnTranslator.java"
    replace_exact(
        java_respawn_trans,
        """            ChunkUtils.loadDimension(session);
        }

        session.sendDownstreamGamePacket(ServerboundPlayerLoadedPacket.INSTANCE);""",
        """            ChunkUtils.loadDimension(session);
        } else if (session.getChunkCache().getChunkHeightY() <= 0 && session.getDimensionType() != null) {
            ChunkUtils.loadDimension(session);
        }

        session.sendDownstreamGamePacket(ServerboundPlayerLoadedPacket.INSTANCE);""",
        "JavaRespawnTranslator.ensureDimensionLoadedOnSameWorldRespawn",
    )

    # Custom skulls & optional resource pack prompt toggle (preserves cached PNGs & core support)
    replace_exact(
        skull_populator,
        """        if (!GeyserImpl.getInstance().config().gameplay().enableCustomContent()) {
            return;
        }""",
        """        if (!GeyserImpl.getInstance().config().gameplay().enableCustomContent()
                || !Boolean.parseBoolean(System.getProperty("purpurbedrock.customSkullsEnabled", "true"))) {
            try {
                Files.createDirectories(GeyserImpl.getInstance().getBootstrap().getConfigFolder().resolve("cache").resolve("player_skulls"));
            } catch (IOException ignored) {
            }
            return;
        }""",
        "CustomSkullRegistryPopulator.respectCustomSkullsToggle",
    )
    replace_exact(
        skull_pack_mgr,
        """        Path packPath = cachePath.resolve("player_skulls.mcpack");
        File packFile = packPath.toFile();
        if (BlockRegistries.CUSTOM_SKULLS.get().isEmpty() || !GeyserImpl.getInstance().config().gameplay().enableCustomContent()) {
            packFile.delete(); // No need to keep resource pack
            return null;
        }""",
        """        Path packPath = cachePath.resolve("player_skulls.mcpack");
        File packFile = packPath.toFile();
        if (!Boolean.parseBoolean(System.getProperty("purpurbedrock.customSkullsEnabled", "true"))) {
            // Preserve cached player_skulls.mcpack and player_skulls/*.png on disk for instant re-enable later,
            // while returning null so players are never prompted to download the skull pack when disabled.
            return null;
        }
        if (BlockRegistries.CUSTOM_SKULLS.get().isEmpty() || !GeyserImpl.getInstance().config().gameplay().enableCustomContent()) {
            packFile.delete(); // No need to keep resource pack
            return null;
        }""",
        "SkullResourcePackManager.skipPackWithoutDeletingWhenDisabled",
    )

    session_load_packs = root / "core/src/main/java/org/geysermc/geyser/event/type/SessionLoadResourcePacksEventImpl.java"
    replace_exact(
        session_load_packs,
        """    public SessionLoadResourcePacksEventImpl(GeyserSession session) {
        super(session);
        this.session = session;
        this.packs = new Object2ObjectLinkedOpenHashMap<>(Registries.RESOURCE_PACKS.get());
        this.sessionPackOptionOverrides = new Object2ObjectOpenHashMap<>();
    }""",
        """    public SessionLoadResourcePacksEventImpl(GeyserSession session) {
        super(session);
        this.session = session;
        this.packs = new Object2ObjectLinkedOpenHashMap<>(Registries.RESOURCE_PACKS.get());
        this.sessionPackOptionOverrides = new Object2ObjectOpenHashMap<>();

        boolean customSkullsEnabled = Boolean.parseBoolean(System.getProperty("purpurbedrock.customSkullsEnabled", "true"));
        boolean promptOptionalPacks = Boolean.parseBoolean(System.getProperty("purpurbedrock.promptOptionalPacks", "true"));
        boolean forcePacks = GeyserImpl.getInstance().config().gameplay().forceResourcePacks();
        if (!customSkullsEnabled) {
            this.packs.entrySet().removeIf(entry -> {
                if (entry.getValue().codec() instanceof org.geysermc.geyser.api.pack.PathPackCodec pathCodec) {
                    java.nio.file.Path fileName = pathCodec.path().getFileName();
                    return fileName != null && "player_skulls.mcpack".equalsIgnoreCase(fileName.toString());
                }
                return false;
            });
        }
        if (!forcePacks && (!promptOptionalPacks || !customSkullsEnabled)) {
            this.packs.remove(INTEGRATED_PACK_UUID);
        }
    }""",
        "SessionLoadResourcePacksEventImpl.suppressSkullAndOptionalPackPrompt",
    )

    skull_be_trans = root / "core/src/main/java/org/geysermc/geyser/translator/level/block/entity/SkullBlockEntityTranslator.java"
    replace_exact(
        skull_be_trans,
        """    public static @Nullable BlockDefinition translateSkull(GeyserSession session, NbtMap javaNbt, Vector3i blockPosition, BlockState blockState) {
        NbtMap profile = javaNbt.getCompound("profile");""",
        """    public static @Nullable BlockDefinition translateSkull(GeyserSession session, NbtMap javaNbt, Vector3i blockPosition, BlockState blockState) {
        if (!Boolean.parseBoolean(System.getProperty("purpurbedrock.customSkullsEnabled", "true"))) {
            session.getSkullCache().removeSkull(blockPosition);
            return null;
        }
        NbtMap profile = javaNbt.getCompound("profile");""",
        "SkullBlockEntityTranslator.respectCustomSkullsToggle",
    )

    replace_exact(
        skull_cache_cls,
        """    public Skull putSkull(Vector3i position, UUID uuid, String skinUrl, String skinHash, BlockState blockState) {
        Skull skull = skulls.computeIfAbsent(position, Skull::new);""",
        """    public Skull putSkull(Vector3i position, UUID uuid, String skinUrl, String skinHash, BlockState blockState) {
        if (!Boolean.parseBoolean(System.getProperty("purpurbedrock.customSkullsEnabled", "true"))) {
            return null;
        }
        Skull skull = skulls.computeIfAbsent(position, Skull::new);""",
        "SkullCache.putSkullRespectToggle",
    )
    replace_exact(
        skull_cache_cls,
        """    public void updateVisibleSkulls() {
        if (cullingEnabled) {""",
        """    public void updateVisibleSkulls() {
        if (!Boolean.parseBoolean(System.getProperty("purpurbedrock.customSkullsEnabled", "true"))) {
            if (!skulls.isEmpty()) {
                clear();
            }
            return;
        }
        if (cullingEnabled) {""",
        "SkullCache.updateVisibleSkullsRespectToggle",
    )
    replace_exact(
        skull_cache_cls,
        """        if (cullingEnabled) {
            inRangeSkulls.remove(skull);
            if (hadEntity && inRangeSkulls.size() >= maxVisibleSkulls) {
                // Reassign entity to the closest skull without an entity
                assignSkullEntity(inRangeSkulls.get(maxVisibleSkulls - 1));
            }
        }""",
        """        if (cullingEnabled) {
            inRangeSkulls.remove(skull);
            if (hadEntity && maxVisibleSkulls > 0 && inRangeSkulls.size() >= maxVisibleSkulls) {
                // Reassign entity to the closest skull without an entity
                assignSkullEntity(inRangeSkulls.get(maxVisibleSkulls - 1));
            }
        }""",
        "SkullCache.guardZeroMaxVisibleSkulls",
    )

    item_translator = root / "core/src/main/java/org/geysermc/geyser/translator/item/ItemTranslator.java"
    replace_exact(
        item_translator,
        """    private static @Nullable CustomSkull getCustomSkull(@Nullable ResolvableProfile profile) {
        if (profile == null) {
            return null;
        }""",
        """    private static @Nullable CustomSkull getCustomSkull(@Nullable ResolvableProfile profile) {
        if (profile == null || !Boolean.parseBoolean(System.getProperty("purpurbedrock.customSkullsEnabled", "true"))) {
            return null;
        }""",
        "ItemTranslator.getCustomSkullRespectToggle",
    )


    # Keep upstream entity delta movement unchanged. Player rendering is made lightweight
    # at spawn/equipment level instead of rewriting movement packet cadence.

    # Reliable plugin-formatted chat: Bedrock social/XUID filtering can silently discard
    # CHAT packets when performance-safe player entries intentionally have no Xbox identity.
    # Deliver already-formatted Java chat as SYSTEM text and queue it during StartGame.
    message_translator = root / "core/src/main/java/org/geysermc/geyser/translator/text/MessageTranslator.java"
    replace_exact(
        message_translator,
        """        if (senderUuid == null) {
            textPacket.setXuid(session.getAuthData().xuid());
        } else {
            String xuid = "";
            GeyserSession playerSession = GeyserImpl.getInstance().connectionByUuid(senderUuid);

            // Prefer looking up xuid using the session to catch linked players
            if (playerSession != null) {
                xuid = playerSession.getAuthData().xuid();
            } else if (senderUuid.version() == 0) {
                xuid = Long.toString(senderUuid.getLeastSignificantBits());
            }
            textPacket.setXuid(xuid);
        }
        textPacket.setType(TextPacket.Type.CHAT);""",
        """        // The Java decoration below already contains the sender and ChatEX format.
        // SYSTEM bypasses Bedrock's local Xbox/social filter, which otherwise drops messages
        // whose sender intentionally uses the shared performance-safe player-list identity.
        textPacket.setXuid("");
        textPacket.setType(TextPacket.Type.SYSTEM);""",
        "MessageTranslator.reliablePluginChatIdentity",
    )
    replace_exact(
        message_translator,
        """        session.sendUpstreamPacket(textPacket);
    }

    /**
     * Checks if the given message is over 256 characters""",
        """        if (session.isSentSpawnPacket()) {
            session.sendUpstreamPacket(textPacket);
        } else {
            session.getUpstream().queuePostStartGamePacket(textPacket);
        }
    }

    /**
     * Checks if the given message is over 256 characters""",
        "MessageTranslator.queueChatDuringStartGame",
    )

    system_chat = root / "core/src/main/java/org/geysermc/geyser/translator/protocol/java/JavaSystemChatTranslator.java"
    replace_exact(
        system_chat,
        """        textPacket.setXuid(session.getAuthData().xuid());""",
        """        textPacket.setXuid(""); // Purpurbedrock: never let Bedrock social filtering hide plugin/system chat""",
        "JavaSystemChatTranslator.noRecipientXuidFiltering",
    )

    # Virtual Java chest menus need a temporary Bedrock block. Prefer a block three positions
    # below the player so it never appears above their head, and suppress the client's stale
    # close acknowledgement briefly after a submenu has been opened.
    inventory_translator = root / "core/src/main/java/org/geysermc/geyser/translator/inventory/InventoryTranslator.java"
    replace_exact(
        inventory_translator,
        """        if (inventory.getContainerType() == null || previous.getContainerType() == null ||
            !Objects.equals(inventory.getContainerType(), previous.getContainerType()) ||
            !Objects.equals(inventory.getTitle(), previous.getTitle()) ||
            inventory.getSize() != previous.getSize()
        ) {""",
        """        if (inventory.getContainerType() == null || previous.getContainerType() == null ||
            !Objects.equals(inventory.getContainerType(), previous.getContainerType()) ||
            inventory.getSize() != previous.getSize()
        ) {
            // Purpurbedrock: a title-only change must not tear down the virtual chest.
            // DeluxeMenus sections commonly keep the same 54-slot type with a new title;
            // reusing the holder avoids the Bedrock close/open race entirely.""",
        "InventoryTranslator.reuseSameSizeSubmenusAcrossTitles",
    )

    game_event_translator = root / "core/src/main/java/org/geysermc/geyser/translator/protocol/java/level/JavaGameEventTranslator.java"
    replace_exact(
        game_event_translator,
        """            case CHANGE_GAME_MODE:
                GameMode gameMode = (GameMode) packet.getValue();

                SetPlayerGameTypePacket playerGameTypePacket = new SetPlayerGameTypePacket();""",
        """            case CHANGE_GAME_MODE:
                GameMode gameMode = (GameMode) packet.getValue();

                // Creative inventory is client-native. A pending virtual chest from /shop must
                // never remain selected across the mode change or every inventory-open attempt
                // is interpreted as belonging to that stale Java container.
                var openHolder = session.getInventoryHolder();
                if (openHolder != null) {
                    org.geysermc.geyser.util.InventoryUtils.sendJavaContainerClose(openHolder);
                    org.geysermc.geyser.util.InventoryUtils.closeInventory(session, openHolder, false);
                }
                session.setPendingOrCurrentBedrockInventoryId(-1);
                session.setClosingInventory(false);

                SetPlayerGameTypePacket playerGameTypePacket = new SetPlayerGameTypePacket();""",
        "JavaGameEventTranslator.clearVirtualMenuOnGameModeChange",
    )

    inventory_utils = root / "core/src/main/java/org/geysermc/geyser/util/InventoryUtils.java"
    replace_exact(
        inventory_utils,
        """    public static void openInventory(InventoryHolder<?> holder) {
        holder.markCurrent();
        if (holder.shouldSetPending()) {""",
        """    public static void openInventory(InventoryHolder<?> holder) {
        GeyserSession session = holder.session();
        // Recover an orphaned virtual-container ID left by a Java menu that was closed
        // before the Bedrock client displayed it. Without this, every later /shop or /menu
        // remains pending forever because there can never be a close acknowledgement.
        if (session.getInventoryHolder() == null
                && !session.isClosingInventory()
                && session.getPendingOrCurrentBedrockInventoryId() != -1) {
            session.setPendingOrCurrentBedrockInventoryId(-1);
        }
        holder.markCurrent();
        if (holder.shouldSetPending()) {""",
        "InventoryUtils.recoverOrphanBeforeOpen",
    )
    replace_exact(
        inventory_utils,
        """        session.setInventoryHolder(null);
    }

    /**
     * A util method to get an (open) inventory based on a Java id. This method should be used over""",
        """        if (holder != null && holder.pending()
                && session.getPendingOrCurrentBedrockInventoryId() == holder.bedrockId()) {
            // A pending holder was never visible and therefore cannot produce a Bedrock close
            // acknowledgement. Release its ID immediately so the next command can open a menu.
            session.setPendingOrCurrentBedrockInventoryId(-1);
            session.setClosingInventory(false);
        }
        session.setInventoryHolder(null);
    }

    /**
     * A util method to get an (open) inventory based on a Java id. This method should be used over""",
        "InventoryUtils.releaseNeverDisplayedHolder",
    )
    replace_exact(
        inventory_utils,
        """        Vector3i flatPlayerPosition = session.getPlayerEntity().bedrockPosition().toInt();
        Vector3i position = flatPlayerPosition.add(Vector3i.UP);
        if (position.getY() < minY) {
            return null;
        }
        if (position.getY() >= maxY || !canUseWorldSpace(session, position)) {
            position = flatPlayerPosition.down(3);
            if (position.getY() >= maxY || !canUseWorldSpace(session, position)) {
                return null;
            }
        }
        return position;""",
        """        Vector3i flatPlayerPosition = session.getPlayerEntity().bedrockPosition().toInt();
        // Keep the virtual holder out of sight. Above-head chests reveal an implementation
        // detail and can also trigger a client close while switching DeluxeMenus sections.
        Vector3i position = flatPlayerPosition.down(3);
        if (position.getY() < minY || position.getY() >= maxY || !canUseWorldSpace(session, position)) {
            position = flatPlayerPosition.add(Vector3i.UP);
            if (position.getY() < minY || position.getY() >= maxY || !canUseWorldSpace(session, position)) {
                return null;
            }
        }
        return position;""",
        "InventoryUtils.preferInvisibleBelowPlayerVirtualHolder",
    )
    replace_exact(
        inventory_utils,
        """    public static void openAndUpdateInventory(InventoryHolder<?> holder) {
        holder.openInventory();
        holder.updateInventory();
    }""",
        """    public static void openAndUpdateInventory(InventoryHolder<?> holder) {
        holder.openInventory();
        org.geysermc.geyser.translator.protocol.bedrock.BedrockContainerCloseTranslator.protectFreshMenu(holder.session());
        holder.updateInventory();
    }""",
        "InventoryUtils.protectFreshSubmenu",
    )
    replace_exact(
        inventory_utils,
        """    public static void scheduleInventoryOpen(GeyserSession session) {
        session.sendNetworkLatencyStackPacket(MAGIC_VIRTUAL_INVENTORY_HACK, true, () -> {
            if (session.getPendingOrCurrentBedrockInventoryId() != -1) {
                InventoryUtils.openPendingInventory(session);
            }
        });
    }""",
        """    public static void scheduleInventoryOpen(GeyserSession session) {
        final int expectedBedrockId = session.getPendingOrCurrentBedrockInventoryId();
        session.sendNetworkLatencyStackPacket(MAGIC_VIRTUAL_INVENTORY_HACK, true, () -> {
            if (session.getPendingOrCurrentBedrockInventoryId() != -1) {
                InventoryUtils.openPendingInventory(session);
            }
        });
        // Some mobile/WebRTC clients occasionally lose the latency-stack response used as
        // the virtual-block readiness acknowledgement. Never leave the Java inventory pending
        // forever: a serialized fallback opens it only if the exact same holder is still pending.
        session.scheduleInEventLoop(() -> {
            InventoryHolder<?> current = session.getInventoryHolder();
            if (current != null && current.pending()
                    && current.bedrockId() == expectedBedrockId
                    && session.getPendingOrCurrentBedrockInventoryId() == expectedBedrockId) {
                InventoryUtils.openPendingInventory(session);
            }
        }, 350, java.util.concurrent.TimeUnit.MILLISECONDS);
    }""",
        "InventoryUtils.virtualMenuOpenFallback",
    )

    container_close = root / "core/src/main/java/org/geysermc/geyser/translator/protocol/bedrock/BedrockContainerCloseTranslator.java"
    replace_exact(
        container_close,
        """public class BedrockContainerCloseTranslator extends PacketTranslator<ContainerClosePacket> {

    @Override""",
        """public class BedrockContainerCloseTranslator extends PacketTranslator<ContainerClosePacket> {
    private static final java.util.Map<GeyserSession, Long> FRESH_MENU_UNTIL =
        java.util.Collections.synchronizedMap(new java.util.WeakHashMap<>());

    public static void protectFreshMenu(GeyserSession session) {
        // Bedrock can emit a delayed close for the previous virtual chest after the new
        // DeluxeMenus section is already visible. Ignore only that tiny transition window.
        FRESH_MENU_UNTIL.put(session, System.nanoTime() + java.util.concurrent.TimeUnit.MILLISECONDS.toNanos(750));
    }

    @Override""",
        "BedrockContainerCloseTranslator.freshMenuGuardState",
    )
    replace_exact(
        container_close,
        """        byte bedrockId = packet.getId();

        //Client wants close confirmation
        session.sendUpstreamPacket(packet);
        session.setClosingInventory(false);

        // 1.21.70: Bedrock can reject opening inventories - in those cases it replies with -1
        InventoryHolder<? extends Inventory> holder = session.getInventoryHolder();""",
        """        byte bedrockId = packet.getId();
        InventoryHolder<? extends Inventory> holder = session.getInventoryHolder();

        Long protectedUntil = FRESH_MENU_UNTIL.get(session);
        if (bedrockId != -1 && holder != null && bedrockId == holder.bedrockId()
                && protectedUntil != null && System.nanoTime() < protectedUntil) {
            // This is the stale close generated by the just-replaced virtual chest, not a
            // deliberate player action. Re-open in place and keep the Java submenu active.
            holder.openInventory();
            holder.updateInventory();
            return;
        }
        FRESH_MENU_UNTIL.remove(session);

        //Client wants close confirmation
        session.sendUpstreamPacket(packet);
        session.setClosingInventory(false);

        // 1.21.70: Bedrock can reject opening inventories - in those cases it replies with -1""",
        "BedrockContainerCloseTranslator.ignoreStaleSubmenuClose",
    )



if __name__ == "__main__":
    main()
