rootProject.name = "PurpurBedrockCompletions"
