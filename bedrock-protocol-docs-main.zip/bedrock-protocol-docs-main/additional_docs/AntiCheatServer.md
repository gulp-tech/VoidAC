---
title: Anti-cheat server properties
section: Configuration
order: 2
---

```properties
# This contains the anti-cheat related dedicated server default properties. Add these to your server.properties file and modify as desired.

# Regardless of discrepancies the server will not send corrections within this many ticks of each-other
# After a correction on tick 5 and a delay of 2, the next possible correction would be on tick 8
player-rewind-min-correction-delay-ticks=5
# How many ticks of history are contained in the client's rolling window for use when receiving corrections.
# At 20 ticks per second a history size of 40 means that a correction could stil be processed with rewind with
# two seconds of two-way latency
player-rewind-history-size-ticks=40

# This is the tolerance of discrepancies between the Client and Server Player position. This helps prevent sending corrections too frequently
# for non-cheating players in cases where the server and client have different perceptions about when a motion started. For example damage knockback or being pushed by pistons.
# The higher the number, the more tolerant the server will be before asking for a correction. Values beyond 1.0 have increased chances of allowing cheating.
# This value drives a combination of a few behaviors:
# - The server eases their position by a small fraction of this towards the client to converge towards being in sync
# - The server sends a correction if the divergence distance is above this amount
# - The server accepts the client position if the divergence is within a small fraction of this
player-position-acceptance-threshold=0.5

# Block break settings
server-authoritative-block-breaking=true
server-authoritative-block-breaking-pick-range-scalar=1.5
```