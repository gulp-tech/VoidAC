dependencies {
    compileOnlyApi(libs.annotations)
}
