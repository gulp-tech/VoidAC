package ac.boar.anticheat.ack.types;

import ac.boar.anticheat.ack.Acknowledgment;

public record ChunkRadiusUpdateAck(int radius) implements Acknowledgment {
}
