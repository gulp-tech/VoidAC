package acknowledgement

import (
	"time"

	"github.com/go-gl/mathgl/mgl32"
	"github.com/oomph-ac/oomph/anticheat/player"
)

// PlayerInitalized is an acknowledgment that is ran to signal when the player is ready for processing
type PlayerInitalized struct {
	mPlayer *player.Player
}

func NewPlayerInitalizedACK(p *player.Player) *PlayerInitalized {
	return &PlayerInitalized{mPlayer: p}
}

func (ack *PlayerInitalized) Run() {
	ack.mPlayer.Ready = true
}

// Latency is an acknowledgment that is ran to measure the full stack latency between
// Oomph and the member player.
type Latency struct {
	mPlayer *player.Player

	timeOf time.Time
	tickOf int64
}

func NewLatencyACK(p *player.Player, timeOf time.Time, tickOf int64) *Latency {
	return &Latency{
		mPlayer: p,
		timeOf:  timeOf,
		tickOf:  tickOf,
	}
}

func (ack *Latency) Run() {
	ack.mPlayer.StackLatency = ack.mPlayer.Time().Sub(ack.timeOf)
	// Using this little trick screws over players attempting to use backtrack. GG.
	if !ack.mPlayer.Ready || ack.mPlayer.ClientTick < ack.tickOf || ack.mPlayer.ClientTick >= ack.mPlayer.ServerTick {
		// ack.mPlayer.Message("set tick from %d -> %d", ack.mPlayer.ClientTick, ack.tickOf)
		ack.mPlayer.ClientTick = ack.tickOf
	}
	ack.mPlayer.Dbg.Notify(player.DebugModeLatency, true, "latency=%.2fms (tickLatency=%d)", float64(ack.mPlayer.StackLatency.Microseconds())/1000.0, ack.mPlayer.ServerTick-ack.mPlayer.ClientTick)
}

// UpdateSimRate is an acknowledgment that is ran to update the player's simulation rate.
type UpdateSimRate struct {
	mPlayer *player.Player
	mul     float32
}

func NewUpdateSimRateACK(p *player.Player, mul float32) *UpdateSimRate {
	return &UpdateSimRate{
		mPlayer: p,
		mul:     mul,
	}
}

func (ack *UpdateSimRate) Run() {
	if mgl32.FloatEqual(ack.mul, 1.0) {
		ack.mPlayer.Tps = 20.0
	} else {
		ack.mPlayer.Tps *= ack.mul
	}
}
