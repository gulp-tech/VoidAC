/*
 * Copyright (c) 2019-2022 GeyserMC. http://geysermc.org
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @author GeyserMC
 * @link https://github.com/GeyserMC/Geyser
 */

package org.geysermc.geyser.entity.type;

import org.geysermc.geyser.api.util.Identifier;
import org.geysermc.geyser.entity.spawn.EntitySpawnContext;
import org.geysermc.geyser.registry.Registries;
import org.geysermc.mcprotocollib.protocol.data.game.entity.metadata.type.BooleanEntityMetadata;

public class WitherSkullEntity extends FireballEntity {
    private boolean isCharged;
    private static final Identifier DANGEROUS_SKULL = Identifier.of("wither_skull_dangerous");

    public WitherSkullEntity(EntitySpawnContext context) {
        super(context);

        this.futureTicks = 1;
    }

    public void setDangerous(BooleanEntityMetadata entityMetadata) {
        boolean newDangerous = entityMetadata.getPrimitiveValue();
        if (newDangerous != isCharged) {
            isCharged = newDangerous;
            // Is an entirely new entity in Bedrock but just a metadata type in Java
            bedrockDefinition = isCharged ? Registries.BEDROCK_ENTITY_DEFINITIONS.get(DANGEROUS_SKULL) : javaDefinition.defaultBedrockDefinition();
            despawnEntity();
            spawnEntity();
        }
    }

    @Override
    protected float getDrag() {
        return isCharged ? 0.73f : super.getDrag();
    }
}
