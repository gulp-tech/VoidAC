/*
 * Copyright (c) 2019-2026 GeyserMC. http://geysermc.org
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @author GeyserMC
 * @link https://github.com/GeyserMC/Geyser
 */

package org.geysermc.geyser.api.connection;

import org.checkerframework.checker.index.qual.Positive;
import org.geysermc.api.connection.Connection;
import org.geysermc.geyser.api.bedrock.camera.CameraData;
import org.geysermc.geyser.api.bedrock.camera.CameraShake;
import org.geysermc.geyser.api.command.CommandSource;
import org.geysermc.geyser.api.entity.EntityData;
import org.geysermc.geyser.api.entity.type.player.GeyserAvatarEntity;
import org.geysermc.geyser.api.entity.type.player.GeyserPlayerEntity;
import org.geysermc.geyser.api.skin.SkinData;

import java.util.NoSuchElementException;
import java.util.Set;
import java.util.UUID;

/**
 * Represents a player connection used in Geyser.
 */
public interface GeyserConnection extends Connection, CommandSource {

    /**
     * Exposes the {@link CameraData} for this connection.
     * It allows you to send fogs, camera shakes, force camera perspectives, and more.
     *
     * @return the CameraData for this connection.
     */
    CameraData camera();

    /**
     * Exposes the {@link EntityData} for this connection.
     * It allows you to look up other entities through various methods.
     *
     * @return the EntityData for this connection.
     */
    EntityData entities();

    /**
     * Returns the current ping of the connection.
     */
    int ping();

    /**
     * @return {@code true} if the client currently has a form open.
     * @since 2.8.0
     */
    boolean hasFormOpen();

    /**
     * Closes the currently open form on the client.
     */
    void closeForm();

    /**
     * Gets the Bedrock protocol version of the player.
     */
    int protocolVersion();

    /**
     * Attempts to open the {@code minecraft:pause_screen_additions} dialog tag. This method opens this dialog the same way Java does, that is:
     *
     * <ul>
     *     <li>If there are multiple dialogs in the additions tag, the {@code minecraft:custom_options} dialog is opened to select a dialog.</li>
     *     <li>If there is one dialog in the additions tag, that dialog is opened.</li>
     *     <li>If there are no dialogs in the tag, but there are server links sent to the client, the {@code minecraft:server_links} dialog is opened.</li>
     *     <li>If all of the above fails, no dialog is opened.</li>
     * </ul>
     *
     * <p>Use {@link GeyserConnection#hasFormOpen()} to check if a dialog was opened.</p>
     * @since 2.8.0
     */
    void openPauseScreenAdditions();

    /**
     * Attempts to open the {@code minecraft:quick_actions} dialog tag. This method opens this dialog the same way Java does, that is:
     *
     * <ul>
     *     <li>If there are multiple dialogs in the actions tag, the {@code minecraft:quick_actions} dialog is opened to select a dialog.</li>
     *     <li>If there is one dialog in the actions tag, that dialog is opened.</li>
     *     <li>If there are no dialogs in the tag, no dialog is opened.</li>
     * </ul>
     *
     * <p>Use {@link GeyserConnection#hasFormOpen()} to check if a dialog was opened.</p>
     * @since 2.8.0
     */
    void openQuickActions();

    /**
     * Sends a command as if the player had executed it.
     *
     * @param command the command without the leading forward-slash
     * @since 2.8.0
     */
    void sendCommand(String command);

    /**
     * Gets the hostname or ip address the player used to join this Geyser instance.
     * Example:
     * <ul>
     *     <li> {@code test.geysermc.org} </li>
     *     <li> {@code 127.0.0.1} </li>
     *     <li> {@code 06e9:c755:4eff:5f13:9b4c:4b21:9df2:6a73} </li>
     * </ul>
     *
     * @throws NoSuchElementException if called before the session is fully initialized
     * @return the ip address or hostname string the player used to join 
     * @since 2.8.3
     */
    String joinAddress();

    /**
     * Gets the port the player used to join this Geyser instance.
     * Example:
     * <ul>
     *     <li> {@code 19132} </li>
     *     <li> {@code 2202} </li>
     * </ul>
     *
     * @throws NoSuchElementException if called before the session is fully initialized
     * @return the port the player used to join 
     * @since 2.8.3
     */
    @Positive
    int joinPort();

    /**
     * Applies a skin to a player seen by this Geyser connection.
     * If the uuid matches the {@link GeyserConnection#javaUuid()}, this
     * will update the skin of this Geyser connection.
     * If the player uuid provided is not known to this connection, this method
     * will silently return.
     *
     * @param player which player this skin should be applied to
     * @param skinData the skin data to apply
     * @since 2.8.3
     */
    void sendSkin(UUID player, SkinData skinData);

    /**
     * Displays a player entity as emoting to this client.
     *
     * <p>This method is deprecated and planned to be removed in Geyser 2.14.0.</p>
     *
     * @param emoter the player entity emoting.
     * @param emoteId the emote ID to send to this client.
     * @deprecated since 2.12.1: use {@link GeyserAvatarEntity#showEmote(String, boolean)} instead.
     */
    @Deprecated(since = "2.12.1")
    default void showEmote(GeyserPlayerEntity emoter, String emoteId) {
        emoter.showEmote(emoteId);
    }

    /**
     * Shakes the client's camera.
     * <p>
     * If the camera is already shaking with the same {@link CameraShake} type, then the additional intensity
     * will be layered on top of the existing intensity, with their own distinct durations.<br>
     * If the existing shake type is different and the new intensity/duration are not positive, the existing shake only
     * switches to the new type. Otherwise, the existing shake is completely overridden.
     *
     * <p>This method is deprecated for removal and will be removed in Geyser 2.13.0.</p>
     *
     * @param intensity the intensity of the shake. The client has a maximum total intensity of 4.
     * @param duration the time in seconds that the shake will occur for
     * @param type the type of shake
     *
     * @deprecated since 2.2.2: use {@link CameraData#shakeCamera(float, float, CameraShake)} instead.
     */
    @Deprecated(since = "2.2.2", forRemoval = true)
    void shakeCamera(float intensity, float duration, CameraShake type);

    /**
     * Stops all camera shake of any type.
     *
     * <p>This method is deprecated for removal and will be removed in Geyser 2.13.0.</p>
     *
     * @deprecated Use {@link CameraData#stopCameraShake()} instead.
     */
    @Deprecated(since = "2.2.2", forRemoval = true)
    void stopCameraShake();

    /**
     * Adds the given fog IDs to the fog cache, then sends all fog IDs in the cache to the client.
     * <p>
     * Fog IDs can be found <a href="https://wiki.bedrock.dev/documentation/fog-ids.html">here</a>
     *
     * <p>This method is deprecated for removal and will be removed in Geyser 2.13.0.</p>
     *
     * @param fogNameSpaces the fog IDs to add. If empty, the existing cached IDs will still be sent.
     * @deprecated since 2.2.2: use {@link CameraData#sendFog(String...)} instead.
     */
    @Deprecated(since = "2.2.2", forRemoval = true)
    void sendFog(String... fogNameSpaces);

    /**
     * Removes the given fog IDs from the fog cache, then sends all fog IDs in the cache to the client.
     *
     * <p>This method is deprecated for removal and will be removed in Geyser 2.13.0.</p>
     *
     * @param fogNameSpaces the fog IDs to remove. If empty, all fog IDs will be removed.
     * @deprecated since 2.2.2: use {@link CameraData#removeFog(String...)} instead.
     */
    @Deprecated(since = "2.2.2", forRemoval = true)
    void removeFog(String... fogNameSpaces);

    /**
     * Returns an immutable copy of all fog affects currently applied to this client.
     *
     * <p>This method is deprecated for removal and will be removed in Geyser 2.13.0.</p>
     *
     * @deprecated since 2.2.2: use {@link CameraData#fogEffects()} instead.
     */
    @Deprecated(since = "2.2.2", forRemoval = true)
    Set<String> fogEffects();

    /**
     * Returns the associated player entity for this connection.
     *
     * @return the {@link GeyserPlayerEntity} for this connection
     * @since 2.9.3
     */
    GeyserPlayerEntity playerEntity();

    /**
     * Requests an offhand swap from the Java server.
     * There is no guarantee of the server accepting the request.
     *
     * @since 2.9.3
     */
    void requestOffhandSwap();

    /**
     * The PlayFab ID of this player.
     *
     * @since 2.9.4
     */
    String playFabId();

    /**
     * Sends a toast notification to this player.
     *
     * @param title the title of the toast notification
     * @param content the content of the toast notification
     *
     * @since 2.11.3
     */
    void sendToast(String title, String content);
}
