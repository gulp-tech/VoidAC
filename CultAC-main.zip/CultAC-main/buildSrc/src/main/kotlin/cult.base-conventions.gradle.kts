import versioning.BuildConfig

plugins {
    `java-library`
    id("io.freefair.lombok")
    id("cult.format-conventions")
}

group = rootProject.group
version = rootProject.version
description = rootProject.description

// Lombok 1.18.44 supports the JDK 25 compile worker.
lombok {
    version.set("1.18.44")
}

// Java compilation settings
java {
    toolchain.languageVersion.set(JavaLanguageVersion.of(25))
    disableAutoTargetJvm()
    withSourcesJar()
    withJavadocJar()
}

tasks {
    withType<JavaCompile>().configureEach {
        options.encoding = "UTF-8"
        options.release.set(17)
    }

    // Process resources (e.g., for plugin metadata files)
    processResources {
        val properties = mapOf(
            "timestamp" to rootProject.ext["timestamp"],
            "version" to project.version.toString(),
            "git_commit" to rootProject.ext["git_commit"],
            "git_branch" to rootProject.ext["git_branch"],
            "git_repo" to rootProject.ext["git_repo"],
            "git_org" to rootProject.ext["git_org"],
            "build_relocate" to BuildConfig.relocate,
            "build_release" to BuildConfig.release,
        )

        properties.forEach { (key, value) -> inputs.property(key, value) }

        filesMatching(
            listOf(
                "bungee.yml",
                "velocity-plugin.json",
                "cultac.properties"
            )
        ) {
            expand(properties)
        }
    }

    javadoc {
        title = "${rootProject.name}-${project.name} v${rootProject.version}"
        options.encoding = "UTF-8"
        options.overview =
            rootProject.file("buildSrc/src/main/resources/javadoc-overview.html").toString()
        destinationDir = file("${project.layout.buildDirectory.asFile.get()}/docs/javadoc")
        options {
            (this as CoreJavadocOptions).addBooleanOption("Xdoclint:none", true)
        }
    }
}

// Default tasks
defaultTasks("build")
